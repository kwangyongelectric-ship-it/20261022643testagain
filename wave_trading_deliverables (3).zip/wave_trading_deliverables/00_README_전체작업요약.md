# 파형 분석 · 데이터 수집 · 승인 게이트 — 전체 작업 산출물

작성일: 2026-10-19 · 상태 판정: **NOT APPROVED (운영 승인 아님)** — 모든 검증은 합성 데이터와 스텁 기준입니다.

## 1. 패키지 구성

| 폴더 | 내용 | 계약 기준 | 테스트(빈 디렉터리 실측) |
|---|---|---|---|
| `01_wave_trading_verified/` | 평평한 단일 프로젝트: 파형 분석·추천(`wave.py`), 백테스터 v3(`backtest.py`), 봉 확정(`bar_finality.py`), 신뢰도 보정·시간순 OOS·상태 지문 바인딩(`position_confidence.py`), 승인 게이트(`approval_engine*.py`), 게이트 OOS·안정성(`oos_validation*.py`), 수집기(`data_collector_ohlcv.py`), 수집기(`data_collector_ohlcv.py`), shadow 모니터·입력 진단 도구(`wave_shadow_monitor.py`, `diagnose_observations.py`, `LIVE_VERIFICATION_CHECKLIST.md`), 소스 무결성 검사 | (계약 모듈 없음) | **86개 통과** (`python run_tests.py`, shadow 모니터 21개 포함) |
| `02_oos_project_v11_compat/` | 업로드된 **원본 `wave_contracts_ext.py` v1.1.0**(바이트 동일) 기준 계약·OOS·승인·수집 변환·계보 | v1.1.0 | **81개 통과** (엔진 배치 재계산 부정 테스트 11개 포함) |
| `03_oos_project_v1_2_with_lineage_tests/` | 업로드된 `oos_project_v1_2_fingerprint_fixed.zip`의 격리 프로젝트 + 계보 회귀 테스트 5개 | v1.2 제안(`raw_payload_kind` 추가) | **67개 통과** (원본 v1.1.0을 끼우면 38개 실패 — 비호환) |
| `04_contract_proposal/` | `wave_contracts_ext_v1_2_proposal.py` (v1.1.0 + `raw_payload_kind` 1개 필드) | v1.2 제안 | — |
| `05_tools/` | pytest 없이 테스트를 돌리는 간이 실행기와 최소 pytest shim | — | — |
| `06_archive_superseded/` | 초기 버전들(참고용). **현행 기준 아님** | — | — |

측정 조건: 패키지를 빈 디렉터리로 복사하고 환경변수를 초기화(`env -i`)한 뒤 실행. 이 환경에는 pytest가 없어서 02·03은 `05_tools/run_all.py`로 실행했다. 실제 환경에서는 각 폴더에서 `python -m pytest -q`를 권장한다. 소스 무결성 검사: 47개 파일, 이슈 0건. 측정일(월요일)에 요일 의존 결함을 발견·수정했고 그날 외 요일의 실행은 헬퍼 로직(7개 앵커)으로만 확인했다.

## 1-1. 실제 장중 감시 프로그램에 대한 상태 (중요)

**실제 감시 프로그램, 대시보드, KRX 시세 경로는 검증되지 않았다.** 이 패키지의 테스트는 합성 데이터 위의 일봉 파이프라인이다.
모델은 확정 일봉 20개 입력으로만 검증되었고, 장중 스냅샷 20개를 넣는 사용은 **검증된 방식이 아니다**.
`01_wave_trading_verified/LIVE_VERIFICATION_CHECKLIST.md`에 기존 프로그램을 건드리지 않는 shadow 연결 방법,
입력 진단 도구(`diagnose_observations.py`) 사용법, 실행 환경에서 확인할 항목과 필요한 자료를 정리했다.

## 2. 계약 분기 (결정 필요)

- **v1.1.0 유지 (02)**: 원본 계약을 건드리지 않는다. 승인 엔진은 지문 문자열 대신 `CollectedBatch`를 받아 계약 해시를 재계산한다. 수집기 변환은 `raw_payload_kind` 없이 동작하며, 검증기는 `validate(raw, *, batch_hash)`로 raw의 계약 해시를 재계산해 불일치면 `OOS_INPUT_MISMATCH`로 즉시 거부한다. 원본 바이트의 종류(공급자 응답 vs CSV 스냅샷)는 계약 필드로 기록되지 않고 해시로만 구분된다.
- **v1.2 채택 (03, 04)**: `CollectionMeta.raw_payload_kind`(기본 `unspecified`)를 추가한다. 검증기는 입력 시리즈의 계약 해시를 지문으로 쓰고, 불일치는 승인 단계에서 거절한다. 외부 소비자가 v1.1.0을 쓰면 호환성 확인이 필요하다.

## 3. 작업 중 발견·수정한 주요 결함

- **백테스터**: 포지션 크기·손절·목표 미반영, 청산 봉 수익률 소급 제외(같은 봉 누출), 수수료 부과 오류, 승패 집계 오류 → v3로 수정, 변조 테스트로 재확인.
- **OOS 검증**: train이 전체 데이터를 쓰던 누출, 단일 봉 변조 테스트가 청산 누출을 못 잡던 사각지대, `save_approved`가 항상 예외(`os.fdopen(fd, "close")`), 비균일 격자에서 인접 셀 누락, 기준전략과 전략의 평가 구간 불일치 → 수정·테스트.
- **승인 게이트**: 바인딩이 설정 해시만 증명하던 문제, 지문을 저장값으로 반환해 사후 변조가 통과하던 문제, OOS·안정성 리포트가 종목·게이트·전략·시각·데이터에 묶이지 않던 문제 → 모두 수정, 공격 시나리오 회귀 테스트.
- **수집기**: 장중 미확정 봉이 CSV에 영구 잔존, 캐시 읽기 직후 품질 게이트 없음, Naver 폴백이 기존 봉을 덮어쓰는 구조, naive `datetime.now()`, 스레드 비보호 오류 기록 → 수정, 패치 전 코드에서 6개 테스트가 실패함을 확인.
- **봉 필드 정렬**: list/tuple 시퀀스가 잘리지 않고 정렬이 어긋나던 문제 → 명시적 `TIMED_FIELDS` 계약.
- **계약 경로**: ZIP 안의 `wave_contracts_ext`가 재구성본이어서 "39/39 통과"가 원본을 대변하지 못함, 검증기 지문과 배치 해시의 정의 불일치 → 원본 기준 재검증, `batch_hash` 재계산으로 해결(02).
- **테스트 자체의 결함**: 월요일/주말에 `bdate_range`가 299봉을 만들어 22개가 실패하던 요일 의존 → 수정(`BDay().rollback`) + 회귀 테스트.

## 4. 미해결 · 결정 필요

1. 기준 계약 결정: v1.1 유지 vs v1.2 채택.
2. ~~엔진이 호출자가 준 지문 문자열을 믿는다~~ → **02에서 수정 완료**: `evaluate(..., batch=)`로 재계산, 구 인자는 TypeError, 배치 내부 정합성 교차 검증(11개 부정 테스트, 훼손 4종으로 검출력 확인). **03의 엔진은 여전히 문자열을 받는다**(미수정). 한계: 수집 계약(RawStore/RevisionStore) 없이 통째로 위조한 배치는 엔진이 막지 못한다 — 지문의 최종 보증은 수집 계약의 불변성이다.
3. ZIP 계열 승인 엔진은 시계 오차 허용이 0이다(리포트 `created_at`이 `now`보다 미래이면 거절). `01`의 `approval_engine_bound.py`는 5분 허용.
4. 데이터 수집과 봉 확정 판정의 중복: `get_ohlcv`를 `ConfirmedDataCollector` 뒤 소스 어댑터로 재편성하는 것이 구조상 바람직하나 미착수.
5. **실환경 검증**: 기존 감시 프로그램에서 shadow 모니터를 실제로 구동하고, 실제 관측 로그를 진단 도구로 확인하는 작업은 사용자 환경에서만 가능하다(미수행).
6. 마스터 지시문 v12 갱신본: 기준선(v11-1) 본문이 없어 적용하지 않았다.

## 5. 검증되지 않은 것 (한계)

- 실제 pykrx·KIS·공공데이터포털·Naver API 연동(네트워크 차단). "pykrx가 장중에 당일 임시 봉을 돌려준다"는 가정은 스텁 기준.
- 실데이터 OOS 성능. 현재 전략은 종목-연당 약 4~6건 거래하여 보정기·OOS 검증에 필요한 표본(수백 건)에 한참 못 미친다. `UNVERIFIED`가 정상 동작이다.
- 02·03의 `position_confidence.py`, `wave_analysis/`는 **스텁**(보정기는 항상 p=0.8, 백테스터는 가격 변화만 계산). 이 폴더들의 통과는 계약·OOS·승인 배선 검증이다. 실제 전략·보정기 검증은 01(실구현)에서만 합성 데이터로 수행했다.
- 슬리피지 미모델링, `MarketData`에 OHLC 없음(장중 손절/목표 체결 순서 모델링 불가), 거래소 휴장일 미모델링, 캐시 치유가 파일 수정 시각에 의존.
- 지문·해시는 일관성 검사이며 서명이 아니다. 값을 위조해 만든 리포트는 막지 못한다.

## 6. 실행 방법

    # 01 (pytest 불필요)
    cd 01_wave_trading_verified && pip install -r requirements.txt && python run_tests.py
    # 02, 03 (pytest가 있으면)
    cd 02_oos_project_v11_compat && python -m pytest -q
    # pytest가 없으면
    cd 02_oos_project_v11_compat && PYTHONPATH=../05_tools/pytest_shim python ../05_tools/run_all.py test_contract_cases test_oos_validation test_approval_engine_oos_integration test_ohlcv_approval_integration test_batch_lineage_integration

`MANIFEST_SHA256.txt`로 파일 무결성을 확인할 수 있다 (`sha256sum -c MANIFEST_SHA256.txt`).
