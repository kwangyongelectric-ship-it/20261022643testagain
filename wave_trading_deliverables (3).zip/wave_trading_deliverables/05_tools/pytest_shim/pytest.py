"""최소 pytest shim: pytest.raises(exc, match=...) 만 지원(네트워크 차단으로 pytest 설치 불가)."""
import re
class _R:
    def __init__(s, exc, match=None): s.exc, s.match = exc, match
    def __enter__(s): return s
    def __exit__(s, t, v, tb):
        if t is None: raise AssertionError(f"DID NOT RAISE {s.exc}")
        if not issubclass(t, s.exc): return False
        if s.match and not re.search(s.match, str(v)): raise AssertionError(f"{v!r} does not match {s.match!r}")
        return True
def raises(exc, match=None): return _R(exc, match)
