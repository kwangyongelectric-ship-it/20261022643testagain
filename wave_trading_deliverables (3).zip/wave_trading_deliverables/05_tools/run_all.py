import importlib, inspect, sys, unittest, os
sys.path.insert(0, os.getcwd())
tot_p = tot_f = tot_e = 0
for name in sys.argv[1:]:
    m = importlib.import_module(name); p = f = 0
    for k, fn in sorted(vars(m).items()):
        if k.startswith("test_") and inspect.isfunction(fn):
            try: fn(); p += 1
            except Exception as e: f += 1; print(f"  FAIL {name}.{k}: {type(e).__name__}: {str(e)[:100]}")
    for k, cls in sorted(vars(m).items()):
        if inspect.isclass(cls) and issubclass(cls, unittest.TestCase) and cls.__module__ == m.__name__:
            res = unittest.TextTestRunner(stream=open(os.devnull, "w")).run(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
            bad = len(res.failures) + len(res.errors); p += res.testsRun - bad; f += bad
            for t, tb in res.failures + res.errors: print(f"  FAIL {name}.{t.id().split('.')[-1]}: {tb.strip().splitlines()[-1][:100]}")
    print(f"{name}: passed={p} failed={f}"); tot_p += p; tot_f += f
print(f"합계: passed={tot_p} failed={tot_f}")
