# OOS + ApprovalEngine integration bundle

Files:
- oos_validation_fixed.py: OOS validator, stability analyzer, atomic result store.
- test_oos_validation.py: OOS/store/stability tests, including embargo >= algorithm window.
- approval_engine_oos_integrated.py: ApprovalEngine requires typed, fresh OOS and stability reports bound to the recommendation and gate.
- test_approval_engine_oos_integration.py: approval gate smoke tests.
- wave_contracts_ext.py: shared collection, hashing, provenance, credential, and hard-reject contracts.
- data_collection_v2.py and revision_store.py: canonical module names copied into this isolated worktree.
- data_collector_ohlcv_fix1.py: `dataframe_to_collected_batch()` maps collector frames into the contract.
- test_ohlcv_approval_integration.py: collector-to-approval regression cases.

Validation status:
- No test results are assumed or pre-recorded; run `python -m pytest -q` from this isolated directory.
- The included `wave_analysis` package is a minimal compatibility stub, not the production strategy/backtester. Stub-based tests validate plumbing and gate behavior only.
- Before deployment, run these tests against the actual `wave_analysis` module and verify that the strategy's fee, execution timing, trade-count semantics, and return metrics match the baseline assumptions.
- `OOSValidator.validate()` now fails closed if `algorithm.window_size` is missing/non-positive or `embargo_bars < window_size`.

## DataFrame-to-contract boundary

Call `dataframe_to_collected_batch()` with the collector's DataFrame, its provider name,
and an explicit `confirmed_through` boundary. Rows later than the boundary are recorded
as unconfirmed and excluded; a bar whose timestamp equals the boundary is included.
Pass provider-native `raw_bytes` when available. Its bytes are hashed as the raw content.
If omitted, the contract stores a CSV snapshot marked `dataframe_csv_snapshot` rather
than claiming it is the provider's native response. The normalized hash independently
covers canonical close, volume, and timestamp values; it is not the hash of the raw payload.

## Approval evidence binding

`ApprovalEngine.evaluate()` requires `current_data_fingerprint` when OOS reports are
provided. It must identify the exact data snapshot used for the current recommendation
and must equal both reports' `data_fingerprint`. The engine also rejects symbol or
strategy-version mismatches, a gate that differs from the configured expected gate,
and OOS or stability reports older than `max_oos_age`.

## OOS report binding

- Configure `OOSValidator(strategy_version=...)` and pass the same version to `ApprovalEngine`.
- Analyze the gate grid with the OOS report's `data_fingerprint` and strategy version. Missing metadata is rejected by the approval gate:

```python
oos_report = validator.validate(raw)
stability_report = analyzer.analyze(
	train_grid,
	symbol=raw.symbol,
	strategy_version=oos_report.strategy_version,
	data_fingerprint=oos_report.data_fingerprint,
)
engine = ApprovalEngine(
	calibrator,
	validation,
	strategy_version=oos_report.strategy_version,
	expected_gate=oos_report.frozen_gate,
)
```

- Approval rejects non-bundle report objects, mismatched symbols/versions/gates/data fingerprints, missing grid fingerprints, and OOS reports older than seven days by default.
