import logging
import os
import time
from datetime import datetime, timedelta
from typing import Optional

import numpy as np
import pandas as pd
import requests

from data_collection_v2 import DataSourceError, to_collected_batch as build_collected_batch
from wave_contracts_ext import CollectedBatch

# --- 버그 #1 수정: 구조화 로거 (print → logging) ------------------------
logger = logging.getLogger("data_collector")

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)

COLUMNS_MAP = {
    "시가": "Open",
    "고가": "High",
    "저가": "Low",
    "종가": "Close",
    "거래량": "Volume",
    "open": "Open",
    "high": "High",
    "low": "Low",
    "close": "Close",
    "volume": "Volume",
}

REQUIRED_COLUMNS = ["Open", "High", "Low", "Close", "Volume"]

# --- 버그 #1 수정: 품질 게이트 기준 (제안값 — 최종 승인 전까지 조정 가능) ---
# MIN_ROWS_RATIO: 요청 구간의 예상 거래일(영업일) 수 대비 최소 확보 비율.
#   근거: pykrx/Naver는 영업일 기준 일봉을 반환하므로, 예상 영업일의 절반도
#   못 받았다면 해당 공급자의 응답을 신뢰할 수 없다고 판정.
MIN_ROWS_RATIO = 0.5
# MAX_MISSING_RATIO: OHLCV 값 결측(NaN) 허용 비율 상한.
#   근거: 정상 수집된 일봉은 결측이 발생하지 않음. 일부 결측은 허용하되
#   5% 초과 시 불량 데이터로 판정해 폴백. (제안값 — 실데이터 검증 후 확정)
MAX_MISSING_RATIO = 0.05

# --- 버그 #1 수정: 공급자별 실패 기록 (호출자가 프로그램적으로 확인 가능) ---
_last_collection_errors = []


def get_last_collection_errors():
    """최근 get_ohlcv 호출에서 발생한 공급자별 오류 목록 반환.

    각 항목: {"source": 공급자명, "exc_type": 예외 유형, "message": 내용}
    get_ohlcv()는 기존 호환성을 위해 빈 DataFrame 반환을 유지하므로,
    호출자는 반환값이 비어 있을 때 이 함수로 원인을 확인한다.
    """
    return list(_last_collection_errors)


def _record_error(source, exc, message=""):
    entry = {
        "source": source,
        "exc_type": type(exc).__name__ if exc is not None else None,
        "message": str(exc) if exc is not None else message,
    }
    _last_collection_errors.append(entry)
    logger.error(
        "source=%s exc_type=%s message=%s",
        entry["source"], entry["exc_type"], entry["message"],
    )


def validate_ohlcv(df, min_rows=1, max_missing_ratio=MAX_MISSING_RATIO):
    """품질 게이트: 행 수·필수 컬럼·결측률 검증.

    반환: (통과여부, 사유문자열) — 통과 시 (True, "")
    """
    if df is None or df.empty:
        return False, "empty dataframe"
    if len(df) < min_rows:
        return False, f"row count {len(df)} < min_rows {min_rows}"
    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            return False, f"missing required column: {col}"
    missing = df[REQUIRED_COLUMNS].isna()
    if not missing.values.any():
        return True, ""
    ratio = missing.values.sum() / missing.values.size
    if ratio > max_missing_ratio:
        return False, f"missing ratio {ratio:.3f} > {max_missing_ratio}"
    return True, ""


def normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    if not isinstance(df.index, pd.DatetimeIndex):
        if "Date" in df.columns or "날짜" in df.columns:
            date_col = "Date" if "Date" in df.columns else "날짜"
            df["Date"] = pd.to_datetime(df[date_col])
            df.set_index('Date', inplace=True)
        else:
            df.index = pd.to_datetime(df.index)
    df = df.rename(columns=COLUMNS_MAP)
    required_cols = ["Open", "High", "Low", "Close", "Volume"]
    for col in required_cols:
        if col not in df.columns:
            df[col] = np.nan
    df = df[required_cols].copy()
    df.index = pd.to_datetime(df.index).astype("datetime64[ns]")
    df.sort_index(inplace=True)
    return df


def dataframe_to_collected_batch(
    df: pd.DataFrame,
    ticker: str,
    *,
    provider: str,
    confirmed_through: datetime,
    timeframe: str = "1d",
    source_id: Optional[str] = None,
    raw_bytes: Optional[bytes] = None,
) -> CollectedBatch:
    """Convert the collector's OHLCV frame into a provenance-bearing batch.

    `confirmed_through` is mandatory: rows after that instant are recorded as
    unconfirmed and excluded. If provider-native bytes are unavailable, the
    raw payload is an explicit CSV snapshot of the returned DataFrame.
    """
    if not isinstance(df, pd.DataFrame) or df.empty:
        raise DataSourceError("empty dataframe")
    if not isinstance(provider, str) or not provider.strip():
        raise DataSourceError("provider is required")
    if confirmed_through is None:
        raise DataSourceError("confirmed_through is required")

    d = df.copy()
    try:
        date_column = next((column for column in ("Date", "date", "날짜")
                            if column in d.columns), None)
        if date_column is not None:
            d.index = pd.to_datetime(d.pop(date_column), errors="raise")
        d = d.rename(columns=COLUMNS_MAP)
        if "Close" not in d.columns or "Volume" not in d.columns:
            raise DataSourceError("dataframe must contain Close and Volume columns")
        timestamps = pd.DatetimeIndex(pd.to_datetime(d.index, errors="raise"))
        if timestamps.tz is None:
            timestamps = timestamps.tz_localize("UTC")
        else:
            timestamps = timestamps.tz_convert("UTC")
        cutoff = pd.Timestamp(confirmed_through)
        if pd.isna(cutoff):
            raise ValueError("confirmed_through is NaT")
        cutoff = cutoff.tz_localize("UTC") if cutoff.tzinfo is None else cutoff.tz_convert("UTC")
    except (TypeError, ValueError, OverflowError) as exc:
        raise DataSourceError("invalid timestamp or confirmation boundary") from exc
    if cutoff > pd.Timestamp.now(tz="UTC"):
        raise DataSourceError("confirmed_through cannot be in the future")

    d.index = timestamps
    unconfirmed = d.index > cutoff
    dropped_unconfirmed = [
        {"timestamp": timestamp.isoformat(), "reason": "unconfirmed bar"}
        for timestamp in d.index[unconfirmed]
    ]
    confirmed = d.loc[~unconfirmed, ["Close", "Volume"]].rename(
        columns={"Close": "close", "Volume": "volume"})
    if confirmed.empty:
        raise DataSourceError("no confirmed bars available")

    payload = raw_bytes
    raw_payload_kind = "provider_response"
    if payload is None:
        payload = df.to_csv(
            index=True, date_format="%Y-%m-%dT%H:%M:%S.%f%z", lineterminator="\n"
        ).encode("utf-8")
        raw_payload_kind = "dataframe_csv_snapshot"
    if not isinstance(payload, bytes):
        raise TypeError("raw_bytes must be bytes")

    batch = build_collected_batch(
        ticker, timeframe, confirmed, provider=provider, raw_bytes=payload,
        source_id=source_id or f"{provider}:{ticker}",
        data_basis_time=cutoff.to_pydatetime(),
        raw_payload_kind=raw_payload_kind,
    )
    batch.meta.raw_rows = len(df)
    batch.meta.dropped.extend(dropped_unconfirmed)
    return batch


def fetch_from_pykrx(ticker: str, start_date: str, end_date: str) -> pd.DataFrame:
    try:
        from pykrx import stock

        if ticker.startswith("^") or ticker == "KS11":
            df = stock.get_index_ohlcv_by_date(start_date, end_date, "1001")
        else:
            df = stock.get_market_ohlcv_by_date(start_date, end_date, ticker)
        return normalize_dataframe(df)
    except Exception as e:
        # 버그 #1 수정: PyKRX 예외 원인을 구조화 로그로 보존
        _record_error("pykrx", e, f"PYKRX 수집 실패 ({ticker})")
        return pd.DataFrame()


def fetch_from_naver(ticker: str, pages: int = 10) -> pd.DataFrame:
    try:
        symbol = "KOSPI" if ticker in ["KS11", "^KS11", "1001"] else ticker
        url = f"https://fchart.stock.naver.com/sise.nhn?symbol={symbol}&requestType=0&count=500&timeframe=day"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code != 200:
            _record_error(
                "naver", None,
                f"Naver HTTP status {response.status_code} ({ticker})",
            )
            return pd.DataFrame()
        import xml.etree.ElementTree as ET
        root = ET.fromstring(response.text)
        data = []
        for item in root.findall('.//item'):
            vals = item.get("data").split("|")
            data.append({
                "Date": vals[0],
                "Open": float(vals[1]),
                "High": float(vals[2]),
                "Low": float(vals[3]),
                "Close": float(vals[4]),
                "Volume": float(vals[5]),
            })
        df = pd.DataFrame(data)
        df["Date"] = pd.to_datetime(df["Date"])
        df.set_index("Date", inplace=True)
        return normalize_dataframe(df)
    except Exception as e:
        # 버그 #1 수정: Naver 예외 원인을 구조화 로그로 보존
        _record_error("naver", e, f"Naver Finance 데이터 수집 실패 ({ticker})")
        return pd.DataFrame()


def get_ohlcv(
    ticker: str = "KS11", start_date: str = "20200101", force_update: bool = False
) -> pd.DataFrame:
    _last_collection_errors.clear()

    file_symbol = "ks11" if ticker in ["KS11", "^KS11", "1001"] else ticker
    file_path = os.path.join(DATA_DIR, f"{file_symbol}_daily.csv")
    today_str = datetime.now().strftime("%Y%m%d")

    # --- 버그 #1 수정: 요청 구간의 예상 영업일 수 기반 최소 행 수 산출 ---
    start_d = datetime.strptime(start_date, "%Y%m%d").date()
    end_d = datetime.strptime(today_str, "%Y%m%d").date()
    expected_days = int(np.busday_count(start_d, end_d))
    min_rows = max(1, int(expected_days * MIN_ROWS_RATIO))

    if os.path.exists(file_path) and not force_update:
        try:
            df_local = pd.read_csv(file_path, index_col=0)
            df_local = normalize_dataframe(df_local)
            last_date = df_local.index[-1].strftime("%Y%m%d")
            if last_date >= today_str:
                logger.info("[Cache Hit] 데이터 최신 : %s", file_path)
                return df_local
            else:
                logger.info(
                    "[Cache Partial] 데이터 업데이트 진행 (%s -> %s)",
                    last_date, today_str,
                )
                start_date = (
                    df_local.index[-1] + timedelta(days=1)
                ).strftime("%Y%m%d")
                # 증분 구간은 예상 영업일이 적으므로 최소 행 수를 재산출
                start_d = datetime.strptime(start_date, "%Y%m%d").date()
                expected_days = int(np.busday_count(start_d, end_d))
                min_rows = max(1, int(expected_days * MIN_ROWS_RATIO))
        except Exception as e:
            _record_error("local_csv", e, "로컬 CSV 로드 오류")
            logger.warning("[Warning] 로컬 CSV 로드 오류, 재수집 진행: %s", e)
            df_local = pd.DataFrame()
    else:
        df_local = pd.DataFrame()

    logger.info(
        "[Fetch] PyKRX 수집 시작 (%s: %s ~ %s)...", ticker, start_date, today_str
    )
    df_new = fetch_from_pykrx(ticker, start_date, today_str)

    # --- 버그 #1 수정: PyKRX 결과 품질 게이트 (실패 시 폴백) ---
    if not df_new.empty:
        ok, reason = validate_ohlcv(df_new, min_rows=min_rows)
        if not ok:
            _record_error("pykrx", None, f"quality gate fail: {reason}")
            df_new = pd.DataFrame()

    if df_new.empty:
        logger.info("[Fallback] Naver Finance 수집 전환 (%s)...", ticker)
        df_new = fetch_from_naver(ticker)

        # --- 버그 #1 수정: Naver 결과 품질 게이트 ---
        if not df_new.empty:
            ok, reason = validate_ohlcv(df_new, min_rows=min_rows)
            if not ok:
                _record_error("naver", None, f"quality gate fail: {reason}")
                df_new = pd.DataFrame()

    if not df_new.empty:
        if not df_local.empty:
            df_combined = pd.concat([df_local, df_new])
            df_combined = df_combined[~df_combined.index.duplicated(keep="last")]
        else:
            df_combined = df_new
        df_combined.to_csv(file_path)
        logger.info("[Saved] CSV 저장 완료: %s", file_path)
        return df_combined
    else:
        logger.error("[Fail] 데이터 수집 실패. 기존 캐시 반환")
        return df_local


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    ks11_df = get_ohlcv(ticker="KS11", start_date="20220101")
    print(f"KS11 Rows: {len(ks11_df)}")
    print(ks11_df.tail())
