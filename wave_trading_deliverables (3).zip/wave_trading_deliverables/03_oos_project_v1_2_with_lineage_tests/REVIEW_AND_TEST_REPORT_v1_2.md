# 수정·회귀 검증 보고서 — v1.2 계약 및 OOS 지문

## 변경 사항
1. `wave_contracts_ext.py`를 사용자가 승인한 `wave_contracts_ext_v1_2_proposal.py`로 교체했습니다. `CollectionMeta.raw_payload_kind`는 기본값 `unspecified`이며, 수집기가 구분하는 `provider_response` / `dataframe_csv_snapshot` provenance를 수용합니다.
2. `oos_validation_fixed.py`의 OOS 보고서 지문을 계약 모듈의 `normalized_content_hash`와 동일한 정규화 규칙으로 계산하도록 변경했습니다.
   - 지문 대상은 OOS 평가에 사용된 train/test 부분집합만이 아니라 `validate(raw)`에 전달된 전체 입력 데이터입니다.
   - 따라서 보고서의 `data_fingerprint`는 해당 입력이 수집 배치와 동일한 close/volume/timestamp 값을 포함할 때 `CollectedBatch.normalized_content_hash`와 비교할 수 있습니다.
   - `oos_data_fingerprint(train, test)`는 주어진 train/test 관측치에 대해 동일한 계약 해시 함수를 사용합니다. 단, embargo 때문에 원본 전체와 같다고 간주해서는 안 됩니다.
3. `test_oos_validation.py`에 실제 `OOSValidator.validate(raw)` 보고서의 지문이 계약 정규화 해시와 일치하는 회귀 검사를 추가했습니다.

## 검증
- 실행 명령: `python -m pytest -q`
- 결과: **62 passed, 14 subtests passed**
- 실행 위치: `isolated_oos_contract/`
- 테스트는 현재 프로젝트의 계약·OOS·승인·수집 변환 테스트 범위입니다. 실제 시장 데이터, 브로커 체결, 슬리피지, 세금 및 실전 수익성 검증은 포함하지 않습니다.

## 주의 / 한계
- `raw_payload_kind` 추가는 승인된 v1.2 제안 계약 변경입니다. 기존 v1.1.0을 사용하는 외부 소비자는 버전 호환성 확인이 필요합니다.
- OOS 지문은 전체 입력 `MarketData`를 식별합니다. 수집 배치와 OOS 입력이 서로 다른 바 또는 정규화 값을 갖는다면 해시 불일치는 올바른 거부 신호입니다.
- 이 수정은 시계 오차 허용 정책을 바꾸지 않았습니다. 미래 시각으로 기록된 보고서는 기존 stale 검사를 통과하지 못할 수 있습니다.
- 테스트 통과만으로 실제 전략·백테스터의 실거래 정확성이나 성능을 승인하지 않습니다.
