"""v1.2 ZIP용 계보 회귀 테스트: 검증기(OOSValidator.validate(raw))가 입력 시리즈의 계약 해시를 지문으로 쓰고,
승인 엔진이 현재 수집 배치의 normalized_content_hash와 직접 비교한다. 지문을 손으로 지정하지 않는다."""
from types import SimpleNamespace as NS
import numpy as np, pandas as pd

import oos_validation_fixed as ov
from approval_engine_oos_integrated import ApprovalEngine, ApprovedPosition, Rejection, verdict_for_reasons
from data_collector_ohlcv_fix1 import dataframe_to_collected_batch
from position_confidence import CalStatus
from wave_analysis import MarketData

GATE = ov.GateConfig(1.0, 60)
class _Alg: window_size = 20
class _Rec:
    def __init__(self, **k): pass
class _BT:
    def __init__(self, a, r): pass
    def run(self, t): return {"trades": 9, "sharpe": 9.0, "max_drawdown_pct": 0.0, "total_return_pct": 1.0}
class _Cal:
    state_fingerprint = "fp"
    def calibrate(self, raw): return NS(status=CalStatus.CALIBRATED, p=.8, p_lower=.7, bin_lo=.7, bin_hi=.9, reason="")
GRID = pd.DataFrame([{"min_risk_reward": rr, "min_signal_strength": ss, "score": 1.0 if (rr, ss) == (1.0, 60) else 0.9}
                     for rr in (0.8, 1.0, 1.2, 1.5) for ss in (40, 50, 60, 70)])

def frame(n=300, bump=None):
    idx = pd.bdate_range(end=pd.offsets.BDay().rollback(pd.Timestamp.now().normalize() - pd.Timedelta(days=1)), periods=n)   # 주말이면 직전 금요일
    c = 70000 * np.exp(np.cumsum(np.random.default_rng(3).normal(0, .01, n)))
    if bump is not None: c[bump] *= 1.001
    return pd.DataFrame({"Open": c, "High": c, "Low": c, "Close": c, "Volume": np.full(n, 1e5)}, index=idx)

def batch(df, upto=None):
    return dataframe_to_collected_batch(df, "005930", provider="pykrx", confirmed_through=(upto or df.index[-1]).to_pydatetime())

def md_df(df): return MarketData("005930", "1d", df.index, df["Close"].to_numpy(), df["Volume"].to_numpy())
def md_batch(b): return MarketData("005930", "1d", pd.to_datetime(b.timestamps, unit="s"), np.array(b.closes), np.array(b.volumes))

def reports(md):
    oos = ov.OOSValidator(lambda: _Alg(), _Rec, _BT, lambda tr: GATE, min_oos_trades=1, strategy_version="s1").validate(md)
    return oos, ov.GateStabilityAnalyzer().analyze(GRID, "005930", strategy_version="s1", data_fingerprint=oos.data_fingerprint)

def decide(oos, stab, b, current=None):
    now = pd.Timestamp.now(tz="UTC")
    meta = NS(symbol="005930", last_bar_ts=pd.Timestamp(b.timestamps[-1], unit="s", tz="UTC"), collected_at=pd.Timestamp(b.meta.received_at))
    val = NS(passed=True, reasons=[], validation_id="v", deployed_fingerprint="fp", calibrator_state_hash="fp",
             data_fingerprint="d", strategy_version="s1", train_window=("a", "b"))
    eng = ApprovalEngine(_Cal(), val, require_binding=False, strategy_version="s1", expected_gate=GATE)
    return eng.evaluate(NS(symbol="005930", direction="LONG", action="BUY", signal_strength=80),
                        signal_bar=meta.last_bar_ts, meta=meta, trust=NS(passed=True, reliability=.99), now=now,
                        oos_report=oos, stability_report=stab,
                        current_data_fingerprint=b.normalized_content_hash if current is None else current)

def codes(d): return {r.split(":")[0] for r in d.reasons}


def test_real_validator_fingerprint_equals_batch_hash_and_is_approved():
    b = batch(frame()); oos, stab = reports(md_batch(b))
    assert oos.data_fingerprint == b.normalized_content_hash == stab.data_fingerprint
    assert isinstance(decide(oos, stab, b), ApprovedPosition)

def test_deliberately_wrong_current_fingerprint_is_rejected():
    b = batch(frame()); oos, stab = reports(md_batch(b))
    d = decide(oos, stab, b, current="deadbeef" * 8)
    assert isinstance(d, Rejection) and {"OOS_DATA_FINGERPRINT_MISMATCH", "STABILITY_DATA_FINGERPRINT_MISMATCH"} <= codes(d)
    assert verdict_for_reasons(d.reasons) == "REVALIDATION_REQUIRED"

def test_data_revision_and_new_bar_require_revalidation():
    b = batch(frame()); oos, stab = reports(md_batch(b))
    for other in (batch(frame(bump=50)), batch(frame(n=301))):
        d = decide(oos, stab, other)
        assert isinstance(d, Rejection) and "OOS_DATA_FINGERPRINT_MISMATCH" in codes(d)
        assert verdict_for_reasons(d.reasons) == "REVALIDATION_REQUIRED"

def test_report_built_on_series_with_unconfirmed_bar_is_not_reusable_for_confirmed_batch():
    df = frame(); confirmed = batch(df, upto=df.index[-2])
    oos, stab = reports(md_df(df))                       # 미확정 봉을 포함해 검증
    assert isinstance(decide(oos, stab, confirmed), Rejection)
    oos2, stab2 = reports(md_batch(confirmed))           # 확정 배치 시리즈로 검증하면 승인
    assert isinstance(decide(oos2, stab2, confirmed), ApprovedPosition)


def test_frame_has_requested_length_on_any_weekday():
    """요일 의존 회귀: 월요일/주말에 실행해도 frame()은 정확히 요청한 봉 수를 만든다."""
    assert len(frame()) == 300 and len(frame(n=301)) == 301
