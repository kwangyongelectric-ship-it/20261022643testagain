"""
데이터 수집 모듈 (패키지 밖) — 출력 계약은 오직 MarketData
=========================================================

구조
    DataSource (추상)  ← 어댑터: YahooFinanceSource / PublicDataPortalSource / KisRestSource
    DataCollector      ← 소스 우선순위 + 폴백 + 정규화 + 다종목 수집

원칙
    - 파형 분석 패키지는 이 모듈을 import 하지 않는다. (의존 방향: 수집 → 계약)
    - 어떤 소스를 쓰든 결과는 정규화된 MarketData (오름차순, 중복/NaN 제거).
    - API 키는 코드에 넣지 않고 환경변수로 받는다.
        DATA_GO_KR_KEY, KIS_APP_KEY, KIS_APP_SECRET

의존성: pandas, numpy (필수) / yfinance, requests (사용하는 소스에 한해 지연 import)
"""

from __future__ import annotations

import os
import time
import logging
from abc import ABC, abstractmethod
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

# 계약 import: 실제 패키지 분리 시 첫 번째 줄로 교체
try:
    from wave_analysis.contracts import MarketData
except ImportError:  # 단일 파일 캔버스 환경
    from 파형_분석_패키지 import MarketData  # type: ignore  # 파일명에 맞게 수정

log = logging.getLogger("data_collection")


class DataSourceError(RuntimeError):
    """소스 한 곳의 수집 실패. DataCollector가 잡아서 다음 소스로 폴백한다."""


# ----------------------------------------------------------------
# 공통: DataFrame → MarketData 정규화
# ----------------------------------------------------------------
def to_market_data(symbol: str, timeframe: str, df: pd.DataFrame) -> MarketData:
    """
    df 필수 컬럼: date(또는 DatetimeIndex), close, volume
    정렬·중복 제거·NaN 제거·비양수 가격 제거를 여기서 한 번만 수행한다.
    """
    if df is None or df.empty:
        raise DataSourceError(f"{symbol}: 빈 응답")
    d = df.copy()
    if "date" in d.columns:
        d = d.set_index("date")
    d.index = pd.to_datetime(d.index)
    d["close"] = pd.to_numeric(d["close"], errors="coerce")
    d["volume"] = pd.to_numeric(d["volume"], errors="coerce").fillna(0.0)
    d = d.dropna(subset=["close"])
    d = d[d["close"] > 0]
    d = d[~d.index.duplicated(keep="last")].sort_index()
    if d.empty:
        raise DataSourceError(f"{symbol}: 정제 후 유효 데이터 없음")
    return MarketData(symbol, timeframe, pd.DatetimeIndex(d.index),
                      d["close"].to_numpy(), d["volume"].to_numpy())


def _default_range(days: int, end: Optional[date]) -> tuple[date, date]:
    end = end or date.today()
    return end - timedelta(days=days), end


# ----------------------------------------------------------------
# 추상 소스
# ----------------------------------------------------------------
class DataSource(ABC):
    name: str = "base"

    @abstractmethod
    def fetch(self, symbol: str, lookback_days: int = 365,
              end: Optional[date] = None) -> MarketData:
        """일봉 MarketData 반환. 실패 시 DataSourceError."""


# ----------------------------------------------------------------
# 1) Yahoo Finance (yfinance) — 해외/국내 공통, 무료, 지연 시세
# ----------------------------------------------------------------
class YahooFinanceSource(DataSource):
    name = "yfinance"

    def __init__(self, kr_suffix: str = ".KS"):
        """6자리 숫자 종목코드는 kr_suffix(.KS=코스피, .KQ=코스닥)를 붙여 조회."""
        self.kr_suffix = kr_suffix

    def _ticker(self, symbol: str) -> str:
        return symbol + self.kr_suffix if symbol.isdigit() and len(symbol) == 6 else symbol

    def fetch(self, symbol, lookback_days=365, end=None) -> MarketData:
        try:
            import yfinance as yf
        except ImportError as e:
            raise DataSourceError("yfinance 미설치 (pip install yfinance)") from e
        start, end_d = _default_range(lookback_days, end)
        try:
            df = yf.download(self._ticker(symbol), start=start.isoformat(),
                             end=(end_d + timedelta(days=1)).isoformat(),
                             interval="1d", auto_adjust=True, progress=False)
        except Exception as e:
            raise DataSourceError(f"{symbol}: yfinance 오류 {e}") from e
        if df is None or df.empty:
            raise DataSourceError(f"{symbol}: yfinance 응답 없음")
        if isinstance(df.columns, pd.MultiIndex):       # 최신 yfinance는 MultiIndex 반환
            df.columns = df.columns.get_level_values(0)
        out = pd.DataFrame({"close": df["Close"], "volume": df["Volume"]})
        return to_market_data(symbol, "1d", out)


# ----------------------------------------------------------------
# 2) 공공데이터포털 (금융위원회_주식시세정보) — 일봉, 전일 기준 지연
# ----------------------------------------------------------------
class PublicDataPortalSource(DataSource):
    name = "data.go.kr"
    URL = "https://apis.data.go.kr/1160100/service/GetStockSecuritiesInfoService/getStockPriceInfo"

    def __init__(self, service_key: Optional[str] = None, page_size: int = 1000, timeout: int = 15):
        self.key = service_key or os.getenv("DATA_GO_KR_KEY")
        self.page_size = page_size
        self.timeout = timeout

    @staticmethod
    def parse(payload: Dict[str, Any]) -> pd.DataFrame:
        """응답 JSON → DataFrame(date, close, volume). item이 1건이면 dict로 오는 점 처리."""
        body = payload.get("response", {}).get("body", {})
        items = (body.get("items") or {})
        items = items.get("item", []) if isinstance(items, dict) else []
        if isinstance(items, dict):
            items = [items]
        return pd.DataFrame({
            "date": [pd.to_datetime(i["basDt"], format="%Y%m%d") for i in items],
            "close": [i["clpr"] for i in items],
            "volume": [i["trqu"] for i in items],
        })

    def fetch(self, symbol, lookback_days=365, end=None) -> MarketData:
        if not self.key:
            raise DataSourceError("DATA_GO_KR_KEY 미설정")
        try:
            import requests
        except ImportError as e:
            raise DataSourceError("requests 미설치") from e
        start, end_d = _default_range(lookback_days, end)
        frames, page = [], 1
        while True:
            params = {"serviceKey": self.key, "resultType": "json",
                      "numOfRows": self.page_size, "pageNo": page,
                      "likeSrtnCd": symbol,
                      "beginBasDt": start.strftime("%Y%m%d"),
                      "endBasDt": end_d.strftime("%Y%m%d")}
            try:
                r = requests.get(self.URL, params=params, timeout=self.timeout)
                r.raise_for_status()
                payload = r.json()
            except Exception as e:
                raise DataSourceError(f"{symbol}: data.go.kr 오류 {e}") from e
            df = self.parse(payload)
            frames.append(df)
            total = int(payload.get("response", {}).get("body", {}).get("totalCount", 0) or 0)
            if df.empty or page * self.page_size >= total:
                break
            page += 1
        return to_market_data(symbol, "1d", pd.concat(frames, ignore_index=True))


# ----------------------------------------------------------------
# 3) 한국투자증권 KIS Developers (REST) — 국내주식 기간별 일봉
#    ※ 엔드포인트/TR_ID는 KIS 공식 문서와 대조해 확인할 것 (변경 가능).
# ----------------------------------------------------------------
class KisRestSource(DataSource):
    name = "kis"
    REAL = "https://openapi.koreainvestment.com:9443"
    MOCK = "https://openapivts.koreainvestment.com:29443"
    PATH = "/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice"
    TR_ID = "FHKST03010100"
    MAX_ROWS = 100            # 1회 호출당 최대 행 수 → 구간을 나눠 반복 호출

    def __init__(self, app_key=None, app_secret=None, mock: bool = False,
                 call_interval: float = 0.25, timeout: int = 15):
        self.app_key = app_key or os.getenv("KIS_APP_KEY")
        self.app_secret = app_secret or os.getenv("KIS_APP_SECRET")
        self.base = self.MOCK if mock else self.REAL
        self.call_interval = call_interval     # 초당 호출 제한 대응
        self.timeout = timeout
        self._token: Optional[str] = None
        self._token_exp: datetime = datetime.min

    def _get_token(self, requests) -> str:
        if self._token and datetime.now() < self._token_exp:
            return self._token
        r = requests.post(f"{self.base}/oauth2/tokenP", timeout=self.timeout,
                          json={"grant_type": "client_credentials",
                                "appkey": self.app_key, "appsecret": self.app_secret})
        r.raise_for_status()
        j = r.json()
        self._token = j["access_token"]
        # 토큰은 발급 횟수 제한이 있으므로 만료 직전까지 재사용
        self._token_exp = datetime.now() + timedelta(seconds=int(j.get("expires_in", 3600)) - 60)
        return self._token

    @staticmethod
    def parse(payload: Dict[str, Any]) -> pd.DataFrame:
        rows = payload.get("output2") or []
        rows = [r for r in rows if r.get("stck_bsop_date")]
        return pd.DataFrame({
            "date": [pd.to_datetime(r["stck_bsop_date"], format="%Y%m%d") for r in rows],
            "close": [r["stck_clpr"] for r in rows],
            "volume": [r["acml_vol"] for r in rows],
        })

    def fetch(self, symbol, lookback_days=365, end=None) -> MarketData:
        if not (self.app_key and self.app_secret):
            raise DataSourceError("KIS_APP_KEY / KIS_APP_SECRET 미설정")
        try:
            import requests
        except ImportError as e:
            raise DataSourceError("requests 미설치") from e
        start, end_d = _default_range(lookback_days, end)
        frames, cursor = [], end_d
        try:
            token = self._get_token(requests)
            headers = {"authorization": f"Bearer {token}", "appkey": self.app_key,
                       "appsecret": self.app_secret, "tr_id": self.TR_ID, "custtype": "P"}
            while cursor >= start:
                params = {"FID_COND_MRKT_DIV_CODE": "J", "FID_INPUT_ISCD": symbol,
                          "FID_INPUT_DATE_1": start.strftime("%Y%m%d"),
                          "FID_INPUT_DATE_2": cursor.strftime("%Y%m%d"),
                          "FID_PERIOD_DIV_CODE": "D", "FID_ORG_ADJ_PRC": "0"}
                r = requests.get(self.base + self.PATH, headers=headers,
                                 params=params, timeout=self.timeout)
                r.raise_for_status()
                j = r.json()
                if j.get("rt_cd") not in (None, "0"):
                    raise DataSourceError(f"{symbol}: KIS 오류 {j.get('msg1')}")
                df = self.parse(j)
                if df.empty:
                    break
                frames.append(df)
                oldest = df["date"].min().date()
                if len(df) < self.MAX_ROWS or oldest <= start:
                    break
                cursor = oldest - timedelta(days=1)
                time.sleep(self.call_interval)
        except DataSourceError:
            raise
        except Exception as e:
            raise DataSourceError(f"{symbol}: KIS 통신 오류 {e}") from e
        if not frames:
            raise DataSourceError(f"{symbol}: KIS 응답 없음")
        return to_market_data(symbol, "1d", pd.concat(frames, ignore_index=True))


# ----------------------------------------------------------------
# 컬렉터: 우선순위 + 폴백 + 최소 길이 검증 + 다종목
# ----------------------------------------------------------------
class DataCollector:
    def __init__(self, sources: Sequence[DataSource], min_bars: int = 30):
        if not sources:
            raise ValueError("최소 1개의 DataSource가 필요합니다.")
        self.sources = list(sources)
        self.min_bars = min_bars          # 분석 window_size 이상으로 설정할 것

    def collect(self, symbol: str, lookback_days: int = 365,
                end: Optional[date] = None) -> MarketData:
        errors: List[str] = []
        for src in self.sources:
            try:
                md = src.fetch(symbol, lookback_days, end)
                if len(md.close) < self.min_bars:
                    raise DataSourceError(f"{symbol}: {len(md.close)}봉 < 최소 {self.min_bars}봉")
                log.info("%s ← %s (%d봉)", symbol, src.name, len(md.close))
                return md
            except DataSourceError as e:
                log.warning("%s 실패 [%s]: %s", symbol, src.name, e)
                errors.append(f"[{src.name}] {e}")
        raise DataSourceError(f"{symbol}: 모든 소스 실패 → " + " | ".join(errors))

    def collect_many(self, symbols: Sequence[str], lookback_days: int = 365,
                     end: Optional[date] = None) -> tuple[List[MarketData], Dict[str, str]]:
        """일부 종목이 실패해도 나머지는 계속 수집. (성공 목록, {종목: 실패사유}) 반환."""
        ok, failed = [], {}
        for s in symbols:
            try:
                ok.append(self.collect(s, lookback_days, end))
            except DataSourceError as e:
                failed[s] = str(e)
        return ok, failed


# ----------------------------------------------------------------
# 사용 예 (파형 분석 패키지와 연결)
# ----------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    collector = DataCollector([KisRestSource(), PublicDataPortalSource(), YahooFinanceSource()],
                              min_bars=30)
    raws, failed = collector.collect_many(["005930", "000660", "035420"], lookback_days=200)
    print(f"성공 {len(raws)}종목 / 실패 {failed}")

    # from wave_analysis.wave_analysis import WaveAnalysisAlgorithm
    # from wave_analysis.position_recommender import PositionRecommender
    # from wave_analysis.multi_symbol_analyzer import MultiSymbolAnalyzer
    # analyzer = MultiSymbolAnalyzer(WaveAnalysisAlgorithm(20), PositionRecommender())
    # print(analyzer.analyze_all(raws))
