import os, tempfile, numpy as np, pandas as pd
import oos_validation_fixed as ov
from wave_analysis import MarketData, WaveAnalysisAlgorithm, PositionRecommender, WaveBacktester

def _grid(best, vals=(0.9,)):
    rows=[{"min_risk_reward":rr,"min_signal_strength":ss,"score":1.0 if (rr,ss)==best else 0.9}
          for rr in (0.8,1.0,1.2,1.5) for ss in (40,50,60,70)]
    return pd.DataFrame(rows)

def test_save_approved_writes_and_clears_stale():
    d=tempfile.mkdtemp(); st=ov.AtomicResultStore(os.path.join(d,"signals_final.csv"))
    st.save_approved(pd.DataFrame({"a":[1]})); st.mark_stale("x")
    assert not os.path.exists(st.path) and os.path.exists(st.path+".STALE")
    st.save_approved(pd.DataFrame({"a":[2]}))
    assert pd.read_csv(st.path)["a"].tolist()==[2]
    assert not os.path.exists(st.path+".STALE") and not [f for f in os.listdir(d) if f.endswith(".tmp")]

def test_failed_write_keeps_previous_file_and_no_tmp():
    d=tempfile.mkdtemp(); st=ov.AtomicResultStore(os.path.join(d,"s.csv")); open(st.path,"w").write("old\n")
    class Bad:
        def to_csv(self,*a,**k): raise OSError("disk full")
    try: st.save_approved(Bad()); assert False
    except OSError: pass
    assert open(st.path).read()=="old\n" and not [f for f in os.listdir(d) if f.endswith(".tmp")]

def test_neighbors_on_nonuniform_grid():
    r=ov.GateStabilityAnalyzer().analyze(_grid((1.2,60)))
    assert r.plateau_ratio>0 and r.stable and not r.warnings          # 내부 최적점: 이웃 4개(R/R 1.0·1.5, S 50·70) 모두 반영
    # 이웃 점수가 모두 0.9인 plateau에서 1.5 이웃이 빠졌다면 유지율은 같아도 개수가 달라진다 → 경고문으로 개수 검증
    r2=ov.GateStabilityAnalyzer().analyze(_grid((1.5,70)))
    assert any("2개" in w for w in r2.warnings), r2.warnings

def test_boundary_optimum_is_not_stable():
    for corner in [(1.5,70),(0.8,40),(1.0,40)]:
        assert not ov.GateStabilityAnalyzer().analyze(_grid(corner)).stable, corner

def test_sharp_optimum_flagged():
    df=_grid((1.0,50)); df.loc[(df.min_risk_reward==1.2)&(df.min_signal_strength==50),"score"]=0.2
    r=ov.GateStabilityAnalyzer().analyze(df); assert r.sharp_optimum and not r.stable

def test_baseline_uses_same_bars_as_strategy():
    rng=np.random.default_rng(3); n=300
    c=70000*np.exp(np.cumsum(rng.normal(0.0004,0.013,n)))
    raw=MarketData("T","1d",pd.date_range("2025-01-01",periods=n,freq="D"),c,np.full(n,1e5))
    class Rec:
        def __init__(s,**k): pass
    class BT:
        def __init__(s,algo,rec): pass
        def run(s,test): return {"trades":9,"sharpe":9.0,"max_drawdown_pct":0.0,"total_return_pct":1.0}
    v=ov.OOSValidator(lambda: WaveAnalysisAlgorithm(window_size=20),Rec,BT,
                      lambda tr: ov.GateConfig(1.0,60),min_oos_trades=1)
    rep=v.validate(raw); _,test=ov.split_time_ordered(raw,0.7,20)
    exp=ov.buy_and_hold_baseline(MarketData("T","1d",test.timestamps[19:],test.close[19:],test.volume[19:]))
    assert abs(rep.baseline["total_return_pct"]-exp["total_return_pct"])<1e-9
    # 기준전략 구간 = 전략이 거래 가능한 구간(50개 수익률): close[19]→close[-1]
    assert abs(rep.baseline["total_return_pct"]-((test.close[-1]/test.close[19])*(1-0.00015)-1)*100)<1e-9

def test_select_gate_receives_only_train_data():
    seen={}
    def sel(train_raws): seen["last"]=train_raws[0].timestamps[-1]; return ov.GateConfig(1.0,60)
    rng=np.random.default_rng(1); n=300
    raw=MarketData("T","1d",pd.date_range("2025-01-01",periods=n,freq="D"),70000*np.exp(np.cumsum(rng.normal(0,.01,n))),np.full(n,1e5))
    ov.OOSValidator(lambda: WaveAnalysisAlgorithm(window_size=20),PositionRecommender,WaveBacktester,sel).validate(raw)
    assert seen["last"]==raw.timestamps[int(n*0.7)-1]

if __name__=="__main__":
    f=0
    for k,fn in sorted(globals().items()):
        if k.startswith("test_") and callable(fn):
            try: fn(); print("PASS",k)
            except Exception as e: f+=1; print("FAIL",k,type(e).__name__,str(e)[:80])
    raise SystemExit(1 if f else 0)
