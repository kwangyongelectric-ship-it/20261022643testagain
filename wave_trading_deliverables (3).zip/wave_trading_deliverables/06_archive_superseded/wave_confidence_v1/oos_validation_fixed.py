"""
oos_validation.py — Out-of-Sample 검증 및 게이트 안정성 분석
=============================================================

적용 기준 (요구 사양 그대로):
  1단계 OOS 검증
    - 시간순 분할: 과거 구간 = 최적화(train), 이후 구간 = 검증(test). 무작위 분할 금지.
    - 파라미터 동결: train에서 확정한 게이트로 test를 1회 평가. test 결과로 파라미터 수정 금지.
    - 누출 방지: train/test 경계에 embargo(≥ 분석 window_size)를 두어
      롤링 윈도우 겹침과 보유 포지션 경계 유입을 차단.
    - 비교 기준 고정: Buy&Hold 기준전략, 동일 수수료, 사전 확정 지표.
    - 실패도 결과로 기록: 거래 수 최소치 미달 / 기준 미달은 OOS_FAIL로 기록 (숨기지 않음).

  2단계 게이트 파라미터 안정성
    - 최상위 후보의 인접 파라미터 성과 일관성 확인.
    - 1그리드 스텝 이동 시 점수 급락 = 날카로운 최적점 → 경고 분류.
    - 단일 후보 성과보다 주변 후보 일관성(plateau)을 중시.

  3단계(준비) 원자적 결과 저장
    - 실패한 실행이 이전 signals_final.csv를 '최신 결과처럼' 남기지 않도록
      임시파일 기록 → 검증 게이트 → 원자적 rename, 실패 시 STALE 마킹.

연결 지점 (실제 리비전과 대조 필요 — 콜백으로 격리):
    select_gate(train_raws) -> GateConfig   ← RiskGateOptimizer 실제 인터페이스에 맞게 주입
    WaveBacktester(algorithm, recommender).run(raw) -> stats dict  ← 키 고정 가정
    PositionRecommender(min_risk_reward, min_signal_strength, target_volatility)

의존성: numpy, pandas
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

# 계약 import — 패키지 분리 시: from wave_analysis.contracts import MarketData
try:
    from wave_analysis.contracts import MarketData
except ImportError:
    from wave_analysis import MarketData  # type: ignore


# ================================================================
# 시간순 분할 + Embargo (누출 방지)
# ================================================================
def split_time_ordered(raw: MarketData, train_ratio: float = 0.7,
                       embargo_bars: int = 20) -> Tuple[MarketData, MarketData]:
    """
    과거 구간(train) → 이후 구간(test) 시간순 분할.

    embargo_bars >= 분석 window_size 여야 한다:
      - 롤링 분석은 직전 window_size 봉을 보므로, train 끝의 window_size-1봉은
        test 첫 정책의 입력이 될 수 있다 → 경계 embargo로 겹침 차단.
      - train 마지막 정책의 포지션이 경계를 넘어 test 수익률에 유입되지 않게
        test는 (경계 + embargo)부터 시작한다.
    """
    n = len(raw.close)
    if not 0.5 < train_ratio < 0.95:
        raise ValueError("train_ratio는 0.5~0.95 범위")
    cut = int(n * train_ratio)
    if embargo_bars < 0:
        raise ValueError("embargo_bars >= 0")
    start_test = cut + embargo_bars
    if cut < 2 or n - start_test < 2:
        raise ValueError(
            f"분할 불가: 전체 {n}봉, train {cut}봉, embargo {embargo_bars}봉 → "
            f"test {n - start_test}봉. 데이터를 더 확보하거나 embargo를 줄이세요(단 window_size 이상 유지).")

    def slice_md(a: int, b: int) -> MarketData:
        return MarketData(raw.symbol, raw.timeframe,
                          pd.DatetimeIndex(raw.timestamps[a:b]),
                          raw.close[a:b].copy(), raw.volume[a:b].copy())

    return slice_md(0, cut), slice_md(start_test, n)


# ================================================================
# 기준전략 (비교 기준 고정): Buy & Hold, 동일 수수료
# ================================================================
def buy_and_hold_baseline(raw: MarketData, fee: float = 0.00015) -> Dict[str, float]:
    """단 1회 진입 수수료만 반영한 Buy&Hold. 사전 확정 기준 — OOS 결과를 보고 수정 금지."""
    close = raw.close
    if len(close) < 2:
        raise ValueError("기준전략 계산에 2봉 이상 필요")
    total = (close[-1] / close[0]) * (1 - fee) - 1
    n = len(close) - 1
    ann = (1 + total) ** (252 / max(n, 1)) - 1
    rets = np.diff(close) / close[:-1]
    vol = float(np.std(rets) * np.sqrt(252))
    eq_rel = np.cumprod(1 + rets)
    peak = np.maximum.accumulate(eq_rel)
    mdd = float(np.max((peak - eq_rel) / peak))
    sharpe = ann / vol if vol > 0 else 0.0
    return {"total_return_pct": total * 100, "annualized_return_pct": ann * 100,
            "annualized_vol_pct": vol * 100, "sharpe": sharpe,
            "max_drawdown_pct": mdd * 100}


# ================================================================
# OOS 검증기
# ================================================================
@dataclass
class GateConfig:
    min_risk_reward: float
    min_signal_strength: int


@dataclass
class OOSReport:
    symbol: str
    verdict: str                      # OOS_PASS / OOS_FAIL
    frozen_gate: GateConfig           # test 평가에 사용된 동결 파라미터
    train_bars: int
    test_bars: int
    embargo_bars: int
    oos: Dict[str, Any]               # test 구간 전략 성과
    baseline: Dict[str, float]        # test 구간 Buy&Hold 기준
    failure_reasons: List[str] = field(default_factory=list)

    def to_dict(self): return asdict(self)


class OOSValidator:
    """
    사용법:
        select_gate 콜백에 실제 RiskGateOptimizer를 연결한다.
            def select_gate(train_raws):                      # train에서만 최적화
                best, grid = optimizer.optimize_on(train_raws)  # 실제 인터페이스에 맞게
                return best
        validator = OOSValidator(algorithm_factory, recommender_cls, backtester_cls, select_gate)
        report = validator.validate(raw)

    파라미터 동결: select_gate은 train_raws만 받는다 — test 데이터 접근 경로 자체가 없다.
    """
    def __init__(self,
                 algorithm_factory: Callable[[], Any],
                 recommender_cls: type,
                 backtester_cls: type,
                 select_gate: Callable[[List[MarketData]], GateConfig],
                 min_oos_trades: int = 5,
                 min_sharpe_vs_baseline: float = 0.0,     # 전략 Sharpe가 기준 Sharpe를 못 넘으면 실패
                 max_mdd_vs_baseline: float = 1.2,        # 전략 MDD가 기준 MDD의 1.2배 초과 시 실패
                 train_ratio: float = 0.7,
                 embargo_bars: int = 20):
        self.algorithm_factory = algorithm_factory
        self.recommender_cls = recommender_cls
        self.backtester_cls = backtester_cls
        self.select_gate = select_gate
        self.min_oos_trades = min_oos_trades
        self.min_sharpe_vs_baseline = min_sharpe_vs_baseline
        self.max_mdd_vs_baseline = max_mdd_vs_baseline
        self.train_ratio = train_ratio
        self.embargo_bars = embargo_bars

    def validate(self, raw: MarketData) -> OOSReport:
        train, test = split_time_ordered(raw, self.train_ratio, self.embargo_bars)

        # [train] 게이트 최적화 — 오직 train 구간으로만
        gate = self.select_gate([train])

        # [동결] test 재평가는 이 파라미터를 1회 사용. 이후 수정 금지.
        recommender = self.recommender_cls(min_risk_reward=gate.min_risk_reward,
                                           min_signal_strength=gate.min_signal_strength)
        algo = self.algorithm_factory()
        backtester = self.backtester_cls(algo, recommender)

        # [test] 평가 1회 + 고정 기준전략
        oos = backtester.run(test)
        warm = int(getattr(algo, "window_size", 0))           # 롤링 윈도우 워밍업: 이 구간은 전략이 거래할 수 없다
        base_raw = MarketData(test.symbol, test.timeframe, pd.DatetimeIndex(test.timestamps[max(warm - 1, 0):]),
                              test.close[max(warm - 1, 0):].copy(), test.volume[max(warm - 1, 0):].copy())
        baseline = buy_and_hold_baseline(base_raw)         # 전략과 같은 수익률 구간(close[warm-1]→끝)

        # [판정] 실패도 결과로 기록
        reasons: List[str] = []
        if oos["trades"] < self.min_oos_trades:
            reasons.append(f"OOS 거래 {oos['trades']}회 < 최소 {self.min_oos_trades}회 "
                           "(게이트가 신호를 사실상 차단 — 최적화 과적합 의심)")
        if oos["sharpe"] < baseline["sharpe"] + self.min_sharpe_vs_baseline:
            reasons.append(f"OOS Sharpe {oos['sharpe']:.2f} <= Buy&Hold {baseline['sharpe']:.2f} "
                           "(기준전략 대비 우위 없음)")
        if oos["max_drawdown_pct"] > baseline["max_drawdown_pct"] * self.max_mdd_vs_baseline:
            reasons.append(f"OOS MDD {oos['max_drawdown_pct']:.2f}% > "
                           f"Buy&Hold의 {self.max_mdd_vs_baseline:.1f}배 "
                           f"({baseline['max_drawdown_pct']:.2f}%) — 리스크 개선 없음")

        verdict = "OOS_PASS" if not reasons else "OOS_FAIL"
        if reasons:
            reasons.append("※ OOS 결과를 보고 파라미터를 수정하면 이 구간은 더 이상 순수 OOS가 아님 — "
                           "수정 시 미사용 미래 구간으로 재검증 필요")
        return OOSReport(symbol=raw.symbol, verdict=verdict, frozen_gate=gate,
                         train_bars=len(train.close), test_bars=len(test.close),
                         embargo_bars=self.embargo_bars,
                         oos=oos, baseline=baseline, failure_reasons=reasons)


# ================================================================
# 게이트 파라미터 안정성 분석
# ================================================================
@dataclass
class StabilityReport:
    symbol: str
    stable: bool
    best_gate: GateConfig
    best_score: float
    neighbor_mean_score: float
    neighbor_min_score: float
    plateau_ratio: float             # 인접 후보 중 최고점 대비 유지 비율
    sharp_optimum: bool               # 1스텝 이동 시 급락 여부
    warnings: List[str] = field(default_factory=list)

    def to_dict(self): return asdict(self)


class GateStabilityAnalyzer:
    """
    입력: RiskGateOptimizer가 반환한 그리드 결과 DataFrame
        (컬럼: min_risk_reward, min_signal_strength, score — stats 컬럼은 선택)

    판정:
      - best의 인접 셀(±1 스텝) 평균/최저 점수와 비교해 plateau 여부 판단.
      - 점수가 최고점 대비 retention_threshold 이하로 떨어지는 인접 셀이 있으면
        날카로운 최적점(sharp optimum)으로 경고.
      - 최적 후보 1개의 성과가 아니라 '주변 일관성'이 통과 기준.
    """
    def __init__(self, retention_threshold: float = 0.6):
        if not 0 < retention_threshold <= 1:
            raise ValueError("retention_threshold는 0~1")
        self.retention_threshold = retention_threshold

    def analyze(self, grid_df: pd.DataFrame, symbol: str = "?") -> StabilityReport:
        if grid_df.empty:
            raise ValueError("빈 그리드 결과")
        df = grid_df.sort_values("score", ascending=False).reset_index(drop=True)
        best = df.iloc[0]
        best_gate = GateConfig(float(best["min_risk_reward"]), int(best["min_signal_strength"]))

        rrs = sorted(df["min_risk_reward"].unique())
        sss = sorted(df["min_signal_strength"].unique())
        ri = int(np.argmin([abs(x - float(best["min_risk_reward"])) for x in rrs]))
        si = int(np.argmin([abs(x - float(best["min_signal_strength"])) for x in sss]))
        want_rr = {rrs[k] for k in (ri - 1, ri + 1) if 0 <= k < len(rrs)}
        want_ss = {sss[k] for k in (si - 1, si + 1) if 0 <= k < len(sss)}
        neighbors: List[pd.Series] = []
        for _, row in df.iterrows():
            same_rr = np.isclose(row["min_risk_reward"], best["min_risk_reward"])
            same_ss = row["min_signal_strength"] == best["min_signal_strength"]
            if same_ss and any(np.isclose(row["min_risk_reward"], x) for x in want_rr):
                neighbors.append(row)
            if same_rr and any(row["min_signal_strength"] == x for x in want_ss):
                neighbors.append(row)
        # 값이 둘 이상인 축에서 최적점이 끝에 있으면 경계 최적점(한쪽 이웃 없음)
        on_boundary = (len(rrs) > 1 and len(want_rr) < 2) or (len(sss) > 1 and len(want_ss) < 2)

        warnings: List[str] = []
        if not neighbors:
            warnings.append("인접 파라미터 없음 — 그리드 폭이 너무 좁음. 안정성 판정 불가")
            return StabilityReport(symbol, False, best_gate, float(best["score"]),
                                   0.0, 0.0, 0.0, False, warnings)

        scores = [float(n["score"]) for n in neighbors]
        n_mean, n_min = float(np.mean(scores)), float(np.min(scores))
        best_score = float(best["score"])
        retention = n_mean / best_score if best_score > 0 else 0.0
        sharp = n_min < best_score * self.retention_threshold

        if sharp:
            warnings.append(f"날카로운 최적점: 인접 파라미터 점수 {n_min:.3f}가 최고 {best_score:.3f}의 "
                            f"{self.retention_threshold:.0%} 미만 — 파라미터가 조금만 바뀌어도 성과 급락. "
                            "이 게이트는 과최적화되었을 가능성 높음, 채택 경고")
        elif retention < 0.8:
            warnings.append(f"인접 일관성 부족: 인접 평균 유지율 {retention:.0%} — 최적점 신뢰 주의")
        if len(neighbors) < 3:
            warnings.append(f"인접 후보 {len(neighbors)}개 — 최적점이 그리드 경계에 있음. "
                             "경계 최적점은 더 넓은 탐색으로 확인 필요")

        stable = (not sharp) and retention >= 0.8 and not on_boundary   # 경계 최적점은 안정으로 인정하지 않음
        return StabilityReport(symbol, stable, best_gate, best_score,
                               n_mean, n_min, round(retention, 3), sharp, warnings)


# ================================================================
# 원자적 결과 저장 (실패 실행이 최신 결과인 것처럼 남는 것 방지)
# ================================================================
class AtomicResultStore:
    """
    결과 파일은 반드시 원자적으로 갱신한다:
      1) 임시파일에 기록 → 2) 승인 게이트 통과 시에만 os.replace (원자적 rename)
      3) 게이트 실패/파이프라인 중단 시 기존 파일을 .STALE로 마킹 —
         이전 결과가 '최신'인 것처럼 보이는 사고를 원천 차단.
    """
    def __init__(self, path: str = "signals_final.csv"):
        self.path = path

    def save_approved(self, df: pd.DataFrame) -> str:
        dir_ = os.path.dirname(os.path.abspath(self.path)) or "."
        fd, tmp = tempfile.mkstemp(suffix=".tmp", dir=dir_)
        os.close(fd)                                   # 경로로만 쓰므로 핸들은 즉시 닫는다(Windows 포함)
        try:
            df.to_csv(tmp, index=False, encoding="utf-8-sig")
            with open(tmp, "rb") as f:
                os.fsync(f.fileno())                   # 디스크 반영 후에만 교체
            os.replace(tmp, self.path)                 # 원자적 rename: 반쪽짜리 파일 불가
        except Exception:
            if os.path.exists(tmp):
                os.remove(tmp)
            raise
        for stale in (self.path + ".STALE", self.path + ".STALE.reason.txt"):   # 최신 승인 결과와 STALE 공존 방지
            if os.path.exists(stale):
                os.remove(stale)
        return self.path

    def mark_stale(self, reason: str) -> Optional[str]:
        """실패한 실행 직후 호출: 이전 결과를 무효 표시."""
        if not os.path.exists(self.path):
            return None
        stale = self.path + ".STALE"
        os.replace(self.path, stale)
        with open(stale + ".reason.txt", "w", encoding="utf-8") as f:
            f.write(f"{pd.Timestamp.now()}: {reason}\n")
        return stale


# ================================================================
# 데모 (시뮬레이션 데이터로 전체 흐름 자가검증)
# ================================================================
if __name__ == "__main__":
    # — 실제 모듈 import —
    from wave_analysis import WaveAnalysisAlgorithm, PositionRecommender, WaveBacktester

    rng = np.random.default_rng(11)
    n = 300
    prices = 70000 * np.exp(np.cumsum(rng.normal(0.0004, 0.013, n)))
    raw = MarketData("005930", "1d",
                     pd.date_range(end=pd.Timestamp.now().normalize(), periods=n, freq="D"),
                     prices, rng.integers(1e5, 5e5, n).astype(float))

    # — 게이트 선택 콜백: 실제 RiskGateOptimizer 인터페이스에 맞게 교체할 지점 —
    def select_gate(train_raws: List[MarketData]) -> GateConfig:
        """연결 지점: 실제 리비전의 RiskGateOptimizer.optimize(...) 호출로 대체."""
        # 데모: train 구간만으로 소규모 그리드 서치
        algo = WaveAnalysisAlgorithm(window_size=20)
        rows = []
        for rr in (0.8, 1.0, 1.2, 1.5):
            for ss in (40, 50, 60, 70):
                bt = WaveBacktester(algo, PositionRecommender(min_risk_reward=rr, min_signal_strength=ss))
                stats = bt.run(train_raws[0])
                rows.append({"min_risk_reward": rr, "min_signal_strength": ss,
                             "sharpe": stats["sharpe"], "score": stats["sharpe"]})
        grid = pd.DataFrame(rows).sort_values("score", ascending=False).reset_index(drop=True)
        # 데모 OOS는 재귀 참조를 피하기 위해 글로벌에 그리드 저장 (안정성 분석 재사용)
        globals()["_demo_grid"] = grid
        return GateConfig(float(grid.iloc[0]["min_risk_reward"]),
                          int(grid.iloc[0]["min_signal_strength"]))

    validator = OOSValidator(
        algorithm_factory=lambda: WaveAnalysisAlgorithm(window_size=20),
        recommender_cls=PositionRecommender,
        backtester_cls=WaveBacktester,
        select_gate=select_gate,
        min_oos_trades=3,          # 데모 시뮬레이션에서는 기준 완화
        embargo_bars=20)

    print("=" * 70); print("[1] OOS 검증 (시간순 분할 + embargo 20봉 + 파라미터 동결)"); print("=" * 70)
    report = validator.validate(raw)
    r = report
    print(f"종목 {r.symbol} | train {r.train_bars}봉 / embargo {r.embargo_bars}봉 / test {r.test_bars}봉")
    print(f"동결 게이트: R/R>={r.frozen_gate.min_risk_reward}, Signal>={r.frozen_gate.min_signal_strength}")
    print(f"OOS  : 누적 {r.oos['total_return_pct']:+.2f}% | Sharpe {r.oos['sharpe']:.2f} | "
          f"MDD {r.oos['max_drawdown_pct']:.2f}% | 매매 {r.oos['trades']}회 | 승률 {r.oos['win_rate_pct']}%")
    print(f"기준 : 누적 {r.baseline['total_return_pct']:+.2f}% | Sharpe {r.baseline['sharpe']:.2f} | "
          f"MDD {r.baseline['max_drawdown_pct']:.2f}% (Buy&Hold, 동일 수수료)")
    print(f"판정 : {r.verdict}")
    for reason in r.failure_reasons:
        print(f"  - {reason}")

    print(); print("=" * 70); print("[2] 게이트 파라미터 안정성 분석"); print("=" * 70)
    stability = GateStabilityAnalyzer(retention_threshold=0.6).analyze(globals()["_demo_grid"], r.symbol)
    print(f"최고점: R/R>={stability.best_gate.min_risk_reward}, S>={stability.best_gate.min_signal_strength} "
          f"(score={stability.best_score:.3f})")
    print(f"인접 평균 유지율: {stability.plateau_ratio:.0%} / 인접 최저: {stability.neighbor_min_score:.3f} "
          f"/ 날카로운 최적점: {stability.sharp_optimum}")
    print(f"판정: {'안정' if stability.stable else '불안정'}")
    for w in stability.warnings:
        print(f"  - {w}")

    print(); print("=" * 70); print("[3] 원자적 결과 저장 (실패 실행 잔류 방지)"); print("=" * 70)
    store = AtomicResultStore("signals_final.csv")
    if r.verdict == "OOS_PASS" and stability.stable:
        store.save_approved(pd.DataFrame([report.to_dict()]))
        print("OOS 통과 + 게이트 안정 → signals_final.csv 원자적 저장 완료")
    else:
        stale = store.mark_stale(f"OOS={r.verdict}, stable={stability.stable} → 운영 미승인")
        print(f"운영 미승인 → 기존 결과 STALE 마킹: {stale}")
    print("\n운영 승인 조건: OOS_PASS && 안정성 stable && 신뢰도 검증 통과 (3단계 스케줄러의 승인 게이트)")