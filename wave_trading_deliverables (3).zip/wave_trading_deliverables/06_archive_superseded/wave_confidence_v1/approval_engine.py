"""
approval_engine.py — 승인 게이트 (엔진에서 강제)
================================================

규칙: '승인된 포지션 제안(ApprovedPosition)'은 이 엔진을 통과해야만 만들어진다.
  - 대시보드/주문 계층은 ApprovedPosition만 받는다. 직접 생성하면 PermissionError.
  - 아래 조건을 전부 만족해야 승인된다. 거절 사유는 단락 평가 없이 전부 모은다.

  1. 추천이 실행 가능한가(LONG/BUY)
  2. 신호가 '확정된 마지막 봉'에서 나왔는가 (미확정 봉 사용 금지)
  3. 데이터 신뢰도 검증(TrustReport) 통과
  4. 시간순 OOS 검증(ValidationReport) 통과
  5. 해당 점수 구간이 CALIBRATED (표본 부족/범위 밖이면 UNVERIFIED → 거절)
  6. 보정 확률 p가 하한 이상
  7. 수집 시각이 너무 오래되지 않았는가

Python에는 진짜 접근 제어가 없으므로 토큰 검사는 '실수 방지'이지 보안 경계가 아니다.
실제 주문 계층에서는 이 게이트의 출력만 입력으로 받도록 타입/인터페이스를 고정할 것.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any, List, Optional, Sequence, Union

import pandas as pd

from position_confidence import CalStatus, ConfidenceCalibrator, ValidationReport

_GATE_TOKEN = object()


@dataclass(frozen=True)
class ApprovedPosition:
    recommendation: Any
    calibrated_p: float
    p_lower: float
    support_range: tuple
    validation_id: str
    data_reliability: float
    signal_bar: pd.Timestamp
    collected_at: pd.Timestamp
    _token: object = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        if self._token is not _GATE_TOKEN:
            raise PermissionError("ApprovedPosition은 ApprovalEngine만 생성할 수 있습니다.")


@dataclass(frozen=True)
class Rejection:
    symbol: str
    reasons: tuple
    calibrated_p: Optional[float] = None


Decision = Union[ApprovedPosition, Rejection]


class ApprovalEngine:
    def __init__(self, calibrator: ConfidenceCalibrator,
                 validation: Optional[ValidationReport],
                 min_prob: float = 0.55,
                 max_collection_age: timedelta = timedelta(hours=12)):
        self.calibrator, self.validation = calibrator, validation
        self.min_prob, self.max_age = min_prob, max_collection_age

    def evaluate(self, rec, *, signal_bar, meta, trust, now) -> Decision:
        reasons: List[str] = []
        sym = getattr(rec, "symbol", getattr(meta, "symbol", "?"))

        # 1) 실행 가능성
        if not (getattr(rec, "direction", None) == "LONG" and getattr(rec, "action", None) == "BUY"):
            reasons.append("NOT_ACTIONABLE")

        # 2) 확정 봉
        sb = pd.Timestamp(signal_bar)
        if sb > meta.last_bar_ts:
            reasons.append("BAR_UNCONFIRMED: 신호 봉이 확정 봉보다 최신")
        elif sb < meta.last_bar_ts:
            reasons.append("STALE_SIGNAL_BAR: 신호 봉이 최신 확정 봉이 아님")

        # 3) 데이터 신뢰
        if trust is None or not trust.passed:
            reasons.append("DATA_UNTRUSTED")

        # 4) OOS 검증
        if self.validation is None:
            reasons.append("VALIDATION_MISSING")
        elif not self.validation.passed:
            reasons.append("VALIDATION_FAILED: " + "; ".join(self.validation.reasons))

        # 5) 보정 상태 / 6) 확률 하한
        cs = self.calibrator.calibrate(float(getattr(rec, "signal_strength", 0.0)) / 100.0)
        if cs.status is not CalStatus.CALIBRATED:
            reasons.append(f"CALIBRATION_UNVERIFIED: {cs.reason}")
        elif cs.p < self.min_prob:
            reasons.append(f"LOW_CONFIDENCE: p={cs.p:.3f} < {self.min_prob}")

        # 7) 수집 시각
        if pd.Timestamp(now) - meta.collected_at > self.max_age:
            reasons.append("STALE_COLLECTION")

        if reasons:
            return Rejection(sym, tuple(reasons), cs.p)
        return ApprovedPosition(
            recommendation=rec, calibrated_p=cs.p, p_lower=cs.p_lower,
            support_range=(cs.bin_lo, cs.bin_hi), validation_id=self.validation.validation_id,
            data_reliability=trust.reliability, signal_bar=sb, collected_at=meta.collected_at,
            _token=_GATE_TOKEN)
