"""
validation_dashboard.py — 표시 전용
===================================
이 모듈은 승인 여부를 판단하지 않는다. ApprovalEngine이 만든 결과(ApprovedPosition / Rejection)와
ValidationReport를 '보여주기만' 한다. approval_engine의 토큰/생성자에 접근하지 않는다.
"""
from __future__ import annotations

from typing import Sequence

import pandas as pd


def _f(x, nd=3):
    return "—" if x is None or (isinstance(x, float) and pd.isna(x)) else f"{x:.{nd}f}"


def render_validation(report) -> str:
    verdict = "통과" if report.passed else "실패"
    lines = [
        f"## OOS 검증 [{report.validation_id}] — {verdict}",
        f"- 거래 {report.n_trades} / OOS {report.n_oos} / 보정 적용 {report.n_covered} "
        f"(커버리지 {report.coverage:.0%}) / fold {report.folds}",
        "",
        "| 지표 | 원시 점수 | 보정 후 | 기저 승률 |",
        "|---|---|---|---|",
        f"| Brier | {_f(report.brier_raw)} | {_f(report.brier_cal)} | {_f(report.brier_base)} |",
        f"| ECE | {_f(report.ece_raw)} | {_f(report.ece_cal)} | — |",
        f"| Brier skill | — | {_f(report.skill)} | — |",
    ]
    if report.reasons:
        lines += ["", "실패 사유:"] + [f"- {r}" for r in report.reasons]
    return "\n".join(lines)


def decisions_frame(decisions: Sequence) -> pd.DataFrame:
    rows = []
    for d in decisions:
        if hasattr(d, "recommendation"):
            rec = d.recommendation
            rows.append({"symbol": getattr(rec, "symbol", "?"), "결과": "승인",
                         "p": d.calibrated_p, "p_하한": d.p_lower,
                         "신뢰도": d.data_reliability, "사유": ""})
        else:
            rows.append({"symbol": d.symbol, "결과": "거절", "p": d.calibrated_p,
                         "p_하한": None, "신뢰도": None, "사유": " | ".join(d.reasons)})
    return pd.DataFrame(rows)
