"""
position_confidence.py — 포지션 제안 신뢰도 보정 (모듈 B)
=========================================================

입력  : 원시 점수(signal_strength/100) 와 '거래 결과(순수익>0 여부)'
출력  : 보정 확률 p, 상태(CALIBRATED / UNVERIFIED), 시간순 OOS 검증 리포트

핵심 규칙
  1) 표본 검사 먼저: 점수 구간(bin)의 표본이 부족하면 인접 구간과 병합,
     그래도 부족하거나 데이터 범위 밖이면 UNVERIFIED (확률을 만들어 내지 않는다).
  2) 라벨 성숙(label maturity): 보정기는 as_of 시점에 '결과가 이미 확정된' 거래만 학습한다.
     (label_time <= as_of). 청산 전 거래의 결과를 쓰면 미래 누출이다.
  3) 검증은 시간순(expanding window) OOS. 무작위 분할을 쓰지 않는다.
  4) 승인은 이 모듈이 하지 않는다. 승인 강제는 approval_engine.py.

임계값(min_bin_samples, min_total, max_ece, min_skill 등)은 모두 '제안값'이다.
"""
from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional, Sequence

import numpy as np
import pandas as pd


class CalStatus(str, Enum):
    CALIBRATED = "CALIBRATED"
    UNVERIFIED = "UNVERIFIED"


@dataclass(frozen=True)
class TradeRecord:
    symbol: str
    decision_time: pd.Timestamp   # 결정에 사용된 마지막 종가의 시각(= 진입 판단 시점)
    label_time: pd.Timestamp      # 결과가 알려지는 시각(= 청산 판단 시점)
    score: float                  # 0~1 원시 점수
    outcome: int                  # 1: 비용 차감 후 수익, 0: 그 외


@dataclass(frozen=True)
class CalibratedScore:
    raw: float
    p: Optional[float]
    status: CalStatus
    reason: str = ""
    p_lower: Optional[float] = None       # Wilson 95% 하한 (보수적 판단용)
    bin_lo: Optional[float] = None
    bin_hi: Optional[float] = None
    n_support: int = 0


# ------------------------------------------------------------------
# 지표
# ------------------------------------------------------------------
def brier_score(p: np.ndarray, y: np.ndarray) -> float:
    return float(np.mean((np.asarray(p, float) - np.asarray(y, float)) ** 2))


def expected_calibration_error(p: np.ndarray, y: np.ndarray, n_bins: int = 10) -> float:
    p, y = np.asarray(p, float), np.asarray(y, float)
    b = np.minimum((np.clip(p, 0, 1) * n_bins).astype(int), n_bins - 1)
    ece = 0.0
    for j in range(n_bins):
        m = b == j
        if m.any():
            ece += abs(p[m].mean() - y[m].mean()) * m.sum() / len(p)
    return float(ece)


def wilson_lower(k: float, n: float, z: float = 1.96) -> float:
    if n <= 0:
        return 0.0
    ph = k / n
    d = 1 + z * z / n
    c = ph + z * z / (2 * n)
    r = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n))
    return max(0.0, (c - r) / d)


# ------------------------------------------------------------------
# 보정기
# ------------------------------------------------------------------
class ConfidenceCalibrator:
    def __init__(self, n_bins: int = 10, min_bin_samples: int = 30, min_total: int = 100):
        if min_total < min_bin_samples:
            raise ValueError("min_total >= min_bin_samples 이어야 합니다.")
        self.n_bins, self.min_bin_samples, self.min_total = n_bins, min_bin_samples, min_total
        self.as_of: Optional[pd.Timestamp] = None
        self.n_fit = 0
        self.fit_failure: str = "NOT_FITTED"
        self._groups: List[Dict] = []

    # 1) 표본 검사 → 인접 병합 → 단조(PAV) 보정
    def fit(self, trades: Sequence[TradeRecord], as_of: pd.Timestamp) -> "ConfidenceCalibrator":
        self.as_of = pd.Timestamp(as_of)
        usable = [t for t in trades if pd.Timestamp(t.label_time) <= self.as_of]   # 라벨 성숙
        self.n_fit, self._groups = len(usable), []
        if len(usable) < self.min_total:
            self.fit_failure = f"INSUFFICIENT_TOTAL: {len(usable)} < {self.min_total}"
            return self
        s = np.clip(np.array([t.score for t in usable], float), 0.0, 1.0)
        y = np.array([t.outcome for t in usable], float)
        b = np.minimum((s * self.n_bins).astype(int), self.n_bins - 1)
        n_b = np.bincount(b, minlength=self.n_bins)
        k_b = np.bincount(b, weights=y, minlength=self.n_bins)

        groups, cur = [], None
        for j in range(self.n_bins):
            if n_b[j] == 0:
                continue
            if cur is None:
                cur = {"lo": j, "hi": j, "n": float(n_b[j]), "k": float(k_b[j])}
            else:
                cur["hi"] = j
                cur["n"] += n_b[j]
                cur["k"] += k_b[j]
            if cur["n"] >= self.min_bin_samples:
                groups.append(cur)
                cur = None
        if cur is not None:                      # 꼬리 잔여분: 직전 그룹에 병합
            if groups:
                g = groups[-1]
                g["hi"], g["n"], g["k"] = cur["hi"], g["n"] + cur["n"], g["k"] + cur["k"]
            else:
                groups.append(cur)

        # PAV(pool adjacent violators): 점수가 높을수록 확률이 낮아지는 구간을 풀링
        blocks: List[Dict] = []
        for g in groups:
            blocks.append({"gs": [g], "n": g["n"], "k": g["k"]})
            while len(blocks) > 1 and blocks[-2]["k"] / blocks[-2]["n"] > blocks[-1]["k"] / blocks[-1]["n"]:
                b2 = blocks.pop()
                blocks[-1]["gs"] += b2["gs"]
                blocks[-1]["n"] += b2["n"]
                blocks[-1]["k"] += b2["k"]
        for blk in blocks:
            p = blk["k"] / blk["n"]
            for g in blk["gs"]:
                self._groups.append({
                    "lo": g["lo"], "hi": g["hi"], "p": p,
                    "p_lower": wilson_lower(blk["k"], blk["n"]), "n": int(blk["n"])})
        self.fit_failure = ""
        return self

    @property
    def fitted(self) -> bool:
        return bool(self._groups)

    def calibrate(self, raw_score: float) -> CalibratedScore:
        if not self.fitted:
            return CalibratedScore(raw_score, None, CalStatus.UNVERIFIED, self.fit_failure)
        s = float(np.clip(raw_score, 0.0, 1.0))
        j = min(int(s * self.n_bins), self.n_bins - 1)
        for g in self._groups:
            if g["lo"] <= j <= g["hi"]:
                return CalibratedScore(raw_score, g["p"], CalStatus.CALIBRATED, "",
                                       g["p_lower"], g["lo"] / self.n_bins,
                                       (g["hi"] + 1) / self.n_bins, g["n"])
        return CalibratedScore(raw_score, None, CalStatus.UNVERIFIED,
                               "OUT_OF_SUPPORT: 학습 데이터에 없는 점수 구간")


# ------------------------------------------------------------------
# 시간순 OOS 검증 (expanding window, 라벨 성숙 기준 purge)
# ------------------------------------------------------------------
@dataclass
class ValidationReport:
    passed: bool
    reasons: List[str]
    n_trades: int
    n_oos: int
    n_covered: int
    coverage: float
    brier_raw: Optional[float]
    ece_raw: Optional[float]
    brier_cal: Optional[float]
    ece_cal: Optional[float]
    brier_base: Optional[float]
    skill: Optional[float]               # 1 - Brier_cal / Brier_base  (기저 승률 대비 개선)
    folds: int
    validation_id: str
    oos_frame: pd.DataFrame = field(repr=False, default_factory=pd.DataFrame)


def validate_chronological(
    trades: Sequence[TradeRecord],
    make_calibrator: Callable[[], ConfidenceCalibrator] = ConfidenceCalibrator,
    n_folds: int = 4,
    initial_frac: float = 0.5,
    min_oos_covered: int = 60,
    max_ece: float = 0.10,
    min_skill: float = 0.0,
    ece_bins: int = 5,
) -> ValidationReport:
    """각 fold의 as_of = fold 첫 거래의 decision_time. 그 시점에 '이미 결과가 난' 거래만으로
    보정기를 학습하고 fold의 거래를 예측한다. 미래 fold는 과거 fold의 예측에 영향을 줄 수 없다."""
    ts = sorted(trades, key=lambda t: (t.decision_time, t.symbol))
    n = len(ts)
    rows = []
    if n >= 2:
        start = max(1, int(n * initial_frac))
        edges = np.linspace(start, n, n_folds + 1).astype(int)
        for f in range(n_folds):
            fold = ts[edges[f]:edges[f + 1]]
            if not fold:
                continue
            as_of = pd.Timestamp(fold[0].decision_time)
            cal = make_calibrator().fit(ts, as_of)
            matured = [t.outcome for t in ts if pd.Timestamp(t.label_time) <= as_of]
            base = float(np.mean(matured)) if matured else np.nan
            for t in fold:
                r = cal.calibrate(t.score)
                rows.append({"fold": f, "symbol": t.symbol, "decision_time": t.decision_time,
                             "raw": t.score, "y": t.outcome, "p": r.p if r.p is not None else np.nan,
                             "base": base, "status": r.status.value})
    df = pd.DataFrame(rows)
    vid = hashlib.sha256((str(n) + "|" + (str(df["decision_time"].max()) if len(df) else "")
                          + f"|{n_folds}|{initial_frac}").encode()).hexdigest()[:12]
    reasons: List[str] = []
    if df.empty:
        return ValidationReport(False, ["NO_OOS_DATA"], n, 0, 0, 0.0, None, None, None, None,
                                None, None, 0, vid, df)
    cov = df[df["p"].notna() & df["base"].notna()]
    coverage = len(cov) / len(df)
    out = dict(brier_raw=None, ece_raw=None, brier_cal=None, ece_cal=None, brier_base=None, skill=None)
    if len(cov):
        y = cov["y"].to_numpy(float)
        out["brier_raw"] = brier_score(cov["raw"], y)
        out["ece_raw"] = expected_calibration_error(cov["raw"], y, ece_bins)
        out["brier_cal"] = brier_score(cov["p"], y)
        out["ece_cal"] = expected_calibration_error(cov["p"], y, ece_bins)
        out["brier_base"] = brier_score(cov["base"], y)
        out["skill"] = (1 - out["brier_cal"] / out["brier_base"]) if out["brier_base"] > 0 else 0.0
    if len(cov) < min_oos_covered:
        reasons.append(f"INSUFFICIENT_OOS: 보정된 OOS 표본 {len(cov)} < {min_oos_covered}")
    else:
        if out["ece_cal"] > max_ece:
            reasons.append(f"ECE_TOO_HIGH: {out['ece_cal']:.3f} > {max_ece}")
        if out["skill"] <= min_skill:
            reasons.append(f"NO_SKILL: 기저 승률 대비 Brier 개선 {out['skill']:+.3f} <= {min_skill}")
    return ValidationReport(not reasons, reasons, n, len(df), len(cov), coverage,
                            folds=int(df["fold"].nunique()), validation_id=vid, oos_frame=df, **out)


# ------------------------------------------------------------------
# 백테스터 결과 → TradeRecord (결과가 확정된 거래만)
# ------------------------------------------------------------------
def extract_trades(raw, result: Dict, fee: float = 0.00015) -> List[TradeRecord]:
    """WaveBacktester.run() 결과의 decisions에서 종료된 거래만 추출한다.
    decisions[k]['index']=i 는 close[i-1]까지 보고 내린 결정이다.
    따라서 결정 시각 = timestamps[i-1], 진입/청산가 = close[i-1].
    진행 중(미청산) 거래는 라벨이 없으므로 제외한다."""
    close = np.asarray(raw.close, float)
    ts = pd.DatetimeIndex(raw.timestamps)
    trades: List[TradeRecord] = []
    open_t = None
    for d in result["decisions"]:
        i = int(d["index"])
        px, when = close[i - 1], ts[i - 1]
        if open_t is not None and d.get("exit_reason"):
            ret = px / open_t["px"] - 1.0 - 2.0 * fee
            trades.append(TradeRecord(raw.symbol, open_t["t"], when, open_t["score"], int(ret > 0)))
            open_t = None
        if open_t is None and float(d["position"]) > 0:
            open_t = {"px": px, "t": when, "score": float(d["signal_strength"]) / 100.0}
    return trades
