"""승인 엔진은 지문 문자열을 받지 않고, 현재 수집 배치(CollectedBatch)에서 계약 해시를 재계산한다.
지문의 최종 보증 위계: 수집 계약의 불변성(RawStore/RevisionStore, TC-1.x)이 배치를 보증하고,
엔진 재계산은 그 전제 위에서 '전달 오류와 사후 변조'를 잡는 계층이다.
(엔진은 배치를 만든 주체가 아니므로, 수집 계약을 거치지 않고 통째로 위조한 배치까지는 막지 못한다.)"""
import dataclasses
from types import SimpleNamespace as NS

import numpy as np, pandas as pd, pytest

import oos_validation_fixed as ov
from approval_engine_oos_integrated import ApprovalEngine, ApprovedPosition, Rejection, verdict_for_reasons
from test_batch_lineage_integration import (GATE, _Alg, _Rec, _PassBT, _Cal, GRID, frame, batch_of, md_of, validate, decide)


def codes(d): return {r.split(":")[0] for r in d.reasons}

def engine():
    val = NS(passed=True, reasons=[], validation_id="v", deployed_fingerprint="fp", calibrator_state_hash="fp",
             data_fingerprint="d", strategy_version="s1", train_window=("a", "b"))
    return ApprovalEngine(_Cal(), val, require_binding=False, strategy_version="s1", expected_gate=GATE)

_UNSET = object()

def evaluate_raw(oos, stab, meta_from, batch=_UNSET, **extra):
    """수집 메타는 meta_from(실제 수집 결과)에서 만들고, 엔진에 넘기는 batch는 따로 지정한다.
    batch를 생략하면 meta_from을 그대로 쓰고, batch=None이면 '미전달'을 뜻한다. 그 외 인자는 엔진에 그대로 전달(구 시그니처 검증용)."""
    now = pd.Timestamp.now(tz="UTC")
    meta = NS(symbol="005930", last_bar_ts=pd.Timestamp(meta_from.timestamps[-1], unit="s", tz="UTC"),
              collected_at=pd.Timestamp(meta_from.meta.received_at))
    kw = dict(extra)
    if batch is _UNSET: kw["batch"] = meta_from
    elif batch is not None: kw["batch"] = batch
    return engine().evaluate(NS(symbol="005930", direction="LONG", action="BUY", signal_strength=80),
                             signal_bar=meta.last_bar_ts, meta=meta, trust=NS(passed=True, reliability=.99), now=now,
                             oos_report=oos, stability_report=stab, **kw)


def base():
    old = batch_of(frame()); oos, stab = validate(md_of(old), old.normalized_content_hash)
    return old, oos, stab


# ---- 합의된 부정 테스트 1~3 (엔진이 배치에서 재계산해도 유지) ----
def test_1_report_built_on_another_series_is_not_reusable():
    old, oos, stab = base()
    other = batch_of(frame(bump=50))
    d = decide(oos, stab, other)
    assert isinstance(d, Rejection) and {"OOS_DATA_FINGERPRINT_MISMATCH", "STABILITY_DATA_FINGERPRINT_MISMATCH"} <= codes(d)

def test_2_revised_or_extended_batch_requires_revalidation():
    old, oos, stab = base()
    for other in (batch_of(frame(bump=50)), batch_of(frame(n=301))):
        d = decide(oos, stab, other)
        assert isinstance(d, Rejection) and verdict_for_reasons(d.reasons) == "REVALIDATION_REQUIRED"

def test_3_unconfirmed_series_report_is_rejected_for_confirmed_batch():
    df = frame(); confirmed = batch_of(df, confirmed_through=df.index[-2])
    full = ov.MarketData("005930", "1d", df.index, df["Close"].to_numpy(), df["Volume"].to_numpy()) if hasattr(ov, "MarketData") else None
    from wave_analysis import MarketData
    full = MarketData("005930", "1d", df.index, df["Close"].to_numpy(), df["Volume"].to_numpy())
    oos, stab = validate(full, ov.series_content_hash(full))             # 미확정 봉 포함 시리즈의 자기 지문으로 검증
    assert isinstance(decide(oos, stab, confirmed), Rejection)


# ---- 새 부정 테스트 4: 배치 내부 위조 ----
def test_4a_series_replaced_by_old_data_but_declared_hash_is_new():
    """시리즈를 낡은 데이터로 바꿔 리포트 지문과 맞췄지만, 배치가 선언한 해시는 새 배치 것 → 무결성 실패."""
    old, oos, stab = base()
    new = batch_of(frame(bump=50))
    forged = dataclasses.replace(new, closes=list(old.closes), volumes=list(old.volumes), timestamps=list(old.timestamps))
    d = decide(oos, stab, forged)
    assert isinstance(d, Rejection)
    assert "BATCH_INTEGRITY_FAILED" in codes(d)
    assert "OOS_DATA_FINGERPRINT_MISMATCH" not in codes(d)               # 재계산 지문은 리포트와 같다 → 무결성 검사만이 잡는다

def test_4b_new_series_with_stale_declared_hash_is_not_trusted():
    """실제 현재 데이터(새 시리즈)에 낡은 리포트와 같은 해시를 '선언'해 붙인 위조. 선언값을 믿으면 승인된다."""
    old, oos, stab = base()
    new = batch_of(frame(bump=50))
    forged = dataclasses.replace(new, normalized_content_hash=old.normalized_content_hash)
    d = decide(oos, stab, forged)
    assert isinstance(d, Rejection)
    assert {"OOS_DATA_FINGERPRINT_MISMATCH", "BATCH_INTEGRITY_FAILED"} <= codes(d)    # 재계산한 값이 새 데이터 지문

def test_4c_raw_bytes_changed_after_construction():
    old, oos, stab = base()
    old.raw_bytes = b"tampered"                                          # __post_init__ 이후 변조
    d = decide(oos, stab, old)
    assert isinstance(d, Rejection) and "BATCH_INTEGRITY_FAILED" in codes(d)

def test_4d_batch_meta_and_symbol_mismatch():
    old, oos, stab = base()
    shifted = dataclasses.replace(old, timestamps=[t - 86400 * 7 for t in old.timestamps])      # 마지막 봉이 수집 메타와 다름
    d = evaluate_raw(oos, stab, old, batch=shifted)
    assert isinstance(d, Rejection) and "BATCH_META_MISMATCH" in codes(d)
    wrong_symbol = dataclasses.replace(old, dataset_id="000660:1d")
    d = evaluate_raw(oos, stab, old, batch=wrong_symbol)
    assert isinstance(d, Rejection) and "BATCH_SYMBOL_MISMATCH" in codes(d)
    fewer = dataclasses.replace(old, meta=dataclasses.replace(old.meta, normalized_rows=old.meta.normalized_rows + 2))
    d = evaluate_raw(oos, stab, old, batch=fewer)
    assert isinstance(d, Rejection) and "BATCH_META_MISMATCH" in codes(d)

def test_4e_invalid_series_and_non_batch_objects_are_rejected_not_crashed():
    old, oos, stab = base()
    nan_batch = dataclasses.replace(old, closes=[float("nan")] + list(old.closes[1:]))
    assert "BATCH_INVALID" in codes(decide(oos, stab, nan_batch))
    d = evaluate_raw(oos, stab, old, batch=old.normalized_content_hash)       # 해시 문자열을 batch로 전달(문자열 불신)
    assert isinstance(d, Rejection) and "BATCH_INVALID" in codes(d)


# ---- 새 부정 테스트 5: 구 시그니처 차단 ----
def test_5_legacy_current_data_fingerprint_argument_is_removed():
    old, oos, stab = base()
    with pytest.raises(TypeError):
        evaluate_raw(oos, stab, old, current_data_fingerprint=old.normalized_content_hash)
    with pytest.raises(TypeError):
        evaluate_raw(oos, stab, old, batch=old, current_data_fingerprint=oos.data_fingerprint)

def test_6_missing_batch_is_fail_closed_and_unverified():
    old, oos, stab = base()
    d = evaluate_raw(oos, stab, old, batch=None)                              # batch 미전달
    assert isinstance(d, Rejection) and "CURRENT_BATCH_MISSING" in codes(d)
    assert verdict_for_reasons([r for r in d.reasons if r.startswith(("CURRENT_BATCH", "CURRENT_DATA"))]) == "UNVERIFIED"

def test_7_report_own_fingerprint_can_no_longer_be_used_as_current():
    """과거 갭: 다른 배치를 평가하면서 리포트 자신의 지문을 current로 넘기면 승인되던 경로가 사라졌다."""
    old, oos, stab = base()
    other = batch_of(frame(bump=50))
    assert isinstance(decide(oos, stab, other), Rejection)                    # 넘길 수 있는 것은 배치 객체뿐
    assert isinstance(decide(oos, stab, old), ApprovedPosition)               # 정상 경로는 그대로 승인
