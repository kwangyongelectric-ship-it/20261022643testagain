"""Smoke tests for OOS/stability integration into ApprovalEngine."""
from types import SimpleNamespace

import pandas as pd

from approval_engine_oos_integrated import ApprovalEngine, ApprovedPosition, Rejection, CalStatus, verdict_for_reasons
from oos_validation_fixed import GateConfig, OOSReport, StabilityReport


def _make_batch(symbol="X", last_epoch=1767225600, tweak=None):
    """계약 객체(CollectedBatch)를 직접 만든다. 마지막 봉 = 2026-01-01 UTC(픽스처의 last_bar_ts와 동일)."""
    from datetime import datetime, timezone
    from wave_contracts_ext import CollectedBatch, CollectionMeta, normalized_content_hash, raw_content_hash
    stamps = [last_epoch - 2 * 86400, last_epoch - 86400, last_epoch]
    closes = [100.0, 101.0, 102.5 if tweak is None else 102.5 + tweak]
    volumes = [10.0, 11.0, 12.0]
    raw = b"raw-" + symbol.encode()
    meta = CollectionMeta(source_id=f"t:{symbol}", provider="t",
                          data_basis_time=datetime.fromtimestamp(last_epoch, timezone.utc),
                          received_at=datetime.fromtimestamp(last_epoch, timezone.utc),
                          raw_rows=3, normalized_rows=3)
    return CollectedBatch(dataset_id=f"{symbol}:1d", raw_bytes=raw, raw_content_hash=raw_content_hash(raw),
                          normalized_content_hash=normalized_content_hash(closes, volumes, stamps),
                          meta=meta, closes=closes, volumes=volumes, timestamps=stamps)


BATCH = _make_batch()
CHANGED = _make_batch(tweak=0.5)          # 마지막 봉 종가 정정 → 해시가 달라진 현재 배치


class FakeCalibrator:
    state_fingerprint = "fp"

    def calibrate(self, raw):
        return SimpleNamespace(
            status=CalStatus.CALIBRATED, p=0.8, p_lower=0.7,
            bin_lo=0.7, bin_hi=0.9, reason=""
        )


def fixture():
    gate = GateConfig(1.0, 60)
    validation = SimpleNamespace(
        passed=True, reasons=[], validation_id="v",
        deployed_fingerprint="fp", calibrator_state_hash="fp",
        data_fingerprint="d", strategy_version="s", train_window=("a", "b")
    )
    engine = ApprovalEngine(
        FakeCalibrator(), validation, min_prob=0.55,
        require_binding=False, strategy_version="s", expected_gate=gate
    )
    rec = SimpleNamespace(symbol="X", direction="LONG", action="BUY", signal_strength=80)
    meta = SimpleNamespace(
        symbol="X",
        last_bar_ts=pd.Timestamp("2026-01-01T00:00:00Z"),
        collected_at=pd.Timestamp("2026-01-01T00:05:00Z"),
    )
    trust = SimpleNamespace(passed=True, reliability=0.99)
    now = pd.Timestamp("2026-01-01T00:06:00Z")
    return engine, rec, meta, trust, now, gate


def reports(gate, now, *, verdict="OOS_PASS", stable=True, symbol="X", fp=None,
            oos_created_at=None, stability_created_at=None, strategy_version="s"):
    fp = BATCH.normalized_content_hash if fp is None else fp
    oos = OOSReport(
        symbol=symbol, verdict=verdict, frozen_gate=gate,
        train_bars=200, test_bars=70, embargo_bars=20,
        oos={"trades": 9, "sharpe": 1.2}, baseline={"sharpe": 0.8},
        strategy_version=strategy_version,
        created_at=now if oos_created_at is None else oos_created_at,
        data_fingerprint=fp,
    )
    stability = StabilityReport(
        symbol=symbol, stable=stable, best_gate=gate, best_score=1.0,
        neighbor_mean_score=0.9, neighbor_min_score=0.85, plateau_ratio=0.9,
        sharp_optimum=False, strategy_version=strategy_version,
        created_at=now if stability_created_at is None else stability_created_at,
        data_fingerprint=fp, grid_fingerprint="grid-fp",
    )
    return oos, stability


def test_missing_oos_and_stability_fail_closed():
    engine, rec, meta, trust, now, _ = fixture()
    decision = engine.evaluate(rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now)
    assert isinstance(decision, Rejection)
    assert any(r.startswith("OOS_REPORT_MISSING") for r in decision.reasons)
    assert any(r.startswith("GATE_STABILITY_MISSING") for r in decision.reasons)


def test_oos_fail_and_unstable_are_rejected():
    engine, rec, meta, trust, now, gate = fixture()
    oos, stability = reports(gate, now, verdict="OOS_FAIL", stable=False)
    decision = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
        batch=BATCH,
    )
    assert isinstance(decision, Rejection)
    assert any(r.startswith("OOS_VALIDATION_FAILED") for r in decision.reasons)
    assert any(r.startswith("GATE_UNSTABLE") for r in decision.reasons)
    assert verdict_for_reasons(decision.reasons) == "REJECTED"


def test_oos_pass_and_stable_continue_to_existing_gates():
    engine, rec, meta, trust, now, gate = fixture()
    oos, stability = reports(gate, now)
    decision = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
        batch=BATCH,
    )
    assert isinstance(decision, ApprovedPosition)


def test_current_input_fingerprint_is_required_and_reports_must_match():
    engine, rec, meta, trust, now, gate = fixture()
    oos, stability = reports(gate, now)

    missing = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
    )
    assert isinstance(missing, Rejection)
    assert any(r.startswith("CURRENT_DATA_FINGERPRINT_MISSING") for r in missing.reasons)
    assert any(r.startswith("CURRENT_BATCH_MISSING") for r in missing.reasons)

    changed = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
        batch=CHANGED,
    )
    assert isinstance(changed, Rejection)
    assert any(r.startswith("OOS_DATA_FINGERPRINT_MISMATCH") for r in changed.reasons)
    assert any(r.startswith("STABILITY_DATA_FINGERPRINT_MISMATCH") for r in changed.reasons)


def test_stale_oos_or_stability_report_is_rejected():
    engine, rec, meta, trust, now, gate = fixture()
    old = now - pd.Timedelta(days=8)
    oos, stability = reports(gate, now, oos_created_at=old)
    stale_oos = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
        batch=BATCH,
    )
    assert isinstance(stale_oos, Rejection)
    assert any(r.startswith("STALE_OOS") for r in stale_oos.reasons)

    oos, stability = reports(gate, now, stability_created_at=old)
    stale_stability = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
        batch=BATCH,
    )
    assert isinstance(stale_stability, Rejection)
    assert any(r.startswith("STALE_STABILITY") for r in stale_stability.reasons)


def test_strategy_configuration_and_collection_symbol_must_match():
    engine, rec, meta, trust, now, gate = fixture()
    oos, stability = reports(gate, now, strategy_version="another-strategy")
    wrong_strategy = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
        batch=BATCH,
    )
    assert isinstance(wrong_strategy, Rejection)
    assert any(r.startswith("OOS_VERSION_MISMATCH") for r in wrong_strategy.reasons)

    oos, stability = reports(gate, now)
    meta.symbol = "OTHER"
    wrong_symbol = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
        batch=BATCH,
    )
    assert isinstance(wrong_symbol, Rejection)
    assert any(r.startswith("COLLECTION_SYMBOL_MISMATCH") for r in wrong_symbol.reasons)


def test_forged_reports_are_rejected():
    engine, rec, meta, trust, now, _ = fixture()
    decision = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=SimpleNamespace(verdict="OOS_PASS"),
        stability_report=SimpleNamespace(stable=True),
    )
    assert isinstance(decision, Rejection)
    assert any(r.startswith("OOS_REPORT_INVALID") for r in decision.reasons)
    assert any(r.startswith("GATE_STABILITY_INVALID") for r in decision.reasons)


def test_reports_bound_to_another_symbol_are_rejected():
    engine, rec, meta, trust, now, gate = fixture()
    oos, stability = reports(gate, now, symbol="OTHER")
    decision = engine.evaluate(
        rec, signal_bar=meta.last_bar_ts, meta=meta, trust=trust, now=now,
        oos_report=oos, stability_report=stability,
    )
    assert isinstance(decision, Rejection)
    assert any(r.startswith("OOS_SYMBOL_MISMATCH") for r in decision.reasons)
