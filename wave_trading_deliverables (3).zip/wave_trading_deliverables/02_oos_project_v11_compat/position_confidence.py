from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional, Sequence, Tuple


class CalStatus(Enum):
    CALIBRATED = "CALIBRATED"
    UNVERIFIED = "UNVERIFIED"


@dataclass
class ValidationBinding:
    validation_id: str
    calibrator_hash: str
    data_fingerprint: str
    strategy_version: str
    train_window: tuple


@dataclass
class ValidationReport:
    passed: bool
    reasons: Sequence[str] = field(default_factory=list)
    validation_id: str = ""
    deployed_fingerprint: str = ""
    calibrator_state_hash: str = ""
    data_fingerprint: str = ""
    strategy_version: str = ""
    train_window: tuple = ()


@dataclass
class ConfidenceCalibrator:
    state_fingerprint: str = "fp"

    def calibrate(self, raw: Any):
        return type(
            "CalResult",
            (),
            {
                "status": CalStatus.CALIBRATED,
                "p": 0.8,
                "p_lower": 0.7,
                "bin_lo": 0.7,
                "bin_hi": 0.9,
                "reason": "",
            },
        )()


def calibrator_state_hash(calibrator: Any) -> str:
    return getattr(calibrator, "state_fingerprint", "")


__all__ = [
    "CalStatus",
    "ConfidenceCalibrator",
    "ValidationBinding",
    "ValidationReport",
    "calibrator_state_hash",
]
