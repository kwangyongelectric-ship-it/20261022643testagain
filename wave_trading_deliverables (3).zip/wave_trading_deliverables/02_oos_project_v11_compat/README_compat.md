# oos_project_v11_compat — 원본 wave_contracts_ext v1.1.0 기준 격리 프로젝트

원본 ZIP(`oos_project_source.zip`, `oos_project_revised.zip`)은 변경하지 않았다. 이 폴더는 별도 사본이다.

- `wave_contracts_ext.py` : 업로드된 원본 v1.1.0 (바이트 동일). 재구성본/제안본 아님.
- `data_collection_v2.py`, `revision_store.py`, `test_contract_cases.py` : ZIP 루트 원본 (바이트 그대로).
- 수정한 파일
  - `data_collector_ohlcv_fix1.py` : `raw_payload_kind` 제거(v1.1 계약에 없음). 원본 바이트 종류 구분은 `raw_content_hash`로만 가능.
  - `oos_validation_fixed.py` : `validate(raw, *, batch_hash=None)`. 지문을 검증기가 새로 정의하지 않고,
    raw 시리즈의 계약 해시가 batch_hash와 같을 때만 채택(불일치 ValueError). 미전달 시 지문 공백 → 엔진이 거절.
  - 테스트: `test_ohlcv_approval_integration.py` 조정, `test_batch_lineage_integration.py` 신규(7개).
- **엔진 지문 신뢰 문제 수정**: `ApprovalEngine.evaluate(..., batch=CollectedBatch)`. 구 `current_data_fingerprint` 문자열 인자는 폐지(전달하면 TypeError).
  엔진이 배치의 `closes/volumes/timestamps`에서 계약 해시를 직접 재계산하고(선언된 해시를 믿지 않음), 배치 내부 정합성
  (선언 해시·raw 해시·`normalized_rows`·심볼·마지막 봉과 수집 메타)을 교차 검증한다. 신규 테스트 `test_engine_batch_recompute.py` 11개.
  보증 위계: 지문의 최종 보증은 수집 계약의 불변성(RawStore/RevisionStore, TC-1.x)이고, 엔진 재계산은 그 전제 위에서
  전달 오류와 사후 변조를 잡는 계층이다. 수집 계약을 거치지 않고 통째로 위조한 배치까지는 엔진이 막지 못한다.
- 스텁(그대로): `position_confidence.py`, `wave_analysis/` — 계약·OOS·승인 배선 테스트용. 전략/보정기 검증이 아니다.

실행: `python -m pytest -q` (pytest 필요). 이 환경에서는 pytest 없이 동등한 실행기로 81개(39+8+8+7+8+11) 통과를 확인했다.

한계: 합성 데이터·스텁 기준. 시계 오차 허용 없음(리포트 created_at이 now보다 미래이면 거절). 실제 pykrx/API 미검증.
