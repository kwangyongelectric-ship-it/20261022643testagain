from datetime import timedelta
from types import SimpleNamespace

import pandas as pd
import pytest

from approval_engine_oos_integrated import (
    ApprovalEngine,
    ApprovedPosition,
    Rejection,
)
from data_collector_ohlcv_fix1 import dataframe_to_collected_batch
from data_collection_v2 import DataSourceError
from oos_validation_fixed import GateConfig, OOSReport, StabilityReport
from position_confidence import CalStatus
from wave_contracts_ext import normalized_content_hash, raw_content_hash


class Calibrator:
    state_fingerprint = "calibrator-fingerprint"

    def calibrate(self, raw):
        return SimpleNamespace(
            status=CalStatus.CALIBRATED,
            p=0.8,
            p_lower=0.7,
            bin_lo=0.7,
            bin_hi=0.9,
            reason="",
        )


def collector_frame(rows=30):
    dates = pd.bdate_range("2026-01-05", periods=rows)
    return pd.DataFrame(
        {
            "Open": range(100, 100 + rows),
            "High": range(101, 101 + rows),
            "Low": range(99, 99 + rows),
            "Close": [100.0 + index for index in range(rows)],
            "Volume": [1000.0 + index for index in range(rows)],
        },
        index=dates,
    )


def collect_batch(frame=None, *, confirmed_through=None):
    frame = collector_frame() if frame is None else frame
    boundary = confirmed_through or frame.index[-1].to_pydatetime()
    return dataframe_to_collected_batch(
        frame,
        "005930",
        provider="pykrx",
        confirmed_through=boundary,
    )


def evaluate_batch(batch, *, signal_bar=None, verdict="OOS_PASS", stability_fp=None):
    now = pd.Timestamp.now(tz="UTC")
    gate = GateConfig(1.0, 60)
    data_fingerprint = batch.normalized_content_hash
    validation = SimpleNamespace(
        passed=True,
        reasons=[],
        validation_id="validation-1",
        deployed_fingerprint="calibrator-fingerprint",
        calibrator_state_hash="calibrator-fingerprint",
        data_fingerprint="validation-data-fingerprint",
        strategy_version="strategy-1",
        train_window=("start", "end"),
    )
    engine = ApprovalEngine(
        Calibrator(),
        validation,
        require_binding=False,
        strategy_version="strategy-1",
        expected_gate=gate,
    )
    recommendation = SimpleNamespace(
        symbol="005930",
        direction="LONG",
        action="BUY",
        signal_strength=80,
    )
    last_confirmed = pd.Timestamp(batch.timestamps[-1], unit="s", tz="UTC")
    metadata = SimpleNamespace(
        symbol="005930",
        last_bar_ts=last_confirmed,
        collected_at=pd.Timestamp(batch.meta.received_at),
    )
    trust = SimpleNamespace(passed=True, reliability=0.99)
    oos = OOSReport(
        symbol="005930",
        verdict=verdict,
        frozen_gate=gate,
        train_bars=200,
        test_bars=70,
        embargo_bars=20,
        oos={"trades": 9, "sharpe": 1.2},
        baseline={"sharpe": 0.8},
        strategy_version="strategy-1",
        created_at=now,
        data_fingerprint=data_fingerprint,
    )
    stability = StabilityReport(
        symbol="005930",
        stable=True,
        best_gate=gate,
        best_score=1.0,
        neighbor_mean_score=0.9,
        neighbor_min_score=0.85,
        plateau_ratio=0.9,
        sharp_optimum=False,
        strategy_version="strategy-1",
        created_at=now,
        data_fingerprint=stability_fp or data_fingerprint,
        grid_fingerprint="grid-fingerprint",
    )
    return engine.evaluate(
        recommendation,
        signal_bar=last_confirmed if signal_bar is None else signal_bar,
        meta=metadata,
        trust=trust,
        now=now,
        oos_report=oos,
        stability_report=stability,
        batch=batch,
    )


def test_collector_dataframe_becomes_batch_and_can_be_approved():
    frame = collector_frame()
    boundary = frame.index[-2].to_pydatetime()
    batch = collect_batch(frame, confirmed_through=boundary)

    assert len(batch.closes) == len(frame) - 1
    assert batch.meta.raw_rows == len(frame)
    assert batch.meta.normalized_rows == len(frame) - 1
    assert batch.meta.dropped[-1]["reason"] == "unconfirmed bar"
    assert batch.timestamps[-1] == int(pd.Timestamp(boundary, tz="UTC").timestamp())
    assert batch.meta.required_fields_present()
    assert isinstance(evaluate_batch(batch), ApprovedPosition)


def test_provider_bytes_and_csv_snapshot_provenance_are_distinct():
    frame = collector_frame(5)
    provider_payload = b'{"provider":"pykrx","raw":"response"}'
    provider_batch = dataframe_to_collected_batch(
        frame,
        "005930",
        provider="pykrx",
        confirmed_through=frame.index[-1].to_pydatetime(),
        raw_bytes=provider_payload,
    )
    snapshot_batch = collect_batch(frame)

    assert provider_batch.raw_bytes == provider_payload
    assert provider_batch.raw_content_hash == raw_content_hash(provider_payload)
    assert snapshot_batch.raw_bytes != provider_payload
    assert snapshot_batch.raw_content_hash == raw_content_hash(snapshot_batch.raw_bytes)
    assert provider_batch.normalized_content_hash == snapshot_batch.normalized_content_hash
    assert provider_batch.raw_content_hash != snapshot_batch.raw_content_hash
    assert provider_batch.normalized_content_hash == normalized_content_hash(
        provider_batch.closes, provider_batch.volumes, provider_batch.timestamps
    )


def test_missing_close_is_recorded_and_all_missing_data_is_rejected():
    frame = collector_frame(5)
    frame.iloc[2, frame.columns.get_loc("Close")] = float("nan")
    batch = collect_batch(frame)
    assert any(drop["reason"] == "close NaN" for drop in batch.meta.dropped)
    assert len(batch.closes) == len(frame) - 1

    frame["Close"] = float("nan")
    with pytest.raises(DataSourceError, match="정제 후 유효 데이터 없음"):
        collect_batch(frame)


def test_missing_required_column_and_confirmation_boundary_fail_closed():
    frame = collector_frame(5).drop(columns=["Volume"])
    with pytest.raises(DataSourceError, match="Close and Volume"):
        collect_batch(frame)

    with pytest.raises(DataSourceError, match="confirmed_through is required"):
        dataframe_to_collected_batch(
            collector_frame(5), "005930", provider="pykrx", confirmed_through=None
        )


def test_signal_from_unconfirmed_bar_is_rejected():
    frame = collector_frame()
    batch = collect_batch(frame, confirmed_through=frame.index[-2].to_pydatetime())
    unconfirmed_signal = pd.Timestamp(frame.index[-1], tz="UTC")

    decision = evaluate_batch(batch, signal_bar=unconfirmed_signal)

    assert isinstance(decision, Rejection)
    assert any(reason.startswith("BAR_UNCONFIRMED") for reason in decision.reasons)


def test_fingerprint_mismatch_is_rejected():
    batch = collect_batch()
    decision = evaluate_batch(batch, stability_fp="different-fingerprint")

    assert isinstance(decision, Rejection)
    assert any(
        reason.startswith("OOS_STABILITY_FINGERPRINT_MISMATCH")
        for reason in decision.reasons
    )


def test_oos_failure_is_rejected():
    decision = evaluate_batch(collect_batch(), verdict="OOS_FAIL")

    assert isinstance(decision, Rejection)
    assert any(reason.startswith("OOS_VALIDATION_FAILED") for reason in decision.reasons)
