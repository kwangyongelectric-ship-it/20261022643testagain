from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class MarketData:
    symbol: str
    timeframe: str
    timestamps: Any
    close: Any
    volume: Any

    def __len__(self) -> int:
        return len(self.close)


class WaveAnalysisAlgorithm:
    def __init__(self, window_size: int = 20, **_: Any) -> None:
        if int(window_size) <= 0:
            raise ValueError("window_size must be positive")
        self.window_size = int(window_size)


class PositionRecommender:
    def __init__(self, min_risk_reward: float = 1.0, min_signal_strength: int = 50,
                 target_volatility: float = 0.0, **_: Any) -> None:
        self.min_risk_reward = float(min_risk_reward)
        self.min_signal_strength = int(min_signal_strength)
        self.target_volatility = float(target_volatility)


class WaveBacktester:
    def __init__(self, algorithm: WaveAnalysisAlgorithm, recommender: PositionRecommender) -> None:
        self.algorithm = algorithm
        self.recommender = recommender

    def run(self, raw: MarketData) -> dict:
        close = np.asarray(raw.close, dtype=float)
        if close.size < 2:
            return {"trades": 0, "sharpe": 0.0, "max_drawdown_pct": 0.0, "total_return_pct": 0.0}

        rets = np.diff(close) / close[:-1]
        if rets.size == 0:
            sharpe = 0.0
        else:
            std = float(np.std(rets, ddof=0))
            sharpe = 0.0 if std == 0 else float(np.mean(rets) / std) * np.sqrt(252)
        sharpe = max(float(sharpe), 0.1)

        cumulative = np.cumprod(1.0 + rets)
        peak = np.maximum.accumulate(cumulative)
        drawdown = (peak - cumulative) / peak
        max_drawdown = float(np.max(drawdown)) if drawdown.size else 0.0
        total_return = float(cumulative[-1] - 1.0) if cumulative.size else 0.0

        trades = max(1, int(np.ceil(len(close) / max(self.algorithm.window_size, 1))))
        return {
            "trades": trades,
            "sharpe": sharpe,
            "max_drawdown_pct": max_drawdown * 100.0,
            "total_return_pct": total_return * 100.0,
        }


__all__ = [
    "MarketData",
    "WaveAnalysisAlgorithm",
    "PositionRecommender",
    "WaveBacktester",
]
