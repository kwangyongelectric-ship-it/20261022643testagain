"""수집 배치(CollectedBatch) → OOS 검증 → 승인 엔진의 '데이터 계보' 통합 테스트.
승인 엔진이 현재 배치의 normalized_content_hash와 실제 OOSValidator가 만든 리포트의 data_fingerprint를 직접 비교한다.
(지문을 테스트에서 손으로 지정하지 않는다.)"""
from datetime import timedelta
from types import SimpleNamespace as NS

import numpy as np, pandas as pd, pytest

import oos_validation_fixed as ov
from approval_engine_oos_integrated import ApprovalEngine, ApprovedPosition, Rejection, verdict_for_reasons
from data_collector_ohlcv_fix1 import dataframe_to_collected_batch
from position_confidence import CalStatus
from wave_analysis import MarketData

GATE = ov.GateConfig(1.0, 60)


class _Alg:
    window_size = 20
class _Rec:
    def __init__(self, **k): pass
class _PassBT:                                   # OOS 판정 로직만 검증하려고 성과를 고정
    def __init__(self, a, r): pass
    def run(self, t): return {"trades": 9, "sharpe": 9.0, "max_drawdown_pct": 0.0, "total_return_pct": 1.0}
class _Cal:
    state_fingerprint = "fp"
    def calibrate(self, raw): return NS(status=CalStatus.CALIBRATED, p=0.8, p_lower=0.7, bin_lo=.7, bin_hi=.9, reason="")


def frame(end=None, n=300, bump=None):
    end = end if end is not None else pd.Timestamp.now().normalize() - pd.Timedelta(days=1)
    end = pd.offsets.BDay().rollback(end)                       # 주말이면 직전 금요일(요일 무관)
    idx = pd.bdate_range(end=end, periods=n)
    c = 70000 * np.exp(np.cumsum(np.random.default_rng(3).normal(0, .01, n)))
    if bump is not None: c[bump] *= 1.001                      # 과거 한 봉의 값 정정을 흉내
    return pd.DataFrame({"Open": c, "High": c, "Low": c, "Close": c, "Volume": np.full(n, 1e5)}, index=idx)


def batch_of(df, confirmed_through=None):
    return dataframe_to_collected_batch(df, "005930", provider="pykrx",
                                        confirmed_through=(confirmed_through or df.index[-1]).to_pydatetime())

def md_of(batch):
    return MarketData("005930", "1d", pd.to_datetime(batch.timestamps, unit="s"),
                      np.array(batch.closes), np.array(batch.volumes))

GRID = pd.DataFrame([{"min_risk_reward": rr, "min_signal_strength": ss, "score": 1.0 if (rr, ss) == (1.0, 60) else 0.9}
                     for rr in (0.8, 1.0, 1.2, 1.5) for ss in (40, 50, 60, 70)])

def validate(md, batch_hash):
    oos = ov.OOSValidator(lambda: _Alg(), _Rec, _PassBT, lambda tr: GATE, min_oos_trades=1,
                          strategy_version="s1").validate(md, batch_hash=batch_hash)
    stab = ov.GateStabilityAnalyzer().analyze(GRID, "005930", strategy_version="s1", data_fingerprint=oos.data_fingerprint)
    return oos, stab

def decide(oos, stab, batch):
    now = pd.Timestamp.now(tz="UTC")
    meta = NS(symbol="005930", last_bar_ts=pd.Timestamp(batch.timestamps[-1], unit="s", tz="UTC"),
              collected_at=pd.Timestamp(batch.meta.received_at))
    val = NS(passed=True, reasons=[], validation_id="v", deployed_fingerprint="fp", calibrator_state_hash="fp",
             data_fingerprint="d", strategy_version="s1", train_window=("a", "b"))
    eng = ApprovalEngine(_Cal(), val, require_binding=False, strategy_version="s1", expected_gate=GATE)
    return eng.evaluate(NS(symbol="005930", direction="LONG", action="BUY", signal_strength=80),
                        signal_bar=meta.last_bar_ts, meta=meta, trust=NS(passed=True, reliability=.99), now=now,
                        oos_report=oos, stability_report=stab, batch=batch)


def test_real_validator_report_is_bound_to_batch_hash_and_approved():
    b = batch_of(frame()); oos, stab = validate(md_of(b), b.normalized_content_hash)
    assert oos.data_fingerprint == b.normalized_content_hash == stab.data_fingerprint
    assert isinstance(decide(oos, stab, b), ApprovedPosition)


def test_validator_rejects_series_that_is_not_the_batch():
    df = frame(); b = batch_of(df)
    other = batch_of(frame(bump=50))                                  # 같은 구간, 한 봉만 다른 값
    with pytest.raises(ValueError, match="OOS_INPUT_MISMATCH"):
        validate(md_of(other), b.normalized_content_hash)


def test_unconfirmed_bar_cannot_slip_into_validated_series():
    df = frame(); b = batch_of(df, confirmed_through=df.index[-2])    # 마지막 봉은 미확정 → 배치에서 제외
    full = MarketData("005930", "1d", df.index, df["Close"].to_numpy(), df["Volume"].to_numpy())
    with pytest.raises(ValueError, match="OOS_INPUT_MISMATCH"):
        validate(full, b.normalized_content_hash)                     # 미확정 봉을 포함한 시리즈로는 검증 불가
    oos, stab = validate(md_of(b), b.normalized_content_hash)
    assert isinstance(decide(oos, stab, b), ApprovedPosition)


def test_data_revision_requires_revalidation():
    old = batch_of(frame()); oos, stab = validate(md_of(old), old.normalized_content_hash)
    revised = batch_of(frame(bump=50))                                 # 과거 봉 정정 → 현재 배치 해시가 바뀜
    assert revised.normalized_content_hash != old.normalized_content_hash
    d = decide(oos, stab, revised)
    assert isinstance(d, Rejection)
    assert {"OOS_DATA_FINGERPRINT_MISMATCH", "STABILITY_DATA_FINGERPRINT_MISMATCH"} <= {r.split(":")[0] for r in d.reasons}
    assert verdict_for_reasons(d.reasons) == "REVALIDATION_REQUIRED"


def test_new_bar_also_changes_fingerprint_so_old_report_is_not_reused():
    old = batch_of(frame(n=300)); oos, stab = validate(md_of(old), old.normalized_content_hash)
    longer = batch_of(frame(n=301))                                    # 봉이 하나 늘어난 배치
    assert isinstance(decide(oos, stab, longer), Rejection)


def test_report_without_batch_hash_is_fail_closed():
    b = batch_of(frame())
    oos = ov.OOSValidator(lambda: _Alg(), _Rec, _PassBT, lambda tr: GATE, min_oos_trades=1,
                          strategy_version="s1").validate(md_of(b))   # batch_hash 미전달
    stab = ov.GateStabilityAnalyzer().analyze(GRID, "005930", strategy_version="s1", data_fingerprint=oos.data_fingerprint)
    assert oos.data_fingerprint == ""
    d = decide(oos, stab, b)
    assert isinstance(d, Rejection) and any(r.startswith("OOS_FINGERPRINT_MISSING") for r in d.reasons)
    assert verdict_for_reasons(d.reasons) in ("UNVERIFIED", "REVALIDATION_REQUIRED")


def test_validator_fingerprint_equals_contract_hash_definition():
    from wave_contracts_ext import normalized_content_hash
    b = batch_of(frame())
    assert ov.series_content_hash(md_of(b)) == normalized_content_hash(b.closes, b.volumes, b.timestamps) == b.normalized_content_hash


def test_frame_has_requested_length_on_any_weekday():
    """요일 의존 회귀: 월요일/주말에 실행해도 frame()은 정확히 요청한 봉 수를 만든다."""
    assert len(frame()) == 300 and len(frame(n=301)) == 301
