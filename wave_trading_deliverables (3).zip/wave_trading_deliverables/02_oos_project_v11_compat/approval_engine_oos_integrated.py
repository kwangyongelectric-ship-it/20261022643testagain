"""
approval_engine.py — 승인 게이트 (엔진에서 강제)
================================================

규칙: '승인된 포지션 제안(ApprovedPosition)'은 이 엔진을 통과해야만 만들어진다.
  - 대시보드/주문 계층은 ApprovedPosition만 받는다. 직접 생성하면 PermissionError.
  - 아래 조건을 전부 만족해야 승인된다. 거절 사유는 단락 평가 없이 전부 모은다.

  1. 추천이 실행 가능한가(LONG/BUY)
  2. 신호가 '확정된 마지막 봉'에서 나왔는가 (미확정 봉 사용 금지)
  3. 데이터 신뢰도 검증(TrustReport) 통과
  4. 시간순 OOS 검증(ValidationReport) 통과
  5. 해당 점수 구간이 CALIBRATED (표본 부족/범위 밖이면 UNVERIFIED → 거절)
  6. 보정 확률 p가 하한 이상
  7. 수집 시각이 너무 오래되지 않았는가

Python에는 진짜 접근 제어가 없으므로 토큰 검사는 '실수 방지'이지 보안 경계가 아니다.
실제 주문 계층에서는 이 게이트의 출력만 입력으로 받도록 타입/인터페이스를 고정할 것.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any, List, Optional, Sequence, Union

import pandas as pd

from position_confidence import (
    CalStatus, ConfidenceCalibrator, ValidationReport, ValidationBinding,
    calibrator_state_hash,
)

_GATE_TOKEN = object()

# Dashboard and monitoring layers should use this shared mapping rather than
# interpreting gate reasons independently. A gate rejection remains non-approvable;
# VALIDATION_MISMATCH is classified as requiring revalidation for display/workflow.
VERDICT_BY_REASON_PREFIX = {
    "VALIDATION_MISMATCH": "REVALIDATION_REQUIRED",
    "REVALIDATION_REQUIRED": "REVALIDATION_REQUIRED",
    "VALIDATION_BINDING_MISSING": "UNVERIFIED",
    "CALIBRATION_UNVERIFIED": "UNVERIFIED",
    "VALIDATION_MISSING": "UNVERIFIED",
    "DATA_UNTRUSTED": "REJECTED",
    "COLLECTION_SYMBOL_MISMATCH": "REJECTED",
    "BAR_UNCONFIRMED": "REJECTED",
    "INVALID_COLLECTION_TIME": "REJECTED",
    "STALE_COLLECTION": "REJECTED",
    "VALIDATION_FAILED": "REJECTED",
    "LOW_CONFIDENCE": "REJECTED",
    "LOW_CONFIDENCE_LOWER_BOUND": "REJECTED",
    "OOS_REPORT_MISSING": "UNVERIFIED",
    "OOS_REPORT_INVALID": "REJECTED",
    "OOS_VALIDATION_FAILED": "REJECTED",
    "GATE_STABILITY_MISSING": "UNVERIFIED",
    "GATE_STABILITY_INVALID": "REJECTED",
    "GATE_UNSTABLE": "REJECTED",
    "OOS_SYMBOL_MISMATCH": "REJECTED",
    "GATE_SYMBOL_MISMATCH": "REJECTED",
    "OOS_GATE_MISMATCH": "REJECTED",
    "OOS_GATE_UNSPECIFIED": "REJECTED",
    "OOS_VERSION_UNSPECIFIED": "REJECTED",
    "OOS_VERSION_MISMATCH": "REVALIDATION_REQUIRED",
    "OOS_STABILITY_VERSION_MISMATCH": "REVALIDATION_REQUIRED",
    "STALE_OOS": "REJECTED",
    "OOS_FINGERPRINT_MISSING": "UNVERIFIED",
    "CURRENT_DATA_FINGERPRINT_MISSING": "UNVERIFIED",
    "CURRENT_BATCH_MISSING": "UNVERIFIED",
    "BATCH_INVALID": "REJECTED",
    "BATCH_INTEGRITY_FAILED": "REJECTED",
    "BATCH_SYMBOL_MISMATCH": "REJECTED",
    "BATCH_META_MISMATCH": "REJECTED",
    "OOS_DATA_FINGERPRINT_MISMATCH": "REVALIDATION_REQUIRED",
    "STABILITY_DATA_FINGERPRINT_MISMATCH": "REVALIDATION_REQUIRED",
    "OOS_STABILITY_FINGERPRINT_MISMATCH": "REVALIDATION_REQUIRED",
    "OOS_STABILITY_GATE_MISMATCH": "REVALIDATION_REQUIRED",
    "GATE_GRID_FINGERPRINT_MISSING": "UNVERIFIED",
}


def verdict_for_reasons(reasons, binding_status: Optional[str] = None) -> str:
    """Dashboard classification. Empty reasons alone never imply verification."""
    if not reasons:
        if binding_status == "VERIFIED_MATCH":
            return "APPROVED_VERIFIED_MATCH"
        if binding_status == "BINDING_MISSING":
            return "CONDITIONALLY_APPROVED_NO_BINDING"
        if binding_status == "BINDING_CONSISTENT":
            return "CONDITIONALLY_APPROVED"
        return "UNVERIFIED"
    verdicts = []
    for reason in reasons:
        prefix = str(reason).split(":", 1)[0]
        verdicts.append(VERDICT_BY_REASON_PREFIX.get(prefix, "REJECTED"))
    if "REJECTED" in verdicts:
        return "REJECTED"
    if "REVALIDATION_REQUIRED" in verdicts:
        return "REVALIDATION_REQUIRED"
    return "UNVERIFIED"


@dataclass(frozen=True)
class ApprovedPosition:
    recommendation: Any
    calibrated_p: float
    p_lower: float
    support_range: tuple
    validation_id: str
    data_reliability: float
    signal_bar: pd.Timestamp
    collected_at: pd.Timestamp
    binding_status: str = "UNVERIFIED"
    _token: object = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        if self._token is not _GATE_TOKEN:
            raise PermissionError("ApprovedPosition은 ApprovalEngine만 생성할 수 있습니다.")


@dataclass(frozen=True)
class Rejection:
    symbol: str
    reasons: tuple
    calibrated_p: Optional[float] = None


Decision = Union[ApprovedPosition, Rejection]



def verify_current_batch(batch, rec, meta):
    """현재 수집 배치(CollectedBatch)에서 계약 해시를 재계산한다. 반환: (지문 또는 None, 사유 목록).

    지문의 최종 보증 위계: 수집 계약의 불변성(RawStore/RevisionStore, TC-1.x)이 배치를 보증하고,
    이 함수는 그 전제 위에서 '전달 오류와 사후 변조'를 잡는 계층이다. 지문은 호출자가 문자열로 넘기지 못하고
    오직 배치 객체에서만 나온다(구 current_data_fingerprint 인자는 폐지)."""
    from wave_contracts_ext import normalized_content_hash, raw_content_hash
    if batch is None:
        return None, ["CURRENT_BATCH_MISSING: 현재 수집 배치(CollectedBatch) 누락 — 지문 문자열은 받지 않는다"]
    reasons: List[str] = []
    try:
        closes, volumes, stamps = batch.closes, batch.volumes, batch.timestamps
        if len(stamps) == 0:
            return None, ["BATCH_INVALID: 빈 배치"]
        fp = normalized_content_hash(closes, volumes, stamps)
    except (ValueError, TypeError, AttributeError, OverflowError) as exc:
        return None, [f"BATCH_INVALID: 배치 시리즈를 계약 해시로 계산할 수 없음 ({type(exc).__name__})"]
    # 선언된 해시 ↔ 실제 시리즈
    if getattr(batch, "normalized_content_hash", None) != fp:
        reasons.append("BATCH_INTEGRITY_FAILED: 선언된 normalized_content_hash가 시리즈에서 재계산한 값과 다름")
    try:
        if getattr(batch, "raw_content_hash", None) != raw_content_hash(batch.raw_bytes):
            reasons.append("BATCH_INTEGRITY_FAILED: raw_content_hash가 raw_bytes와 불일치")
    except (TypeError, AttributeError):
        reasons.append("BATCH_INVALID: raw_bytes를 확인할 수 없음")
    # 배치 ↔ 배치 메타 / 추천 심볼 / 수집 메타
    bmeta = getattr(batch, "meta", None)
    rows = getattr(bmeta, "normalized_rows", 0) if bmeta is not None else 0
    if rows and rows != len(stamps):
        reasons.append(f"BATCH_META_MISMATCH: 배치 메타 normalized_rows={rows} != 시리즈 {len(stamps)}")
    dataset = str(getattr(batch, "dataset_id", ""))
    if dataset.split(":", 1)[0] != getattr(rec, "symbol", None):
        reasons.append(f"BATCH_SYMBOL_MISMATCH: 배치={dataset!r} vs 추천={getattr(rec, 'symbol', None)!r}")
    try:
        batch_last = pd.Timestamp(int(stamps[-1]), unit="s").date()          # 배치 타임스탬프는 UTC epoch 초
        lb = pd.Timestamp(meta.last_bar_ts)
        meta_last = (lb.tz_convert("UTC") if lb.tzinfo is not None else lb).date()
        if batch_last != meta_last:
            reasons.append(f"BATCH_META_MISMATCH: 배치 마지막 봉 {batch_last} != 수집 메타 {meta_last}")
    except (TypeError, ValueError, AttributeError, OverflowError):
        reasons.append("BATCH_META_MISMATCH: 마지막 봉 비교 불가")
    return fp, reasons


class OOSBindingGate:
    def __init__(self, strategy_version: Optional[str], expected_gate: Optional[Any],
                 max_oos_age: timedelta):
        self.strategy_version = strategy_version
        self.expected_gate = expected_gate
        self.max_oos_age = max_oos_age

    def check(self, rec, oos_report: Any, stability_report: Any,
              now: pd.Timestamp, current_data_fingerprint: Optional[str]) -> List[str]:
        try:
            from oos_validation_fixed import OOSReport, StabilityReport
        except ImportError as exc:
            return [f"OOS_REPORT_INVALID: OOS 리포트 타입을 불러올 수 없음 ({exc})"]

        reasons: List[str] = []
        if not isinstance(oos_report, OOSReport):
            reasons.append(f"OOS_REPORT_INVALID: 실제 OOSReport 타입이 아님 (got {type(oos_report).__name__})")
        if not isinstance(stability_report, StabilityReport):
            reasons.append(f"GATE_STABILITY_INVALID: 실제 StabilityReport 타입이 아님 "
                           f"(got {type(stability_report).__name__})")
        if reasons:
            return reasons

        symbol = getattr(rec, "symbol", "?")
        if oos_report.symbol != symbol:
            reasons.append(f"OOS_SYMBOL_MISMATCH: 리포트={oos_report.symbol!r} vs 추천={symbol!r}")
        if stability_report.symbol != symbol:
            reasons.append(f"GATE_SYMBOL_MISMATCH: 리포트={stability_report.symbol!r} vs 추천={symbol!r}")

        if self.expected_gate is None:
            reasons.append("OOS_GATE_UNSPECIFIED: expected_gate 미지정 — 승인 불가")
        elif oos_report.frozen_gate != self.expected_gate:
            reasons.append("OOS_GATE_MISMATCH: OOS frozen_gate가 expected_gate와 불일치")

        if not self.strategy_version:
            reasons.append("OOS_VERSION_UNSPECIFIED: strategy_version 미지정 — 승인 불가")
        elif oos_report.strategy_version != self.strategy_version:
            reasons.append(f"OOS_VERSION_MISMATCH: {oos_report.strategy_version!r} != "
                           f"{self.strategy_version!r}")
        if stability_report.strategy_version != oos_report.strategy_version:
            reasons.append("OOS_STABILITY_VERSION_MISMATCH: OOS와 안정성 리포트의 전략 버전 불일치")

        for report_name, report in (("OOS", oos_report), ("STABILITY", stability_report)):
            try:
                now_ts = pd.Timestamp(now)
                created = pd.Timestamp(report.created_at)
                if (pd.isna(created) or created.tzinfo is None or
                        pd.isna(now_ts) or now_ts.tzinfo is None):
                    reasons.append(f"STALE_{report_name}: created_at 없음/naive — 신선도 판정 불가")
                else:
                    age = now_ts.tz_convert("UTC") - created.tz_convert("UTC")
                    if age < pd.Timedelta(0):
                        reasons.append(f"STALE_{report_name}: created_at이 미래")
                    elif age > pd.Timedelta(self.max_oos_age):
                        reasons.append(
                            f"STALE_{report_name}: 리포트 나이 {age} > {self.max_oos_age}"
                        )
            except (TypeError, ValueError, OverflowError):
                reasons.append(f"STALE_{report_name}: created_at 파싱 실패")

        if not oos_report.data_fingerprint or not stability_report.data_fingerprint:
            reasons.append("OOS_FINGERPRINT_MISSING: data_fingerprint 미기록 리포트는 승인 불가")
        elif oos_report.data_fingerprint != stability_report.data_fingerprint:
            reasons.append("OOS_STABILITY_FINGERPRINT_MISMATCH: OOS와 안정성 리포트 데이터 지문 불일치")
        if not current_data_fingerprint:
            reasons.append("CURRENT_DATA_FINGERPRINT_MISSING: 현재 입력 데이터 지문 누락")
        else:
            if oos_report.data_fingerprint != current_data_fingerprint:
                reasons.append("OOS_DATA_FINGERPRINT_MISMATCH: OOS와 현재 입력 데이터 지문 불일치")
            if stability_report.data_fingerprint != current_data_fingerprint:
                reasons.append(
                    "STABILITY_DATA_FINGERPRINT_MISMATCH: 안정성 보고서와 현재 입력 데이터 지문 불일치"
                )
        if not stability_report.grid_fingerprint:
            reasons.append("GATE_GRID_FINGERPRINT_MISSING: 그리드 지문이 없는 리포트는 승인 불가")
        if stability_report.best_gate != oos_report.frozen_gate:
            reasons.append("OOS_STABILITY_GATE_MISMATCH: 안정성 최적점이 OOS 동결 게이트와 불일치")

        if oos_report.verdict != "OOS_PASS":
            reasons.append(f"OOS_VALIDATION_FAILED: verdict={oos_report.verdict!r}")
        if stability_report.stable is not True:
            reasons.append("GATE_UNSTABLE: 안정성 판정이 stable=True가 아님")
        return reasons


class ApprovalEngine:
    def __init__(self, calibrator: ConfidenceCalibrator,
                 validation: Optional[ValidationReport],
                 min_prob: float = 0.55,
                 max_collection_age: timedelta = timedelta(hours=12),
                 min_p_lower: Optional[float] = None,
                 require_binding: bool = True,
                 strategy_version: Optional[str] = None,
                 expected_gate: Optional[Any] = None,
                 max_oos_age: timedelta = timedelta(days=7)):
        if not 0.0 <= min_prob <= 1.0:
            raise ValueError("min_prob은 0~1 범위여야 합니다.")
        if min_p_lower is not None and not 0.0 <= min_p_lower <= 1.0:
            raise ValueError("min_p_lower는 None 또는 0~1 범위여야 합니다.")
        self.calibrator, self.validation = calibrator, validation
        self.min_prob, self.max_age = min_prob, max_collection_age
        self.min_p_lower = min_p_lower
        self.require_binding = require_binding
        self.strategy_version = strategy_version
        self.oos_binding_gate = OOSBindingGate(strategy_version, expected_gate, max_oos_age)

    def evaluate(self, rec, *, signal_bar, meta, trust, now,
                 binding: Optional[ValidationBinding] = None,
                 oos_report: Optional[Any] = None,
                 stability_report: Optional[Any] = None,
                 batch: Optional[Any] = None) -> Decision:
        reasons: List[str] = []
        sym = getattr(rec, "symbol", getattr(meta, "symbol", "?"))

        # 1) 실행 가능성
        if not (getattr(rec, "direction", None) == "LONG" and getattr(rec, "action", None) == "BUY"):
            reasons.append("NOT_ACTIONABLE")
        if getattr(meta, "symbol", sym) != sym:
            reasons.append("COLLECTION_SYMBOL_MISMATCH: 수집 데이터와 추천 심볼 불일치")

        # 2) 확정 봉
        sb = pd.Timestamp(signal_bar)
        if sb > meta.last_bar_ts:
            reasons.append("BAR_UNCONFIRMED: 신호 봉이 확정 봉보다 최신")
        elif sb < meta.last_bar_ts:
            reasons.append("STALE_SIGNAL_BAR: 신호 봉이 최신 확정 봉이 아님")

        # 3) 데이터 신뢰
        if trust is None or not trust.passed:
            reasons.append("DATA_UNTRUSTED")

        # 4) OOS 검증
        if self.validation is None:
            reasons.append("VALIDATION_MISSING")
        elif not self.validation.passed:
            reasons.append("VALIDATION_FAILED: " + "; ".join(self.validation.reasons))

        # 4a) OOS and stability reports must be bound to this recommendation and gate.
        if oos_report is None:
            reasons.append("OOS_REPORT_MISSING: 게이트 파라미터 OOS 리포트 없음")
        if stability_report is None:
            reasons.append("GATE_STABILITY_MISSING: 게이트 안정성 리포트 없음")
        current_data_fingerprint, batch_reasons = verify_current_batch(batch, rec, meta)   # 문자열 지문 인자 폐지
        reasons.extend(batch_reasons)
        reasons.extend(self.oos_binding_gate.check(
            rec, oos_report, stability_report, now, current_data_fingerprint
        ))

        # 4b) 검증-보정기-전략 바인딩. 마이그레이션 단계에서는 선택적으로 강제한다.
        binding_status = "BINDING_MISSING"
        if binding is not None:
            binding_status = "BINDING_CONSISTENT"
            if self.validation is None or binding.validation_id != self.validation.validation_id:
                reasons.append("VALIDATION_MISMATCH: validation_id 불일치")
            current_fp = getattr(self.calibrator, "state_fingerprint", None)
            report_fp = (getattr(self.validation, "deployed_fingerprint", "") or
                         getattr(self.validation, "calibrator_state_hash", "")) if self.validation is not None else ""
            if not current_fp or current_fp != report_fp or binding.calibrator_hash != current_fp:
                reasons.append("REVALIDATION_REQUIRED: 배포 보정기가 검증 이후 재학습되었거나 상태 지문 불일치")
            if self.validation is not None:
                if binding.data_fingerprint != self.validation.data_fingerprint:
                    reasons.append("VALIDATION_MISMATCH: data_fingerprint 불일치")
                if binding.strategy_version != self.validation.strategy_version:
                    reasons.append("VALIDATION_MISMATCH: 검증 리포트의 strategy_version과 불일치")
            if self.strategy_version is not None and binding.strategy_version != self.strategy_version:
                reasons.append("VALIDATION_MISMATCH: 현재 strategy_version 불일치")
            if self.validation is not None and binding.train_window != self.validation.train_window:
                reasons.append("VALIDATION_MISMATCH: train_window 불일치")
            if not reasons:
                binding_status = "VERIFIED_MATCH"
        elif self.require_binding:
            reasons.append("VALIDATION_BINDING_MISSING")

        # 5) 보정 상태 / 6) 점 추정치와 하한은 독립 평가
        cs = self.calibrator.calibrate(float(getattr(rec, "signal_strength", 0.0)) / 100.0)
        if cs.status is not CalStatus.CALIBRATED:
            reasons.append(f"CALIBRATION_UNVERIFIED: {cs.reason}")
        else:
            if cs.p is None:
                reasons.append("CALIBRATION_INVALID: p 없음")
            elif cs.p < self.min_prob:
                reasons.append(f"LOW_CONFIDENCE: p={cs.p:.3f} < {self.min_prob}")
            if self.min_p_lower is not None:
                if cs.p_lower is None:
                    reasons.append("LOW_CONFIDENCE_LOWER_BOUND: p_lower 없음")
                elif cs.p_lower < self.min_p_lower:
                    reasons.append("LOW_CONFIDENCE_LOWER_BOUND: "
                                   f"p_lower={cs.p_lower:.3f} < {self.min_p_lower}")

        # 7) 수집 시각: NaT/naive/future timestamp는 fail-closed
        try:
            now_ts, collected = pd.Timestamp(now), pd.Timestamp(meta.collected_at)
            if (pd.isna(now_ts) or pd.isna(collected) or
                    now_ts.tzinfo is None or collected.tzinfo is None):
                reasons.append("INVALID_COLLECTION_TIME: NaT 또는 naive timestamp")
            else:
                age = now_ts.tz_convert("UTC") - collected.tz_convert("UTC")
                if age < pd.Timedelta(0):
                    reasons.append("INVALID_COLLECTION_TIME: collected_at이 미래")
                elif age > pd.Timedelta(self.max_age):
                    reasons.append("STALE_COLLECTION")
        except (TypeError, ValueError, OverflowError):
            reasons.append("INVALID_COLLECTION_TIME: timestamp 파싱 실패")

        if reasons:
            return Rejection(sym, tuple(reasons), cs.p)
        return ApprovedPosition(
            recommendation=rec, calibrated_p=cs.p, p_lower=cs.p_lower,
            support_range=(cs.bin_lo, cs.bin_hi), validation_id=self.validation.validation_id,
            data_reliability=trust.reliability, signal_bar=sb, collected_at=meta.collected_at,
            binding_status=binding_status,
            _token=_GATE_TOKEN)
