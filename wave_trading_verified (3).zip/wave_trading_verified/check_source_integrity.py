"""check_source_integrity.py — 인코딩 깨짐/주석에 코드가 삼켜진 줄을 잡는 정적 검사.
사용: python check_source_integrity.py [파일 또는 디렉터리 ...]   (이슈가 있으면 종료 코드 1)

검사 항목
 1. 엄격한 UTF-8 디코딩 (BOM/깨진 바이트)
 2. 컴파일 가능 여부
 3. 깨진 한글(모지바케) 징후: U+FFFD, 한글 문서에 섞인 한자(CJK 통합 한자), 한글과 '?'가 번갈아 나오는 패턴
 4. 주석 한 줄에 코드가 합쳐진 징후: '#' 주석 뒤에 공백 8칸 이상 + 대입/호출 형태
"""
import os, py_compile, re, sys, tempfile

CJK = re.compile(r"[\u4e00-\u9fff]")
HANGUL_Q = re.compile(r"[\uac00-\ud7a3]\?[\uac00-\ud7a3\u4e00-\u9fff]|\?[\uac00-\ud7a3]\?")
SWALLOWED = re.compile(r"#[^\n]*?\S {8,}[A-Za-z_][\w\.]*\s*(=|\()")


def scan_text(text: str, name: str = "<text>"):
    issues = []
    if "\ufffd" in text:
        issues.append((name, 0, "U+FFFD(치환 문자) 포함 — 인코딩 깨짐"))
    for n, line in enumerate(text.splitlines(), 1):
        if CJK.search(line) and re.search(r"[\uac00-\ud7a3]", text):
            issues.append((name, n, "한글 문서에 한자 혼입(모지바케 의심): " + line.strip()[:50]))
        elif HANGUL_Q.search(line):
            issues.append((name, n, "한글과 '?' 교차 패턴(모지바케 의심): " + line.strip()[:50]))
        if SWALLOWED.search(line):
            issues.append((name, n, "주석 뒤에 코드가 같은 줄에 있음(줄바꿈 소실 의심): " + line.strip()[:60]))
    return issues


def scan_file(path: str):
    raw = open(path, "rb").read()
    if raw.startswith(b"\xef\xbb\xbf"):
        pass  # UTF-8 BOM은 허용(경고 없음)
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as e:
        return [(path, 0, f"UTF-8 디코딩 실패: {e.reason} @byte {e.start}")]
    issues = scan_text(text, path)
    try:
        with tempfile.TemporaryDirectory() as d:
            py_compile.compile(path, cfile=os.path.join(d, "x.pyc"), doraise=True)
    except py_compile.PyCompileError as e:
        issues.append((path, 0, "컴파일 실패: " + str(e).strip().splitlines()[-1][:80]))
    return issues


def main(argv):
    targets = argv or ["."]
    files = []
    for t in targets:
        if os.path.isdir(t):
            files += [os.path.join(t, f) for f in sorted(os.listdir(t)) if f.endswith(".py")]
        else:
            files.append(t)
    bad = [i for f in files for i in scan_file(f)]
    for f, n, m in bad:
        print(f"{f}:{n}: {m}")
    print(f"검사 {len(files)}개 파일 — 이슈 {len(bad)}건")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
