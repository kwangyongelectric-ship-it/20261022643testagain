import logging
import os
import threading
import time
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import requests
from pykrx import stock

from bar_finality import KRX, strip_unconfirmed_ohlcv

# --- 버그 #1 수정: 구조화 로거 (print → logging) ------------------------
logger = logging.getLogger("data_collector")

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)

COLUMNS_MAP = {
    "시가": "Open",
    "고가": "High",
    "저가": "Low",
    "종가": "Close",
    "거래량": "Volume",
    "open": "Open",
    "high": "High",
    "low": "Low",
    "close": "Close",
    "volume": "Volume",
}

REQUIRED_COLUMNS = ["Open", "High", "Low", "Close", "Volume"]

# --- 버그 #1 수정: 품질 게이트 기준 (제안값 — 최종 승인 전까지 조정 가능) ---
# MIN_ROWS_RATIO: 요청 구간의 예상 거래일(영업일) 수 대비 최소 확보 비율.
#   근거: pykrx/Naver는 영업일 기준 일봉을 반환하므로, 예상 영업일의 절반도
#   못 받았다면 해당 공급자의 응답을 신뢰할 수 없다고 판정.
MIN_ROWS_RATIO = 0.5
# MAX_MISSING_RATIO: OHLCV 값 결측(NaN) 허용 비율 상한.
#   근거: 정상 수집된 일봉은 결측이 발생하지 않음. 일부 결측은 허용하되
#   5% 초과 시 불량 데이터로 판정해 폴백. (제안값 — 실데이터 검증 후 확정)
MAX_MISSING_RATIO = 0.05

# --- 공급자별 실패 기록 (스레드별 저장: 동시 호출이 서로의 기록을 지우지 않는다) ---
_tls = threading.local()


def _errors():
    if not hasattr(_tls, "errors"):
        _tls.errors = []
    return _tls.errors


def get_last_collection_errors():
    """현재 스레드의 최근 get_ohlcv 호출에서 발생한 공급자별 오류 목록 반환.

    각 항목: {"source": 공급자명, "exc_type": 예외 유형, "message": 내용}
    get_ohlcv()는 기존 호환성을 위해 빈 DataFrame 반환을 유지하므로,
    호출자는 반환값이 비어 있을 때 이 함수로 원인을 확인한다.
    """
    return list(_errors())


def _record_error(source, exc, message=""):
    entry = {
        "source": source,
        "exc_type": type(exc).__name__ if exc is not None else None,
        "message": str(exc) if exc is not None else message,
    }
    _errors().append(entry)
    logger.error(
        "source=%s exc_type=%s message=%s",
        entry["source"], entry["exc_type"], entry["message"],
    )


def validate_ohlcv(df, min_rows=1, max_missing_ratio=MAX_MISSING_RATIO):
    """품질 게이트: 행 수·필수 컬럼·결측률 검증.

    반환: (통과여부, 사유문자열) — 통과 시 (True, "")
    """
    if df is None or df.empty:
        return False, "empty dataframe"
    if len(df) < min_rows:
        return False, f"row count {len(df)} < min_rows {min_rows}"
    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            return False, f"missing required column: {col}"
    missing = df[REQUIRED_COLUMNS].isna()
    if not missing.values.any():
        return True, ""
    ratio = missing.values.sum() / missing.values.size
    if ratio > max_missing_ratio:
        return False, f"missing ratio {ratio:.3f} > {max_missing_ratio}"
    return True, ""


def normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    if not isinstance(df.index, pd.DatetimeIndex):
        if "Date" in df.columns or "날짜" in df.columns:
            date_col = "Date" if "Date" in df.columns else "날짜"
            df["Date"] = pd.to_datetime(df[date_col])
            df.set_index('Date', inplace=True)
        else:
            df.index = pd.to_datetime(df.index)
    df = df.rename(columns=COLUMNS_MAP)
    required_cols = ["Open", "High", "Low", "Close", "Volume"]
    for col in required_cols:
        if col not in df.columns:
            df[col] = np.nan
    df = df[required_cols].copy()
    df.index = pd.to_datetime(df.index).astype("datetime64[ns]")
    df.sort_index(inplace=True)
    return df


def fetch_from_pykrx(ticker: str, start_date: str, end_date: str) -> pd.DataFrame:
    try:
        if ticker.startswith("^") or ticker == "KS11":
            df = stock.get_index_ohlcv_by_date(start_date, end_date, "1001")
        else:
            df = stock.get_market_ohlcv_by_date(start_date, end_date, ticker)
        return normalize_dataframe(df)
    except Exception as e:
        # 버그 #1 수정: PyKRX 예외 원인을 구조화 로그로 보존
        _record_error("pykrx", e, f"PYKRX 수집 실패 ({ticker})")
        return pd.DataFrame()


def fetch_from_naver(ticker: str, pages: int = 10) -> pd.DataFrame:
    try:
        symbol = "KOSPI" if ticker in ["KS11", "^KS11", "1001"] else ticker
        url = f"https://fchart.stock.naver.com/sise.nhn?symbol={symbol}&requestType=0&count=500&timeframe=day"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        response = requests.get(url, headers=headers, timeout=5)
        if response.status_code != 200:
            _record_error(
                "naver", None,
                f"Naver HTTP status {response.status_code} ({ticker})",
            )
            return pd.DataFrame()
        import xml.etree.ElementTree as ET
        root = ET.fromstring(response.text)
        data = []
        for item in root.findall('.//item'):
            vals = item.get("data").split("|")
            data.append({
                "Date": vals[0],
                "Open": float(vals[1]),
                "High": float(vals[2]),
                "Low": float(vals[3]),
                "Close": float(vals[4]),
                "Volume": float(vals[5]),
            })
        df = pd.DataFrame(data)
        df["Date"] = pd.to_datetime(df["Date"])
        df.set_index("Date", inplace=True)
        return normalize_dataframe(df)
    except Exception as e:
        # 버그 #1 수정: Naver 예외 원인을 구조화 로그로 보존
        _record_error("naver", e, f"Naver Finance 데이터 수집 실패 ({ticker})")
        return pd.DataFrame()


# 증분 수집 시 마지막 캐시 봉 앞쪽 N영업일을 다시 받아 확정값으로 교체한다(공급자 사후 정정/과거 저장분 치유).
OVERLAP_BDAYS = 3


def _now_kst() -> pd.Timestamp:
    """현재 시각(KST, tz-aware). 서버가 UTC여도 일관되게 동작한다. 테스트는 이 함수를 교체해 시계를 주입한다."""
    return pd.Timestamp.now(tz=KRX.tz)


def _file_written_at(path: str) -> pd.Timestamp:
    """캐시 CSV가 마지막으로 쓰인 시각(KST). CSV에는 저장 시각 메타가 없어 파일 수정 시각으로 대신한다.
    (파일을 복사/체크아웃하면 수정 시각이 바뀌어 이 판정이 무력화될 수 있다.)"""
    return pd.Timestamp(os.path.getmtime(path), unit="s", tz="UTC").tz_convert(KRX.tz)


def _last_confirmed_bday(now: pd.Timestamp) -> pd.Timestamp:
    """지금 시점에 '확정된' 가장 최근 영업일(평일). 거래소 휴장일은 모델링하지 않는다
    (휴장일에는 캐시 적중 대신 재조회가 일어날 뿐, 데이터가 틀리지는 않는다)."""
    ln = now.tz_convert(KRX.tz)
    today = np.datetime64(ln.date())
    d = np.busday_offset(today, 0, roll="backward")          # 주말이면 직전 평일
    if d == today and ln.time() < KRX.confirm_time():          # 오늘 평일인데 아직 마감 확정 전
        d = np.busday_offset(today, -1, roll="backward")
    return pd.Timestamp(d)


def _bday_minus(ts: pd.Timestamp, n: int) -> pd.Timestamp:
    return pd.Timestamp(np.busday_offset(np.datetime64(ts.date()), -n, roll="backward"))


def _min_rows(start: pd.Timestamp, last_confirmed: pd.Timestamp) -> int:
    expected = int(np.busday_count(start.date(), (last_confirmed + pd.Timedelta(days=1)).date()))
    return max(1, int(expected * MIN_ROWS_RATIO))


def get_ohlcv(
    ticker: str = "KS11", start_date: str = "20200101", force_update: bool = False
) -> pd.DataFrame:
    """확정된 봉만 반환/저장한다.
    - 수집 직후와 캐시 읽기 직후 모두 미확정(당일 장중) 봉을 제거한다.
    - 마지막 캐시 봉이 '확정 전에 저장'됐을 수 있으면(파일 수정 시각 < 그 봉의 확정 시각) 그 봉을 버리고 다시 받는다.
    - pykrx 증분은 마지막 봉 앞쪽 OVERLAP_BDAYS를 겹쳐 받아 확정값으로 교체한다.
    - Naver 폴백은 요청(증분) 구간만 이어붙이고 기존 봉을 덮어쓰지 않는다."""
    _errors().clear()

    now = _now_kst()
    last_confirmed = _last_confirmed_bday(now)
    today_str = now.strftime("%Y%m%d")

    file_symbol = "ks11" if ticker in ["KS11", "^KS11", "1001"] else ticker
    file_path = os.path.join(DATA_DIR, f"{file_symbol}_daily.csv")

    df_local = pd.DataFrame()
    refresh_from = None                 # pykrx 증분 시 겹쳐 받기 시작하는 날짜
    naver_start = pd.Timestamp(datetime.strptime(start_date, "%Y%m%d"))
    if os.path.exists(file_path) and not force_update:
        try:
            df_local = normalize_dataframe(pd.read_csv(file_path, index_col=0))
            df_local = strip_unconfirmed_ohlcv(df_local, now, KRX)       # 영속화된 미확정 봉 제거
            if not df_local.empty:
                ok, reason = validate_ohlcv(df_local, min_rows=1)         # 캐시도 품질 게이트
                if not ok:
                    _record_error("local_csv", None, f"cache quality gate fail: {reason}")
                    df_local = pd.DataFrame()
        except Exception as e:
            _record_error("local_csv", e, "로컬 CSV 로드 오류")
            logger.warning("[Warning] 로컬 CSV 로드 오류, 재수집 진행: %s", e)
            df_local = pd.DataFrame()

        if not df_local.empty:
            last_date = df_local.index[-1]
            confirm_dt = pd.Timestamp(datetime.combine(last_date.date(), KRX.confirm_time())).tz_localize(KRX.tz)
            if _file_written_at(file_path) < confirm_dt:
                # 마지막 봉이 확정되기 전에 저장됐을 수 있다(과거 버전이 만든 캐시 포함): 버리고 다시 받는다
                logger.warning("[Heal] 확정 전 저장 의심 봉 제거: %s", last_date.date())
                df_local = df_local.iloc[:-1]
        if not df_local.empty:
            last_date = df_local.index[-1]
            if last_date >= last_confirmed:
                logger.info("[Cache Hit] 확정 봉 기준 최신 : %s", file_path)
                return df_local
            logger.info("[Cache Partial] 데이터 업데이트 진행 (%s -> %s)",
                        last_date.strftime("%Y%m%d"), last_confirmed.strftime("%Y%m%d"))
            refresh_from = _bday_minus(last_date, OVERLAP_BDAYS)
            start_date = refresh_from.strftime("%Y%m%d")
            naver_start = last_date + pd.Timedelta(days=1)

    logger.info("[Fetch] PyKRX 수집 시작 (%s: %s ~ %s)...", ticker, start_date, today_str)
    # 미확정 봉 제거는 품질 게이트보다 먼저: 장중 1봉이 증분 게이트를 통과해 저장되는 경로를 차단
    df_new = strip_unconfirmed_ohlcv(fetch_from_pykrx(ticker, start_date, today_str), now, KRX)
    used_naver = False

    if not df_new.empty:
        ok, reason = validate_ohlcv(df_new, min_rows=_min_rows(pd.Timestamp(datetime.strptime(start_date, "%Y%m%d")), last_confirmed))
        if not ok:
            _record_error("pykrx", None, f"quality gate fail: {reason}")
            df_new = pd.DataFrame()

    if df_new.empty:
        logger.info("[Fallback] Naver Finance 수집 전환 (%s)...", ticker)
        used_naver = True
        df_new = fetch_from_naver(ticker)
        if not df_new.empty:
            # Naver는 요청 구간과 무관하게 500봉을 준다: 요청 구간만 사용해 기존(pykrx) 봉을 덮어쓰지 않는다
            df_new = strip_unconfirmed_ohlcv(df_new[df_new.index >= naver_start], now, KRX)
        if not df_new.empty:
            ok, reason = validate_ohlcv(df_new, min_rows=_min_rows(naver_start, last_confirmed))
            if not ok:
                _record_error("naver", None, f"quality gate fail: {reason}")
                df_new = pd.DataFrame()
        if not df_new.empty and not df_local.empty:
            logger.warning("[ProviderChange] %s: 기존 데이터(pykrx) 뒤에 Naver 데이터 %d봉을 이어붙임",
                           ticker, len(df_new))

    if not df_new.empty:
        if df_local.empty:
            df_combined = df_new
        elif used_naver:
            df_combined = pd.concat([df_local, df_new])                 # 겹침 없음(naver_start 이후만)
            df_combined = df_combined[~df_combined.index.duplicated(keep="first")]
        else:
            overlap = df_new.index.intersection(df_local.index)
            changed = int((df_new.loc[overlap, "Close"].to_numpy() != df_local.loc[overlap, "Close"].to_numpy()).sum()) if len(overlap) else 0
            if changed:
                logger.warning("[Revision] %s: 겹쳐 받은 %d봉 중 %d봉의 종가가 바뀜(확정값으로 교체)", ticker, len(overlap), changed)
            df_combined = pd.concat([df_local[df_local.index < refresh_from], df_new])
        df_combined = df_combined.sort_index()
        df_combined.to_csv(file_path)
        logger.info("[Saved] CSV 저장 완료: %s", file_path)
        return df_combined
    else:
        logger.error("[Fail] 데이터 수집 실패. 기존 캐시 반환")
        return df_local


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    ks11_df = get_ohlcv(ticker="KS11", start_date="20220101")
    print(f"KS11 Rows: {len(ks11_df)}")
    print(ks11_df.tail())