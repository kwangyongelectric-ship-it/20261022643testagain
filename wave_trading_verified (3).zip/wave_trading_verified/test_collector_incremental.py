"""data_collector_ohlcv.py 회귀 테스트 (pykrx/requests는 스텁 → 네트워크 불필요).
검사 대상은 환경변수 COLLECTOR_UNDER_TEST(기본: 이 폴더의 data_collector_ohlcv.py).
 증분 수집  : 하루 뒤 증분 수집이 새 봉을 반영한다
 ⑫ 장중 호출 : pykrx가 당일 임시 봉을 줘도 반환/CSV에 당일 봉이 없다
 ⑬ 치유     : 과거에 CSV로 영속화된 미확정 봉은 확정값으로 교체된다 / 장중에는 제거된다
 ⑭ 폴백     : Naver 폴백이 기존(pykrx) 봉을 덮어쓰지 않는다
 ⑮ 시계     : 수집기 시계는 tz-aware KST
 ⑯ 동시성   : 스레드 간 오류 기록이 서로 지워지지 않는다
 ⑰ 캐시 품질 : 깨진 캐시 CSV는 폐기하고 재수집한다"""
import datetime as dt, importlib.util, logging, os, shutil, sys, tempfile, threading, types
import numpy as np, pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET = os.environ.get("COLLECTOR_UNDER_TEST", os.path.join(HERE, "data_collector_ohlcv.py"))
KST = "Asia/Seoul"
def T(s): return pd.Timestamp(s, tz=KST)
def bd(a, b): return pd.bdate_range(pd.Timestamp(a), pd.Timestamp(b))


class Env:
    def __init__(self, work):
        self.work, self.now, self.pykrx_ok, self.naver_rows = work, None, True, None
        self.final = {d.date(): 100.0 + d.dayofyear * 0.1 for d in bd("2026-01-01", "2026-10-12")}
        env = self
        def fetch(start, end, ticker):
            if not env.pykrx_ok: raise RuntimeError("pykrx down")
            rows = []
            for d in bd(start, end):
                if d.date() > env.now.date(): continue
                c = env.final[d.date()]
                if d.date() == env.now.date() and env.now.time() < dt.time(15, 30): c *= 0.97   # 장중 임시 종가
                rows.append((d, c, c, c, c, 1000))
            return pd.DataFrame(rows, columns=["날짜", "시가", "고가", "저가", "종가", "거래량"]).set_index("날짜")
        pk, st = types.ModuleType("pykrx"), types.ModuleType("pykrx.stock")
        st.get_market_ohlcv_by_date = st.get_index_ohlcv_by_date = fetch; pk.stock = st
        rq = types.ModuleType("requests")
        class R:
            def __init__(s, text): s.status_code, s.text = 200, text
        def get(*a, **k):
            if env.naver_rows is None: raise ConnectionError("blocked")
            items = "".join(f'<item data="{d}|{c}|{c}|{c}|{c}|1"/>' for d, c in env.naver_rows)
            return R(f"<protocol><chartdata>{items}</chartdata></protocol>")
        rq.get = get
        saved = {k: sys.modules.get(k) for k in ("pykrx", "pykrx.stock", "requests")}
        sys.modules.update({"pykrx": pk, "pykrx.stock": st, "requests": rq})
        sys.path.insert(0, HERE)
        try:
            shutil.copy(TARGET, os.path.join(work, "dc_under_test.py"))
            spec = importlib.util.spec_from_file_location("dc_under_test", os.path.join(work, "dc_under_test.py"))
            self.dc = importlib.util.module_from_spec(spec); spec.loader.exec_module(self.dc)
        finally:
            sys.path.remove(HERE)
            for k, v in saved.items():
                if v is None: sys.modules.pop(k, None)
                else: sys.modules[k] = v
        class F(dt.datetime):                       # 구버전(naive datetime.now) 호환용
            @classmethod
            def now(cls, tz=None): return env.now.tz_localize(None).to_pydatetime()
        self.dc.datetime = F
        self.orig_now_kst = getattr(self.dc, "_now_kst", None)   # 시계 주입 전의 실제 구현
        self.dc._now_kst = lambda: env.now          # 신버전: 시계 주입

    def at(self, s): self.now = T(s); return self
    def csv(self): return os.path.join(self.dc.DATA_DIR, "005930_daily.csv")
    def stamp(self, when):                            # 파일 수정 시각을 시뮬레이션 시각으로 설정
        ts = T(when).timestamp(); os.utime(self.csv(), (ts, ts))
    def get(self, ticker="005930", start="20260101"):  # 호출 후 CSV가 갱신됐으면 수정 시각 = 시뮬레이션 now
        p = self.csv(); before = os.path.getmtime(p) if os.path.exists(p) else None
        df = self.dc.get_ohlcv(ticker, start)
        if os.path.exists(p) and os.path.getmtime(p) != before:
            os.utime(p, (self.now.timestamp(), self.now.timestamp()))
        return df


def _run(fn):
    logging.disable(logging.CRITICAL)
    try:
        with tempfile.TemporaryDirectory() as w: fn(Env(w))
    finally: logging.disable(logging.NOTSET)


def test_incremental_update_advances_after_quality_gate():
    def body(e):
        df1 = e.at("2026-10-07 18:00").get()
        df2 = e.at("2026-10-08 18:00").get()
        assert df2.index[-1] > df1.index[-1], [x["message"] for x in e.dc.get_last_collection_errors()]
    _run(body)


def test_12_intraday_call_never_returns_or_stores_todays_bar():
    def body(e):
        df = e.at("2026-10-07 11:00").get()
        assert df.index[-1] == pd.Timestamp("2026-10-06"), df.index[-1]
        assert pd.read_csv(e.csv(), index_col=0).index[-1] == "2026-10-06"
    _run(body)


def test_13_persisted_partial_bar_is_healed_next_day_and_hidden_intraday():
    def body(e):
        e.at("2026-10-07 18:00")
        idx = bd("2026-01-01", "2026-10-07")
        vals = [e.final[d.date()] for d in idx]; vals[-1] *= 0.97              # 10/07은 장중 임시값으로 저장돼 있음
        os.makedirs(e.dc.DATA_DIR, exist_ok=True)
        pd.DataFrame({"Open": vals, "High": vals, "Low": vals, "Close": vals, "Volume": 1000.0}, index=idx).to_csv(e.csv())
        e.stamp("2026-10-07 11:00")                                              # 장중에 저장된 캐시(과거 버전이 만든 것)
        # (a) 장중(10/07 11:00)에는 미확정 봉을 반환하지 않는다
        df = e.at("2026-10-07 11:00").get()
        assert df.index[-1] == pd.Timestamp("2026-10-06")
        # (b) 다음 날 마감 후에는 10/07이 확정값으로 교체되고 10/08이 추가된다
        df = e.at("2026-10-08 18:00").get()
        assert abs(df.loc["2026-10-07", "Close"] - e.final[dt.date(2026, 10, 7)]) < 1e-9
        assert df.index[-1] == pd.Timestamp("2026-10-08")
    _run(body)


def test_14_naver_fallback_does_not_overwrite_existing_bars():
    def body(e):
        df1 = e.at("2026-10-07 18:00").get()
        e.at("2026-10-08 18:00").pykrx_ok = False
        # Naver는 요청 구간과 무관하게 과거 전체를 '다른 값'으로 준다 + 새 봉 10/08
        e.naver_rows = [(d.strftime("%Y%m%d"), e.final[d.date()] + 1000.0) for d in bd("2026-01-01", "2026-10-08")]
        df2 = e.get()
        pd.testing.assert_frame_equal(df2.loc[df1.index], df1, check_dtype=False)                      # 기존 pykrx 봉 불변
        assert df2.index[-1] == pd.Timestamp("2026-10-08") and df2.loc["2026-10-08", "Close"] > 1000
    _run(body)


def test_15_collector_clock_is_tz_aware_kst_even_on_utc_host():
    def body(e):
        assert e.orig_now_kst is not None, "수집기에 tz-aware 시계(_now_kst)가 없다(naive datetime.now 사용)"
        import time as _t
        old = os.environ.get("TZ")
        os.environ["TZ"] = "UTC"; _t.tzset()                         # 서버가 UTC로 돈다고 가정
        try:
            now = e.orig_now_kst()
            assert now.tzinfo is not None and str(now.tz) == KST, now
            assert abs((now - pd.Timestamp.now(tz=KST)).total_seconds()) < 5
        finally:
            if old is None: os.environ.pop("TZ", None)
            else: os.environ["TZ"] = old
            _t.tzset()
    _run(body)


def test_16_error_records_are_per_thread():
    def body(e):
        out = {}
        a_done, b_go = threading.Event(), threading.Event()
        def worker():
            e.dc._record_error("naver", None, "worker error")
            a_done.set(); b_go.wait(5)
            out["worker"] = [x["message"] for x in e.dc.get_last_collection_errors()]
        t = threading.Thread(target=worker); t.start(); a_done.wait(5)
        e.at("2026-10-07 18:00").get()                   # 메인 스레드 호출이 errors.clear() 수행
        b_go.set(); t.join(5)
        assert out["worker"] == ["worker error"], out
    _run(body)


def test_17_corrupt_cache_is_discarded_and_refetched():
    def body(e):
        e.at("2026-10-07 18:00")
        os.makedirs(e.dc.DATA_DIR, exist_ok=True)
        idx = bd("2026-01-01", "2026-10-07")
        pd.DataFrame({"Open": np.nan, "High": np.nan, "Low": np.nan, "Close": np.nan, "Volume": np.nan}, index=idx).to_csv(e.csv())   # 전부 결측인 캐시
        e.stamp("2026-10-07 18:00")
        df = e.get()
        assert df["Close"].notna().all() and len(df) == len(idx)
        assert any("cache quality gate fail" in x["message"] for x in e.dc.get_last_collection_errors())
    _run(body)
