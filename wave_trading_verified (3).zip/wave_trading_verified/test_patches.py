import unittest
from dataclasses import dataclass
import numpy as np
import pandas as pd

from position_confidence import (
    CalStatus, ConfidenceCalibrator, TradeRecord, validate_chronological,
    build_validation_binding,
)
from bar_finality import finalize_market_data, SessionSpec
from approval_engine import ApprovalEngine, Rejection, verdict_for_reasons
from position_confidence import calibrator_state_hash


class PatchTests(unittest.TestCase):
    def test_low_support_tail_unverified(self):
        ts = pd.Timestamp('2026-01-01', tz='UTC')
        trades = []
        for i in range(35):
            trades.append(TradeRecord('X', ts, ts + pd.Timedelta(days=1), .25, 0))
        for i in range(70):
            trades.append(TradeRecord('X', ts, ts + pd.Timedelta(days=1), .75, 1))
        for i in range(5):
            trades.append(TradeRecord('X', ts, ts + pd.Timedelta(days=1), .99, 0))
        cal = ConfidenceCalibrator().fit(trades, ts + pd.Timedelta(days=2))
        got = cal.calibrate(.99)
        self.assertEqual(got.status, CalStatus.UNVERIFIED)
        self.assertIsNone(got.p)
        self.assertIn('TAIL_LOW_SUPPORT', got.reason)

    def test_binding_required_is_fail_closed(self):
        engine = ApprovalEngine(ConfidenceCalibrator(), None, require_binding=True)
        # Other rejection reasons may also occur; binding-specific reason must be present.
        class Rec:
            symbol='X'; direction='LONG'; action='BUY'; signal_strength=60
        class Meta:
            symbol='X'; last_bar_ts=pd.Timestamp('2026-01-01', tz='UTC')
            collected_at=pd.Timestamp('2026-01-01', tz='UTC')
        class Trust:
            passed=True; reliability=1.0
        got = engine.evaluate(Rec(), signal_bar=Meta.last_bar_ts, meta=Meta(), trust=Trust(),
                              now=pd.Timestamp('2026-01-01 01:00', tz='UTC'))
        self.assertIsInstance(got, Rejection)
        self.assertIn('VALIDATION_BINDING_MISSING', got.reasons)

    def test_invalid_collection_times(self):
        class Rec:
            symbol='X'; direction='LONG'; action='BUY'; signal_strength=60
        class Meta:
            symbol='X'; last_bar_ts=pd.Timestamp('2026-01-01', tz='UTC')
        class Trust:
            passed=False; reliability=0.0
        engine = ApprovalEngine(ConfidenceCalibrator(), None)
        for collected_at, now in [
            (pd.Timestamp('2026-01-01 02:00', tz='UTC'), pd.Timestamp('2026-01-01 01:00', tz='UTC')),
            (pd.NaT, pd.Timestamp('2026-01-01 01:00', tz='UTC')),
            (pd.Timestamp('2026-01-01'), pd.Timestamp('2026-01-01 01:00', tz='UTC')),
        ]:
            meta = Meta(); meta.collected_at = collected_at
            got = engine.evaluate(Rec(), signal_bar=Meta.last_bar_ts, meta=meta, trust=Trust(), now=now)
            self.assertTrue(any(r.startswith('INVALID_COLLECTION_TIME') for r in got.reasons), got.reasons)

    def test_market_data_preserves_ohlc_fields(self):
        @dataclass
        class MD:
            symbol: str
            timeframe: str
            timestamps: pd.DatetimeIndex
            close: np.ndarray
            volume: np.ndarray
            open: np.ndarray
            high: np.ndarray
            low: np.ndarray
        ts = pd.date_range('2026-01-01', periods=3, freq='D')
        md = MD('X', '1d', ts, np.array([1.,2.,3.]), np.array([10,20,30]),
                np.array([.5,1.5,2.5]), np.array([1.5,2.5,3.5]), np.array([.4,1.4,2.4]))
        # Jan 3 is treated as today's unconfirmed bar at noon.
        out, meta = finalize_market_data(md, pd.Timestamp('2026-01-03 12:00', tz='Asia/Seoul'))
        self.assertEqual(len(out.close), 2)
        self.assertEqual(len(out.high), 2)
        self.assertEqual(float(out.high[-1]), 2.5)

    def _sample_trades(self, n=120):
        base = pd.Timestamp('2026-01-01', tz='UTC')
        return [
            TradeRecord('X', base + pd.Timedelta(hours=i),
                        base + pd.Timedelta(hours=i, minutes=30),
                        0.55, int(i % 2 == 0))
            for i in range(n)
        ]

    def test_binding_checks_full_data_and_fit_state(self):
        trades = self._sample_trades()
        report = validate_chronological(trades, strategy_version='v1', min_oos_covered=1)
        ordered = sorted(trades, key=lambda t: (t.decision_time, t.symbol))
        # validate_chronological의 마지막 fold는 index 105에서 시작
        deployment_cal = ConfidenceCalibrator().fit(trades, ordered[105].decision_time)
        binding = build_validation_binding(report, deployment_cal, 'v1', trades)
        self.assertEqual(binding.data_fingerprint, report.data_fingerprint)
        self.assertEqual(binding.calibrator_hash, calibrator_state_hash(deployment_cal))

        altered = list(trades)
        t = altered[0]
        altered[0] = TradeRecord(t.symbol, t.decision_time, t.label_time, t.score, 1 - t.outcome)
        with self.assertRaisesRegex(ValueError, '데이터 지문'):
            build_validation_binding(report, deployment_cal, 'v1', altered)

        different_fit = ConfidenceCalibrator().fit(
            [TradeRecord(t.symbol, t.decision_time, t.label_time, t.score,
                         1 - t.outcome) for t in trades], ordered[105].decision_time)
        self.assertNotEqual(calibrator_state_hash(deployment_cal), calibrator_state_hash(different_fit))
        with self.assertRaisesRegex(ValueError, 'fit 상태'):
            build_validation_binding(report, different_fit, 'v1', trades)

    def test_default_requires_binding_and_dashboard_does_not_overclaim(self):
        engine = ApprovalEngine(ConfidenceCalibrator(), None)
        self.assertTrue(engine.require_binding)
        self.assertEqual(verdict_for_reasons(()), 'UNVERIFIED')
        self.assertEqual(verdict_for_reasons((), 'VERIFIED_MATCH'), 'APPROVED_VERIFIED_MATCH')
        self.assertEqual(verdict_for_reasons((), 'BINDING_MISSING'), 'CONDITIONALLY_APPROVED_NO_BINDING')

    def test_list_tuple_ohlcv_are_sliced_and_unknown_aligned_field_rejected(self):
        @dataclass
        class MDList:
            symbol: str
            timeframe: str
            timestamps: pd.DatetimeIndex
            close: list
            volume: tuple
            open: list
            high: list
            low: list

        ts = pd.date_range('2026-01-01', periods=3, freq='D')
        md = MDList('X', '1d', ts, [1., 2., 3.], (10, 20, 30),
                    [.5, 1.5, 2.5], [1.5, 2.5, 3.5], [.4, 1.4, 2.4])
        out, _ = finalize_market_data(md, pd.Timestamp('2026-01-03 12:00', tz='Asia/Seoul'))
        self.assertEqual(len(out.close), 2)
        self.assertEqual(out.volume, (10, 20))

        @dataclass
        class MDWithUnknown:
            symbol: str
            timeframe: str
            timestamps: pd.DatetimeIndex
            close: np.ndarray
            volume: np.ndarray
            flags: list

        bad = MDWithUnknown('X', '1d', ts, np.array([1., 2., 3.]),
                            np.array([10, 20, 30]), ['a', 'b', 'c'])
        with self.assertRaisesRegex(ValueError, 'UNDECLARED_SEQUENCE_FIELD'):
            finalize_market_data(bad, pd.Timestamp('2026-01-03 12:00', tz='Asia/Seoul'))

    def test_unknown_list_field_rejected_even_if_length_differs(self):
        @dataclass
        class MDWithShortFlags:
            symbol: str
            timeframe: str
            timestamps: pd.DatetimeIndex
            close: list
            volume: list
            open: list
            high: list
            low: list
            flags: list

        ts = pd.date_range('2026-01-01', periods=3, freq='D')
        md = MDWithShortFlags('X', '1d', ts, [1., 2., 3.], [10, 20, 30],
                              [.5, 1.5, 2.5], [1.5, 2.5, 3.5], [.4, 1.4, 2.4], ['a', 'b'])
        with self.assertRaisesRegex(ValueError, 'UNDECLARED_SEQUENCE_FIELD'):
            finalize_market_data(md, pd.Timestamp('2026-01-03 12:00', tz='Asia/Seoul'))

    def test_known_timed_field_length_mismatch_has_contract_code(self):
        @dataclass
        class MDBadClose:
            symbol: str
            timeframe: str
            timestamps: pd.DatetimeIndex
            close: list
            volume: list
            open: list
            high: list
            low: list

        ts = pd.date_range('2026-01-01', periods=3, freq='D')
        md = MDBadClose('X', '1d', ts, [1., 2.], [10, 20, 30],
                         [.5, 1.5, 2.5], [1.5, 2.5, 3.5], [.4, 1.4, 2.4])
        with self.assertRaisesRegex(ValueError, 'FIELD_LENGTH_MISMATCH'):
            finalize_market_data(md, pd.Timestamp('2026-01-03 12:00', tz='Asia/Seoul'))

    def test_refit_after_validation_requires_revalidation(self):
        trades = self._sample_trades()
        report = validate_chronological(trades, strategy_version='v1', min_oos_covered=1)
        ordered = sorted(trades, key=lambda t: (t.decision_time, t.symbol))
        deployed = ConfidenceCalibrator().fit(trades, ordered[105].decision_time)
        binding = build_validation_binding(report, deployed, 'v1', trades)
        altered = [TradeRecord(t.symbol, t.decision_time, t.label_time, t.score, 1 - t.outcome)
                   for t in trades]
        refit = ConfidenceCalibrator().fit(altered, ordered[105].decision_time)
        engine = ApprovalEngine(refit, report, require_binding=True, strategy_version='v1')
        class Rec:
            symbol='X'; direction='LONG'; action='BUY'; signal_strength=55
        class Meta:
            symbol='X'; last_bar_ts=pd.Timestamp('2026-01-01', tz='UTC')
            collected_at=pd.Timestamp('2026-01-01 00:30', tz='UTC')
        class Trust:
            passed=True; reliability=1.0
        got = engine.evaluate(Rec(), signal_bar=Meta.last_bar_ts, meta=Meta(), trust=Trust(),
                              now=pd.Timestamp('2026-01-01 01:00', tz='UTC'), binding=binding)
        self.assertIsInstance(got, Rejection)
        self.assertTrue(any(r.startswith('REVALIDATION_REQUIRED') for r in got.reasons), got.reasons)


if __name__ == '__main__':
    unittest.main()
