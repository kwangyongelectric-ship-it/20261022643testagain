"""그림자 모니터/진단 도구 회귀 테스트(합성 관측치). 실제 감시 프로그램이나 KRX 시세를 검증하는 테스트가 아니다.
목적: 실제 환경에서 겪을 수 있는 실패 양상(정체, 반복 입력, 모의 소스, 계산 예외, 오래된 입력)이 '구분되어 드러나는지'를 고정한다."""
import contextlib, io, json, os, tempfile, threading
import numpy as np, pandas as pd

import diagnose_observations as dg
from wave import MarketData, WaveAnalysisAlgorithm
from wave_shadow_monitor import ShadowMonitor, ShadowState, normalize_legacy

T0 = pd.Timestamp("2026-10-19 09:00", tz="Asia/Seoul")


def feed(mon, n, seed=1, sym="005930", start=0, source="krx", legacy=None, step=10, base=70000.0):
    rng = np.random.default_rng(seed); p = base; st = None
    for k in range(n):
        p *= 1 + rng.normal(0, 0.002)
        st = mon.observe(sym, T0 + pd.Timedelta(seconds=step * (start + k)), round(p, 0), 1000 * (start + k + 1),
                         source=source, legacy_signal=legacy)
    return st


def test_warmup_counts_then_analyzes_with_real_model_output():
    m = ShadowMonitor(); st = feed(m, 19)
    assert (st.state, st.progress) == ("WAITING_WARMUP", "19/20") and st.analysis is None
    st = feed(m, 1, start=19)
    assert st.progress == "20/20" and st.state == "ANALYZING_OK" and st.analysis and st.recommendation
    assert st.analysis["wave_state"] in WaveAnalysisAlgorithm.STATES


def test_shadow_analysis_equals_direct_model_call_on_same_inputs():
    m = ShadowMonitor(); feed(m, 25)
    s = m._syms["005930"]; w = np.array(s.price[-20:])
    a = WaveAnalysisAlgorithm(20).process(MarketData("005930", "x", pd.DatetimeIndex(s.ts[-20:]), w, np.array(s.volume[-20:])))
    st = m.status("005930", now=s.ts[-1])
    assert st.analysis == a.to_dict() and st.analysis["current_price"] == w[-1]


def test_different_feeds_produce_different_analysis_not_constants():
    a = feed(ShadowMonitor(), 30, seed=1).analysis; b = feed(ShadowMonitor(), 30, seed=2).analysis
    assert a["k_f"] != b["k_f"] and a["v_rms"] != b["v_rms"]


def test_same_observation_repeated_is_not_counted_and_is_distinguishable_from_normal_wait():
    m = ShadowMonitor()
    for _ in range(30):
        st = m.observe("005930", T0, 70000, 1000)                  # 시각·가격 동일한 관측치 반복
    assert (st.accepted, st.duplicates, st.progress, st.state) == (1, 29, "1/20", "WAITING_WARMUP")
    assert any(w.startswith("REPEATED_OBSERVATIONS") for w in st.warnings)
    normal = feed(ShadowMonitor(), 1)
    assert normal.duplicates == 0 and not any(w.startswith("REPEATED") for w in normal.warnings)


def test_frozen_feed_price_and_volume_unchanged_with_advancing_time_is_suspect():
    m = ShadowMonitor()
    for k in range(8):
        st = m.observe("005930", T0 + pd.Timedelta(seconds=10 * k), 70000, 5000)       # 시각만 흐르고 값은 그대로
    assert st.state == "INPUT_SUSPECT" and any(r.startswith("FROZEN_FEED") for r in st.reasons) and st.analysis is None


def test_flat_price_feed_is_blocked_after_warmup():
    m = ShadowMonitor()
    for k in range(25):
        st = m.observe("005930", T0 + pd.Timedelta(seconds=10 * k), 70000, 1000 + k)   # 거래량은 변하지만 가격이 모두 같음
    assert st.state == "INPUT_SUSPECT" and any(r.startswith("FLAT_FEED") for r in st.reasons) and st.analysis is None


def test_perfect_arithmetic_ramp_is_warned_but_not_silently_trusted():
    m = ShadowMonitor()
    for k in range(25):
        st = m.observe("005930", T0 + pd.Timedelta(seconds=10 * k), 70000 + 100 * k, 1000 + k)
    assert any(w.startswith("SYNTHETIC_PATTERN") for w in st.warnings)


def test_mock_sources_are_rejected_and_never_counted():
    m = ShadowMonitor()
    for k in range(30):
        st = m.observe("005930", T0 + pd.Timedelta(seconds=k), 70000 + k, 1, source="SimulatedFeed")
    assert st.accepted == 0 and st.progress == "0/20" and st.rejected == {"MOCK_SOURCE": 30}


def test_invalid_and_out_of_order_input_is_rejected_without_exceptions():
    m = ShadowMonitor(); m.observe("A", T0, 100, 1)
    for bad in (float("nan"), 0, -5, "abc", None):
        m.observe("A", T0 + pd.Timedelta(seconds=1), bad, 1)
    m.observe("A", "garbage-ts", 100, 1)
    m.observe("A", T0 - pd.Timedelta(seconds=5), 101, 1)                  # 순서 역전
    m.observe("A", T0, 105, 1)                                            # 같은 시각, 다른 가격
    st = m.status("A", now=T0)
    assert st.accepted == 1
    assert st.rejected["INVALID_PRICE"] >= 3 and st.rejected["INVALID_NUMBER"] == 2
    assert st.rejected["INVALID_TIMESTAMP"] == 1 and st.rejected["OUT_OF_ORDER"] == 1
    assert st.rejected["TIMESTAMP_REPEAT_DIFFERENT_PRICE"] == 1


class _Boom:
    window_size = 20
    def process(self, raw): raise RuntimeError("계산 폭발")


def test_model_exception_is_recorded_not_raised_and_legacy_decision_untouched():
    m = ShadowMonitor(algorithm=_Boom())
    st = feed(m, 25, legacy="BUY")                                        # observe가 예외를 던지면 여기서 테스트 실패
    assert st.state == "MODEL_ERROR" and "RuntimeError" in st.last_error and "계산 폭발" in st.last_error
    assert st.progress == "20/20" and st.analysis is None                 # 관측치는 충분한데 분석이 못 나온다 → 오류로 구분됨
    assert m.final_decision("BUY") == "BUY"


def test_final_decision_never_overrides_legacy_in_any_state():
    for m in (ShadowMonitor(), ShadowMonitor(algorithm=_Boom())):
        for n in (0, 5, 25):
            feed(m, n, sym=f"S{n}")
            for legacy in ("BUY", "SELL", "HOLD", {"action": "SELL"}, None, "알수없음"):
                assert m.final_decision(legacy) is legacy
    st = feed(ShadowMonitor(), 25)
    assert st.advisory_only is True


def test_stale_input_is_detected_by_clock():
    m = ShadowMonitor(max_age_seconds=300); feed(m, 25)
    last = m._syms["005930"].ts[-1]
    assert m.status("005930", now=last + pd.Timedelta(seconds=60)).state == "ANALYZING_OK"
    st = m.status("005930", now=last + pd.Timedelta(minutes=10))
    assert st.state == "STALE_INPUT" and any(r.startswith("STALE_INPUT") for r in st.reasons)


def test_domain_label_flags_unvalidated_intraday_use():
    st = feed(ShadowMonitor(timeframe_label="intraday"), 25)
    assert st.domain == "UNVALIDATED_INTRADAY" and any(w.startswith("UNVALIDATED_INTRADAY") for w in st.warnings)
    st = feed(ShadowMonitor(timeframe_label="1d"), 25)
    assert st.domain == "DAILY_VALIDATED" and not any(w.startswith("UNVALIDATED") for w in st.warnings)


def test_disagreements_are_logged_with_reason_and_never_override():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "shadow.jsonl"); m = ShadowMonitor(log_path=path)
        feed(m, 19, legacy="BUY")                                         # 워밍업 중에는 비교 기록 없음
        assert not os.path.exists(path)
        feed(m, 3, start=19, legacy="BUY"); feed(m, 3, start=22, legacy="매도"); feed(m, 2, start=25, legacy="???")
        rows = [json.loads(l) for l in open(path, encoding="utf-8")]
    assert len(rows) == 8 and all(r["overridden"] is False for r in rows)
    assert {r["legacy"] for r in rows} == {"BUY", "SELL", "UNKNOWN"}
    unk = [r for r in rows if r["legacy"] == "UNKNOWN"]
    assert all(r["agree"] is None and "비교 불가" in r["note"] for r in unk)
    dis = [r for r in rows if r["agree"] is False]
    assert dis and all("legacy=" in r["disagreement_reason"] and r["wave_reason"] for r in dis)
    assert all(r["progress"] == "20/20" for r in rows)


def test_not_comparable_when_wave_has_no_valid_analysis():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "s.jsonl"); m = ShadowMonitor(log_path=path, algorithm=_Boom())
        feed(m, 25, legacy="BUY")
        assert not os.path.exists(path)                                   # 분석이 없으면 '불일치'로 기록하지 않는다


def test_log_write_failure_does_not_break_monitoring():
    with tempfile.TemporaryDirectory() as d:
        m = ShadowMonitor(log_path=d)                                     # 디렉터리를 파일처럼 열기 → 쓰기 실패
        st = feed(m, 25, legacy="BUY")
        assert st.state == "ANALYZING_OK" and m.log_errors > 0


def test_concurrent_observers_do_not_corrupt_state():
    m = ShadowMonitor(); errs = []
    def run(sym):
        try: feed(m, 40, sym=sym, seed=hash(sym) % 1000)
        except Exception as e: errs.append(e)
    th = [threading.Thread(target=run, args=(f"S{i}",)) for i in range(6)]
    [t.start() for t in th]; [t.join() for t in th]
    assert not errs and all(m.status(f"S{i}", now=m._syms[f"S{i}"].ts[-1]).accepted == 40 for i in range(6))


def test_normalize_legacy_variants():
    assert [normalize_legacy(x) for x in ("매수", "buy", {"signal": "SELL"}, None, "관망", "???")] == ["BUY", "BUY", "SELL", "HOLD", "HOLD", "UNKNOWN"]


# ---- 진단 CLI ----
def _csv(rows, d, name="obs.csv"):
    p = os.path.join(d, name); pd.DataFrame(rows).to_csv(p, index=False); return p

def _run(path, *extra):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = dg.main([path, *extra])
    return rc, buf.getvalue()

def test_cli_healthy_feed_exits_zero_and_reports_analysis():
    rng = np.random.default_rng(5); p = 70000.0; rows = []
    for k in range(30):
        p *= 1 + rng.normal(0, .002)
        rows.append({"timestamp": str(T0 + pd.Timedelta(seconds=10 * k)), "price": round(p), "volume": 1000 * (k + 1), "source": "krx"})
    with tempfile.TemporaryDirectory() as d:
        rc, out = _run(_csv(rows, d))
    assert rc == 0 and "ANALYZING_OK" in out and "분석:" in out and "20/20" in out

def test_cli_repeated_same_row_exits_nonzero_and_says_so():
    rows = [{"timestamp": str(T0), "price": 70000, "volume": 1000, "source": "krx"}] * 25
    with tempfile.TemporaryDirectory() as d:
        rc, out = _run(_csv(rows, d))
    assert rc == 2 and "같은 관측치 재입력 24" in out and "1/20" in out and "REPEATED_OBSERVATIONS" in out

def test_cli_frozen_and_mock_feeds_are_flagged():
    frozen = [{"timestamp": str(T0 + pd.Timedelta(seconds=10 * k)), "price": 70000, "volume": 5000, "source": "krx"} for k in range(30)]
    mock = [{"timestamp": str(T0 + pd.Timedelta(seconds=10 * k)), "price": 70000 + k, "volume": k, "source": "mock_krx"} for k in range(30)]
    with tempfile.TemporaryDirectory() as d:
        rc1, o1 = _run(_csv(frozen, d, "f.csv")); rc2, o2 = _run(_csv(mock, d, "m.csv"))
    assert rc1 == 2 and "FROZEN_FEED" in o1
    assert rc2 == 2 and "MOCK_SOURCE" in o2 and "0/20" in o2
