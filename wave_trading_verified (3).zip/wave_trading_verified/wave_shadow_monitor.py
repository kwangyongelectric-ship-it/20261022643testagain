"""
wave_shadow_monitor.py — 기존 장중 감시 프로그램을 건드리지 않는 '그림자(shadow)' 어댑터
=====================================================================================

목적: 새 파동 모델이 실제 시세를 받아 '실제로' 분석하는지 관찰하고, 기존 모델과의 신호를 나란히 기록한다.
원칙
  1. 읽기 전용 관찰자. 기존 수집·감시 경로를 수정하지 않는다. observe()는 예외를 밖으로 던지지 않는다.
  2. 기존 매매 판단을 덮어쓰지 않는다. final_decision(legacy)는 항상 legacy를 그대로 돌려준다.
  3. 입력부터 의심한다: 모의 소스, 같은 관측치 반복, 얼어붙은 피드, 순서 역전, 정체를 상태로 드러낸다.
  4. "대기"와 "정체"와 "오류"를 구분한다: WAITING_WARMUP(n/20) / INPUT_SUSPECT / MODEL_ERROR.
  5. 신호 불일치를 사유와 함께 JSONL로 남긴다(일치/비교 불가도 기록).

★ 도메인 경고: 이 모델은 '확정 일봉' 입력으로만 검증되었다(합성 데이터 기준). 장중 관측치(스냅샷)를 20개 모아 넣는 것은
  검증된 사용 방식이 아니다. timeframe_label이 "1d"가 아니면 모든 상태에 UNVALIDATED_INTRADAY가 표시된다.
"""
from __future__ import annotations

import json
import math
import threading
import traceback
from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd

try:                                     # 평평한 레이아웃(wave.py) / 패키지 레이아웃 모두 지원
    from wave import MarketData, PositionRecommender, WaveAnalysisAlgorithm
except ImportError:                      # pragma: no cover
    from wave_analysis import MarketData, PositionRecommender, WaveAnalysisAlgorithm  # type: ignore

VALIDATED_TIMEFRAME = "1d"


class ShadowState(str, Enum):
    WAITING_WARMUP = "WAITING_WARMUP"      # 정상 대기: 관측치 n/window
    ANALYZING_OK = "ANALYZING_OK"          # 입력 정상 + 분석 성공
    INPUT_SUSPECT = "INPUT_SUSPECT"        # 모의/얼어붙은/평평한 피드 등 → 분석 차단
    STALE_INPUT = "STALE_INPUT"            # 마지막 관측이 너무 오래됨
    MODEL_ERROR = "MODEL_ERROR"            # 분석 중 예외


@dataclass
class ShadowStatus:
    symbol: str
    state: str
    progress: str                          # 예: "7/20"
    accepted: int
    duplicates: int
    rejected: Dict[str, int]
    last_ts: Optional[str]
    last_price: Optional[float]
    domain: str                            # DAILY_VALIDATED | UNVALIDATED_INTRADAY
    reasons: List[str] = field(default_factory=list)      # 상태의 사유(차단 사유)
    warnings: List[str] = field(default_factory=list)     # 차단하지 않는 경고
    analysis: Optional[Dict[str, Any]] = None
    recommendation: Optional[Dict[str, Any]] = None
    last_error: Optional[str] = None
    advisory_only: bool = True             # 항상 True: 이 객체는 주문/매매 판단에 쓰이지 않는다

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


_BUY = {"BUY", "LONG", "ENTER", "매수", "B"}
_SELL = {"SELL", "SHORT", "EXIT", "TAKE_PROFIT", "매도", "S"}


def normalize_legacy(sig: Any) -> str:
    """기존 모델의 신호 표현(문자열/딕셔너리)을 BUY/SELL/HOLD로 정규화. 알 수 없으면 UNKNOWN."""
    if isinstance(sig, dict):
        sig = sig.get("action") or sig.get("signal") or sig.get("direction")
    if sig is None:
        return "HOLD"
    t = str(sig).strip().upper().replace(" ", "")
    if t in {"", "HOLD", "WAIT", "NONE", "FLAT", "관망", "N"}:
        return "HOLD"
    if t in {x.upper() for x in _BUY}:
        return "BUY"
    if t in {x.upper() for x in _SELL}:
        return "SELL"
    return "UNKNOWN"


def normalize_wave(rec) -> str:
    if rec.direction == "LONG" and rec.action == "BUY":
        return "BUY"
    if rec.action in ("SELL", "TAKE_PROFIT"):
        return "SELL"
    return "HOLD"


class _Sym:
    def __init__(self):
        self.ts: List[pd.Timestamp] = []
        self.price: List[float] = []
        self.volume: List[float] = []
        self.pairs: List[tuple] = []          # (price, volume) 최근 값
        self.duplicates = 0
        self.rejected: Dict[str, int] = {}
        self.state = ShadowState.WAITING_WARMUP
        self.reasons: List[str] = []
        self.warnings: List[str] = []
        self.analysis = None
        self.recommendation = None
        self.last_error: Optional[str] = None


class ShadowMonitor:
    def __init__(self, window_size: int = 20, timeframe_label: str = "intraday",
                 max_age_seconds: float = 300.0, naive_tz: str = "Asia/Seoul",
                 log_path: Optional[str] = None, frozen_run: int = 5, flat_run: int = 10, linear_run: int = 10,
                 mock_markers=("mock", "sim", "demo", "fake", "dummy", "test", "random"),
                 algorithm=None, recommender=None, clock: Optional[Callable[[], pd.Timestamp]] = None,
                 max_buffer: int = 5000):
        self.window = window_size
        self.timeframe_label = timeframe_label
        self.max_age = pd.Timedelta(seconds=max_age_seconds)
        self.naive_tz = naive_tz
        self.log_path = log_path
        self.frozen_run, self.flat_run, self.linear_run = frozen_run, flat_run, linear_run
        self.mock_markers = tuple(m.lower() for m in mock_markers)
        self.algorithm = algorithm or WaveAnalysisAlgorithm(window_size=window_size)
        self.recommender = recommender or PositionRecommender()
        self.clock = clock or (lambda: pd.Timestamp.now(tz="UTC"))
        self.max_buffer = max_buffer
        self._syms: Dict[str, _Sym] = {}
        self._lock = threading.Lock()
        self.log_errors = 0

    # ------------------------------------------------------------------
    @property
    def domain(self) -> str:
        return "DAILY_VALIDATED" if self.timeframe_label == VALIDATED_TIMEFRAME else "UNVALIDATED_INTRADAY"

    def final_decision(self, legacy_signal: Any) -> Any:
        """그림자 모델은 기존 매매 판단을 덮어쓰지 않는다. 어떤 상태에서도 입력을 그대로 반환한다."""
        return legacy_signal

    def _reject(self, s: _Sym, why: str) -> None:
        s.rejected[why] = s.rejected.get(why, 0) + 1

    def _to_ts(self, ts) -> Optional[pd.Timestamp]:
        try:
            t = pd.Timestamp(ts)
            if pd.isna(t):
                return None
            t = t.tz_localize(self.naive_tz) if t.tzinfo is None else t
            return t.tz_convert("UTC")
        except Exception:
            return None

    # ------------------------------------------------------------------
    def observe(self, symbol: str, ts, price, volume=0.0, source: str = "krx",
                legacy_signal: Any = None) -> ShadowStatus:
        """관측치 1건 입력. 절대 예외를 던지지 않는다(기존 감시 루프 보호)."""
        try:
            with self._lock:
                s = self._syms.setdefault(symbol, _Sym())
                self._observe_locked(s, symbol, ts, price, volume, source, legacy_signal)
                return self._status_locked(s, symbol)
        except Exception as exc:                       # 어댑터 자체 결함이 감시 루프를 깨뜨리지 않게
            s = self._syms.setdefault(symbol, _Sym())
            s.state = ShadowState.MODEL_ERROR
            s.last_error = f"ADAPTER:{type(exc).__name__}: {exc}"
            return self._status_locked(s, symbol)

    def _observe_locked(self, s: _Sym, symbol, ts, price, volume, source, legacy_signal):
        if any(m in str(source).lower() for m in self.mock_markers):
            self._reject(s, "MOCK_SOURCE"); return
        t = self._to_ts(ts)
        if t is None:
            self._reject(s, "INVALID_TIMESTAMP"); return
        try:
            p, v = float(price), float(volume)
        except (TypeError, ValueError):
            self._reject(s, "INVALID_NUMBER"); return
        if not math.isfinite(p) or p <= 0:
            self._reject(s, "INVALID_PRICE"); return
        if not math.isfinite(v) or v < 0:
            self._reject(s, "INVALID_VOLUME"); return
        if s.ts:
            if t < s.ts[-1]:
                self._reject(s, "OUT_OF_ORDER"); return
            if t == s.ts[-1]:
                if p == s.price[-1]:
                    s.duplicates += 1; return            # 같은 관측치 재입력: 새 관측치로 세지 않는다
                self._reject(s, "TIMESTAMP_REPEAT_DIFFERENT_PRICE"); return
        s.ts.append(t); s.price.append(p); s.volume.append(v); s.pairs.append((p, v))
        if len(s.ts) > self.max_buffer:
            for lst in (s.ts, s.price, s.volume, s.pairs):
                del lst[: len(lst) - self.max_buffer]
        self._evaluate(s, symbol, legacy_signal)

    # ------------------------------------------------------------------
    def _evaluate(self, s: _Sym, symbol: str, legacy_signal: Any) -> None:
        s.reasons, s.warnings = [], []
        if self.domain != "DAILY_VALIDATED":
            s.warnings.append("UNVALIDATED_INTRADAY: 모델은 확정 일봉 입력으로만 검증됨(장중 관측치 입력은 미검증)")
        n = len(s.price)
        # 얼어붙은 피드: (가격, 누적거래량)이 연속으로 동일 — 워밍업 전에도 검사
        if n >= self.frozen_run and len(set(s.pairs[-self.frozen_run:])) == 1 and s.pairs[-1][1] > 0:
            s.reasons.append(f"FROZEN_FEED: 최근 {self.frozen_run}개 관측의 (가격, 거래량)이 동일 — 상류 갱신 정지 의심")
        if n < self.window:
            s.state = ShadowState.INPUT_SUSPECT if s.reasons else ShadowState.WAITING_WARMUP
            s.analysis = s.recommendation = None
            return
        w = np.array(s.price[-self.window:])
        if n >= self.flat_run and float(np.ptp(s.price[-self.flat_run:])) == 0.0:
            s.reasons.append(f"FLAT_FEED: 최근 {self.flat_run}개 관측 가격이 모두 동일")
        if n >= self.linear_run:
            tail = np.array(s.price[-self.linear_run:])
            d2 = np.diff(tail, 2)
            if np.ptp(tail) > 0 and np.allclose(d2, 0.0, atol=1e-9 * max(1.0, float(np.abs(tail).max()))):
                s.warnings.append(f"SYNTHETIC_PATTERN: 최근 {self.linear_run}개가 완전한 등차수열 — 모의 데이터 가능성")
        if len(set(np.round(w, 6))) < 3:
            s.warnings.append("LOW_VARIANCE: 분석 창 내 서로 다른 가격이 3개 미만")
        if s.reasons:
            s.state = ShadowState.INPUT_SUSPECT; s.analysis = s.recommendation = None
            return
        try:
            md = MarketData(symbol, self.timeframe_label, pd.DatetimeIndex(s.ts[-self.window:]), w,
                            np.array(s.volume[-self.window:]))
            a = self.algorithm.process(md)
            rec = self.recommender.generate(a, timeframe=self.timeframe_label)
        except Exception as exc:
            s.state = ShadowState.MODEL_ERROR
            s.last_error = f"{type(exc).__name__}: {exc} | {traceback.format_exc().strip().splitlines()[-3].strip()}"
            s.analysis = s.recommendation = None
            return
        s.state, s.last_error = ShadowState.ANALYZING_OK, None
        s.analysis, s.recommendation = a.to_dict(), rec.to_dict()
        if legacy_signal is not None:
            self._log_comparison(s, symbol, legacy_signal)

    # ------------------------------------------------------------------
    def _log_comparison(self, s: _Sym, symbol: str, legacy_signal: Any) -> None:
        L = normalize_legacy(legacy_signal); W = normalize_wave(_Rec(s.recommendation))
        agree = (L == W)
        row = {"ts": str(s.ts[-1]), "symbol": symbol, "legacy_raw": str(legacy_signal), "legacy": L, "wave": W,
               "agree": agree, "wave_state": s.analysis["wave_state"], "wave_action": s.recommendation["action"],
               "wave_reason": s.recommendation["reason"], "signal_strength": s.recommendation["signal_strength"],
               "progress": f"{min(len(s.price), self.window)}/{self.window}", "domain": self.domain,
               "warnings": list(s.warnings), "overridden": False}
        if L == "UNKNOWN":
            row["agree"] = None; row["note"] = "legacy 신호를 해석할 수 없어 비교 불가"
        elif not agree:
            row["disagreement_reason"] = f"legacy={L} vs wave={W} (action={row['wave_action']}; {row['wave_reason']})"
        if self.log_path:
            try:
                with open(self.log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")
            except Exception:
                self.log_errors += 1               # 로그 실패가 감시를 깨뜨리지 않는다
        s.last_comparison = row                    # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    def _status_locked(self, s: _Sym, symbol: str, now: Optional[pd.Timestamp] = None) -> ShadowStatus:
        state, reasons = s.state, list(s.reasons)
        if s.ts and now is not None and now - s.ts[-1] > self.max_age and state != ShadowState.MODEL_ERROR:
            state = ShadowState.STALE_INPUT
            reasons.append(f"STALE_INPUT: 마지막 관측 {s.ts[-1]} 이후 {now - s.ts[-1]} 경과 > {self.max_age}")
        warns = list(s.warnings)
        if s.duplicates >= 3:
            warns.append(f"REPEATED_OBSERVATIONS: 같은 관측치(시각·가격 동일)가 {s.duplicates}회 재입력됨 — 새 관측치가 아님")
        return ShadowStatus(
            symbol=symbol, state=state.value, progress=f"{min(len(s.price), self.window)}/{self.window}",
            accepted=len(s.price), duplicates=s.duplicates, rejected=dict(s.rejected),
            last_ts=str(s.ts[-1]) if s.ts else None, last_price=s.price[-1] if s.price else None,
            domain=self.domain, reasons=reasons, warnings=warns, analysis=s.analysis,
            recommendation=s.recommendation, last_error=s.last_error)

    def status(self, symbol: str, now: Optional[pd.Timestamp] = None) -> ShadowStatus:
        with self._lock:
            s = self._syms.setdefault(symbol, _Sym())
            return self._status_locked(s, symbol, self.clock() if now is None else pd.Timestamp(now))


class _Rec:                                     # dict → 속성 접근 (normalize_wave용)
    def __init__(self, d): self.__dict__.update(d)
