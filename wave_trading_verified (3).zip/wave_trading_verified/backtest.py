"""WaveBacktester v3: causal execution, fixed position size, target/stop exits."""
from __future__ import annotations
from typing import Any, Dict, List
import numpy as np

class WaveBacktester:
    FEE = 0.00015

    def __init__(self, algorithm, recommender, initial_capital: float = 100_000_000.0):
        self.algorithm = algorithm
        self.recommender = recommender
        self.initial_capital = initial_capital
        self.last_run: Dict[str, Any] | None = None

    def run(self, raw, evaluation_start: int = 0) -> Dict[str, Any]:
        analyses = self.algorithm.rolling_analyses(raw)
        close = np.asarray(raw.close, dtype=float)
        w = self.algorithm.window_size
        if evaluation_start < 0 or evaluation_start > len(close):
            raise ValueError("evaluation_start 범위 오류")

        equity = [self.initial_capital]
        positions: List[float] = []
        decisions: List[Dict[str, Any]] = []
        trades = wins = 0
        in_market = False
        held_size = 0.0
        entry_price = None
        target = None
        stop = None

        # Analysis at t uses close[0:i-1], where i=t+w.
        # Exposure for bar i is therefore decided before close[i] exists.
        for t, a in enumerate(analyses):
            i = t + w
            prev_close = float(close[i - 1])
            current_close = float(close[i])

            # 1) Exit decisions are made using prev_close, which is known
            # before the return from prev_close -> current_close is earned.
            exit_reason = None
            exit_price = None
            if in_market:
                if prev_close >= target:
                    exit_reason, exit_price = "TARGET", prev_close
                elif prev_close <= stop:
                    exit_reason, exit_price = "STOP", prev_close

            rec = self.recommender.generate(a, raw.timeframe)
            wants_long = rec.direction == "LONG" and rec.action == "BUY"

            # A recommendation to stop being BUY is also causal: it is known
            # at the decision timestamp and closes before the next bar return.
            if in_market and exit_reason is None and not wants_long:
                exit_reason, exit_price = "SIGNAL", prev_close

            fee = 0.0
            if exit_reason is not None:
                if exit_price is not None and entry_price is not None and exit_price > entry_price:
                    wins += 1
                fee += self.FEE * held_size
                in_market = False
                held_size = 0.0
                entry_price = target = stop = None

            # New entries are based only on the current causal recommendation.
            if not in_market and wants_long and i >= evaluation_start:
                held_size = float(max(0.0, min(1.0, rec.position_size)))
                if held_size > 0:
                    in_market = True
                    entry_price = prev_close
                    target = float(rec.target_price)
                    stop = float(rec.stop_loss)
                    trades += 1
                    fee += self.FEE * held_size

            # Position size is FIXED during an open trade. A later recommender
            # size change cannot silently resize the existing position.
            exposure = held_size if in_market else 0.0
            ret = current_close / prev_close - 1.0

            # Warm-up bars are processed to establish state but do not enter
            # the evaluation equity curve.
            if i < evaluation_start:
                positions.append(exposure)
                decisions.append({
                    "index": i, "position": exposure, "direction": rec.direction,
                    "action": rec.action, "position_size": rec.position_size,
                    "held_size": held_size, "entry_price": rec.entry_price,
                    "target_price": rec.target_price, "stop_loss": rec.stop_loss,
                    "risk_reward": rec.risk_reward, "signal_strength": rec.signal_strength,
                    "exit_reason": exit_reason,
                })
                continue

            equity.append(equity[-1] * (1.0 + exposure * ret - fee))
            positions.append(exposure)
            decisions.append({
                "index": i, "position": exposure, "direction": rec.direction,
                "action": rec.action, "position_size": rec.position_size,
                "held_size": held_size, "entry_price": rec.entry_price,
                "target_price": rec.target_price, "stop_loss": rec.stop_loss,
                "risk_reward": rec.risk_reward, "signal_strength": rec.signal_strength,
                "exit_reason": exit_reason,
            })

        eq = np.asarray(equity)
        step_returns = np.diff(eq) / eq[:-1] if len(eq) > 1 else np.array([])
        total = eq[-1] / eq[0] - 1.0
        n = len(step_returns)
        ann = (1 + total) ** (252 / max(n, 1)) - 1.0 if n else 0.0
        vol = float(np.std(step_returns) * np.sqrt(252)) if n else 0.0
        peak = np.maximum.accumulate(eq)
        mdd = float(np.max((peak - eq) / peak)) if len(eq) else 0.0
        sharpe = ann / vol if vol > 0 else 0.0
        result = {
            "symbol": raw.symbol, "final_equity": round(float(eq[-1]), 2),
            "total_return_pct": round(total * 100, 2),
            "annualized_return_pct": round(ann * 100, 2),
            "annualized_vol_pct": round(vol * 100, 2),
            "sharpe": round(float(sharpe), 4),
            "max_drawdown_pct": round(mdd * 100, 2),
            "trades": int(trades),
            "win_rate_pct": round(wins / trades * 100, 1) if trades else 0.0,
            "positions": positions, "decisions": decisions,
        }
        self.last_run = result
        return result
