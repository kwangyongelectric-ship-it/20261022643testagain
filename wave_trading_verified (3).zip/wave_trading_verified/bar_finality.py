"""
bar_finality.py — 봉 확정 여부 판정 + 수집 메타(CollectionMeta) 기록
====================================================================

규칙: 확정되지 않은 봉은 분석 계층에 들어가지 않는다.
  - '오늘' 봉은 장 마감 + 확정 버퍼 이후에만 확정으로 본다.
  - 미래 날짜 봉은 항상 제거한다.
  - 제거 내역과 수집 시각을 CollectionMeta로 남긴다(감사/승인 게이트에서 사용).

MarketData 계약은 바꾸지 않는다. 메타는 별도 객체로 함께 전달한다.
현재는 일봉("1d")만 지원한다. 분봉은 명시적으로 거부한다(조용히 틀리는 것보다 낫다).
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields, is_dataclass, replace
from datetime import datetime, time, timedelta
import inspect
from typing import Callable, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    from data_collection import DataSourceError
except ImportError:                                  # 수집 모듈 없이 단독 사용 시
    class DataSourceError(RuntimeError):             # type: ignore
        pass


class UnconfirmedDataError(DataSourceError):
    """확정된 봉이 하나도 없음."""


@dataclass(frozen=True)
class SessionSpec:
    """시장 세션 정의. 기본값은 KRX 정규장(15:30 마감).
    confirm_buffer_min은 소스가 확정 종가를 반영하는 지연이며 '제안값'이다.
    실제 소스별 반영 시각을 관측해 조정할 것."""
    tz: str = "Asia/Seoul"
    close_time: time = time(15, 30)
    confirm_buffer_min: int = 30

    def confirm_time(self) -> time:
        base = datetime.combine(datetime(2000, 1, 3).date(), self.close_time)
        t = base + timedelta(minutes=self.confirm_buffer_min)
        if t.date() != base.date():
            raise ValueError("확정 시각이 자정을 넘습니다.")
        return t.time()


KRX = SessionSpec()


@dataclass(frozen=True)
class CollectionMeta:
    symbol: str
    source: str
    collected_at: pd.Timestamp              # tz-aware
    session_tz: str
    last_bar_ts: pd.Timestamp               # 확정된 마지막 봉
    n_bars: int
    n_dropped_unconfirmed: int
    dropped_bar_ts: Tuple[pd.Timestamp, ...] = field(default_factory=tuple)


def _local_now(now: pd.Timestamp, session: SessionSpec) -> pd.Timestamp:
    now = pd.Timestamp(now)
    if now.tzinfo is None:
        return now.tz_localize(session.tz)
    return now.tz_convert(session.tz)


def confirmed_mask(timestamps, now, session: SessionSpec = KRX) -> np.ndarray:
    """봉별 확정 여부(bool 배열). 일봉 가정(타임스탬프의 '날짜'만 사용)."""
    ln = _local_now(now, session)
    today = ln.tz_localize(None).normalize()
    dates = pd.DatetimeIndex(timestamps)
    if dates.tz is not None:
        dates = dates.tz_convert(session.tz).tz_localize(None)
    dates = dates.normalize()
    mask = np.asarray(dates < today)
    if ln.time() >= session.confirm_time():
        mask = mask | np.asarray(dates == today)
    return mask


def strip_unconfirmed_ohlcv(df: pd.DataFrame, now, session: SessionSpec = KRX) -> pd.DataFrame:
    """data_collector_ohlcv용(DataFrame, DatetimeIndex): 저장/반환 전에 미확정 봉 제거."""
    if df is None or df.empty:
        return df
    return df.loc[confirmed_mask(df.index, now, session)]


TIMED_FIELDS = ("open", "high", "low", "close", "volume")
_TIME_ALIGNED_FIELDS = set(TIMED_FIELDS)
_SEQUENCE_TYPES = (list, tuple, np.ndarray, pd.Series, pd.Index)


def _slice_aligned(value, mask: np.ndarray):
    """Slice a known aligned field while preserving common container types."""
    if isinstance(value, pd.Series):
        return value.iloc[np.flatnonzero(mask)].copy()
    if isinstance(value, np.ndarray):
        return value[mask].copy()
    if isinstance(value, list):
        return [item for item, keep in zip(value, mask) if keep]
    if isinstance(value, tuple):
        return tuple(item for item, keep in zip(value, mask) if keep)
    try:
        return value[mask].copy()
    except (TypeError, AttributeError, IndexError, KeyError) as exc:
        raise TypeError(f"시간 정렬 필드를 안전하게 자를 수 없습니다: {type(value).__name__}") from exc


def _rebuild_masked_market_data(md, mask: np.ndarray, timestamps: pd.DatetimeIndex):
    """화이트리스트 계약으로 MarketData를 재구성한다.

    TIMED_FIELDS만 시간 마스크를 적용한다. 선언되지 않은 모든 시퀀스는
    길이와 무관하게 거부하여 조용한 정렬 불일치를 막는다.
    """
    updates = {"timestamps": timestamps[mask]}
    n = len(pd.DatetimeIndex(md.timestamps))
    values = vars(md)
    for name, value in values.items():
        if name in {"timestamps", "symbol", "timeframe"}:
            continue
        if name in _TIME_ALIGNED_FIELDS:
            try:
                value_len = len(value)
            except (TypeError, AttributeError) as exc:
                raise ValueError(f"FIELD_LENGTH_MISMATCH: {name} 필드가 시퀀스가 아닙니다.") from exc
            if value_len != n:
                raise ValueError(f"FIELD_LENGTH_MISMATCH: {name} {value_len} != {n}")
            updates[name] = _slice_aligned(value, mask)
        elif isinstance(value, _SEQUENCE_TYPES):
            raise ValueError(
                f"UNDECLARED_SEQUENCE_FIELD: {name!r} — 정렬 여부를 알 수 없는 시퀀스. "
                "TIMED_FIELDS에 추가하거나 컬렉션에서 제거할 것"
            )

    if is_dataclass(md):
        valid_names = {f.name for f in fields(md)}
        return replace(md, **{k: v for k, v in updates.items() if k in valid_names})

    try:
        sig = inspect.signature(type(md))
        kwargs = {}
        for name, param in sig.parameters.items():
            if name in updates:
                kwargs[name] = updates[name]
            elif hasattr(md, name):
                value = getattr(md, name)
                if name in _TIME_ALIGNED_FIELDS:
                    if len(value) != n:
                        raise ValueError(f"FIELD_LENGTH_MISMATCH: {name} {len(value)} != {n}")
                    kwargs[name] = _slice_aligned(value, mask)
                elif isinstance(value, _SEQUENCE_TYPES):
                    raise ValueError(f"UNDECLARED_SEQUENCE_FIELD: {name!r}")
                else:
                    kwargs[name] = value
            elif param.default is inspect.Parameter.empty:
                raise TypeError(f"MarketData 생성자 필수 필드 '{name}'를 보존할 수 없습니다.")
        return type(md)(**kwargs)
    except (ValueError, TypeError) as exc:
        # Preserve the machine-readable contract code in the exception chain/message.
        raise type(exc)(str(exc)) from exc


def finalize_market_data(md, collected_at, source: str = "unknown",
                         session: SessionSpec = KRX):
    """MarketData → (확정 봉만 남긴 MarketData, CollectionMeta)."""
    if md.timeframe != "1d":
        raise NotImplementedError(f"봉 확정 판정은 일봉만 지원합니다: {md.timeframe!r}")
    mask = confirmed_mask(md.timestamps, collected_at, session)
    ts = pd.DatetimeIndex(md.timestamps)
    if not mask.any():
        raise UnconfirmedDataError(f"{md.symbol}: 확정된 봉이 없습니다.")
    dropped = tuple(ts[~mask])
    out = _rebuild_masked_market_data(md, mask, ts)
    meta = CollectionMeta(
        symbol=md.symbol, source=source,
        collected_at=_local_now(collected_at, session), session_tz=session.tz,
        last_bar_ts=pd.Timestamp(ts[mask][-1]), n_bars=int(mask.sum()),
        n_dropped_unconfirmed=int((~mask).sum()), dropped_bar_ts=dropped)
    return out, meta


class ConfirmedDataCollector:
    """기존 DataCollector(.sources, .min_bars)를 감싸서 (MarketData, CollectionMeta)를 돌려준다.
    폴백 순서와 최소 봉 수 규칙은 그대로 두고, '확정 봉 기준으로' 최소 봉 수를 다시 검사한다."""

    def __init__(self, collector, session: SessionSpec = KRX,
                 clock: Optional[Callable[[], pd.Timestamp]] = None):
        self.collector, self.session = collector, session
        self.clock = clock or (lambda: pd.Timestamp.now(tz=session.tz))

    def collect(self, symbol: str, lookback_days: int = 365, end=None):
        errors: List[str] = []
        for src in self.collector.sources:
            try:
                collected_at = self.clock()              # 소스 호출 직전 시각을 기록
                md = src.fetch(symbol, lookback_days, end)
                md, meta = finalize_market_data(md, collected_at, src.name, self.session)
                if len(md.close) < self.collector.min_bars:
                    raise DataSourceError(
                        f"{symbol}: 확정 {len(md.close)}봉 < 최소 {self.collector.min_bars}봉")
                return md, meta
            except DataSourceError as e:
                errors.append(f"[{src.name}] {e}")
        raise DataSourceError(f"{symbol}: 모든 소스 실패 → " + " | ".join(errors))
