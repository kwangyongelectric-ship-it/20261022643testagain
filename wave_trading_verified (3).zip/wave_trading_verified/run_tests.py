"""run_tests.py — 모든 테스트 파일을 '각각 별도 프로세스'로 실행하고 요약한다.
사용: python run_tests.py        (종료 코드 0 = 전부 통과)
- 파일별로 프로세스를 분리해 모듈 캐시/경로 오염을 막는다.
- 각 파일의 test_* 함수와 unittest.TestCase를 모두 실행한다
  (파일 안의 `if __name__ == "__main__"` 위치와 무관하게 전부 수집)."""
import glob, importlib, inspect, os, subprocess, sys, unittest

HERE = os.path.dirname(os.path.abspath(__file__))


def run_one(modname: str) -> int:
    sys.path.insert(0, HERE)
    mod = importlib.import_module(modname)
    passed = failed = 0
    for name, fn in sorted(vars(mod).items()):
        if name.startswith("test_") and inspect.isfunction(fn):
            try:
                fn(); passed += 1; print(f"  PASS {name}")
            except Exception as e:
                failed += 1; print(f"  FAIL {name}: {type(e).__name__}: {str(e)[:120]}")
    for name, cls in sorted(vars(mod).items()):
        if inspect.isclass(cls) and issubclass(cls, unittest.TestCase):
            res = unittest.TextTestRunner(stream=open(os.devnull, "w")).run(
                unittest.defaultTestLoader.loadTestsFromTestCase(cls))
            passed += res.testsRun - len(res.failures) - len(res.errors)
            failed += len(res.failures) + len(res.errors)
            for t, tb in res.failures + res.errors:
                print(f"  FAIL {t.id().split('.')[-1]}: {tb.strip().splitlines()[-1][:120]}")
            print(f"  (unittest {cls.__name__}: {res.testsRun}개)")
    print(f"RESULT {modname} passed={passed} failed={failed}")
    return 1 if failed or passed == 0 else 0


def main() -> int:
    if len(sys.argv) == 3 and sys.argv[1] == "--one":
        return run_one(sys.argv[2])
    rows, rc = [], 0
    for path in sorted(glob.glob(os.path.join(HERE, "test_*.py"))):
        mod = os.path.splitext(os.path.basename(path))[0]
        p = subprocess.run([sys.executable, os.path.abspath(__file__), "--one", mod],
                           capture_output=True, text=True, cwd=HERE)
        line = next((l for l in p.stdout.splitlines() if l.startswith("RESULT")), None)
        if p.returncode != 0:
            rc = 1
            print(p.stdout.strip().replace("INFO ", "")[-1500:]); print(p.stderr.strip()[-600:])
        rows.append(line or f"RESULT {mod} 실행 실패 (returncode={p.returncode})")
    print("\n".join(rows)); print("전체:", "통과" if rc == 0 else "실패 있음")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
