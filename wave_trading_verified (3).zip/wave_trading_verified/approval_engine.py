"""
approval_engine.py — 승인 게이트 (엔진에서 강제)
================================================

규칙: '승인된 포지션 제안(ApprovedPosition)'은 이 엔진을 통과해야만 만들어진다.
  - 대시보드/주문 계층은 ApprovedPosition만 받는다. 직접 생성하면 PermissionError.
  - 아래 조건을 전부 만족해야 승인된다. 거절 사유는 단락 평가 없이 전부 모은다.

  1. 추천이 실행 가능한가(LONG/BUY)
  2. 신호가 '확정된 마지막 봉'에서 나왔는가 (미확정 봉 사용 금지)
  3. 데이터 신뢰도 검증(TrustReport) 통과
  4. 시간순 OOS 검증(ValidationReport) 통과
  5. 해당 점수 구간이 CALIBRATED (표본 부족/범위 밖이면 UNVERIFIED → 거절)
  6. 보정 확률 p가 하한 이상
  7. 수집 시각이 너무 오래되지 않았는가

Python에는 진짜 접근 제어가 없으므로 토큰 검사는 '실수 방지'이지 보안 경계가 아니다.
실제 주문 계층에서는 이 게이트의 출력만 입력으로 받도록 타입/인터페이스를 고정할 것.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any, List, Optional, Sequence, Union

import pandas as pd

from position_confidence import (
    CalStatus, ConfidenceCalibrator, ValidationReport, ValidationBinding,
    calibrator_state_hash,
)

_GATE_TOKEN = object()

# Dashboard and monitoring layers should use this shared mapping rather than
# interpreting gate reasons independently. A gate rejection remains non-approvable;
# VALIDATION_MISMATCH is classified as requiring revalidation for display/workflow.
VERDICT_BY_REASON_PREFIX = {
    "VALIDATION_MISMATCH": "REVALIDATION_REQUIRED",
    "REVALIDATION_REQUIRED": "REVALIDATION_REQUIRED",
    "VALIDATION_BINDING_MISSING": "UNVERIFIED",
    "CALIBRATION_UNVERIFIED": "UNVERIFIED",
    "VALIDATION_MISSING": "UNVERIFIED",
    "DATA_UNTRUSTED": "REJECTED",
    "BAR_UNCONFIRMED": "REJECTED",
    "INVALID_COLLECTION_TIME": "REJECTED",
    "STALE_COLLECTION": "REJECTED",
    "VALIDATION_FAILED": "REJECTED",
    "LOW_CONFIDENCE": "REJECTED",
    "LOW_CONFIDENCE_LOWER_BOUND": "REJECTED",
}


def verdict_for_reasons(reasons, binding_status: Optional[str] = None) -> str:
    """Dashboard classification. Empty reasons alone never imply verification."""
    if not reasons:
        if binding_status == "VERIFIED_MATCH":
            return "APPROVED_VERIFIED_MATCH"
        if binding_status == "BINDING_MISSING":
            return "CONDITIONALLY_APPROVED_NO_BINDING"
        if binding_status == "BINDING_CONSISTENT":
            return "CONDITIONALLY_APPROVED"
        return "UNVERIFIED"
    verdicts = []
    for reason in reasons:
        prefix = str(reason).split(":", 1)[0]
        verdicts.append(VERDICT_BY_REASON_PREFIX.get(prefix, "REJECTED"))
    if "REJECTED" in verdicts:
        return "REJECTED"
    if "REVALIDATION_REQUIRED" in verdicts:
        return "REVALIDATION_REQUIRED"
    return "UNVERIFIED"


@dataclass(frozen=True)
class ApprovedPosition:
    recommendation: Any
    calibrated_p: float
    p_lower: float
    support_range: tuple
    validation_id: str
    data_reliability: float
    signal_bar: pd.Timestamp
    collected_at: pd.Timestamp
    binding_status: str = "UNVERIFIED"
    _token: object = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        if self._token is not _GATE_TOKEN:
            raise PermissionError("ApprovedPosition은 ApprovalEngine만 생성할 수 있습니다.")


@dataclass(frozen=True)
class Rejection:
    symbol: str
    reasons: tuple
    calibrated_p: Optional[float] = None


Decision = Union[ApprovedPosition, Rejection]


class ApprovalEngine:
    def __init__(self, calibrator: ConfidenceCalibrator,
                 validation: Optional[ValidationReport],
                 min_prob: float = 0.55,
                 max_collection_age: timedelta = timedelta(hours=12),
                 min_p_lower: Optional[float] = None,
                 require_binding: bool = True,
                 strategy_version: Optional[str] = None):
        if not 0.0 <= min_prob <= 1.0:
            raise ValueError("min_prob은 0~1 범위여야 합니다.")
        if min_p_lower is not None and not 0.0 <= min_p_lower <= 1.0:
            raise ValueError("min_p_lower는 None 또는 0~1 범위여야 합니다.")
        self.calibrator, self.validation = calibrator, validation
        self.min_prob, self.max_age = min_prob, max_collection_age
        self.min_p_lower = min_p_lower
        self.require_binding = require_binding
        self.strategy_version = strategy_version

    def evaluate(self, rec, *, signal_bar, meta, trust, now,
                 binding: Optional[ValidationBinding] = None) -> Decision:
        reasons: List[str] = []
        sym = getattr(rec, "symbol", getattr(meta, "symbol", "?"))

        # 1) 실행 가능성
        if not (getattr(rec, "direction", None) == "LONG" and getattr(rec, "action", None) == "BUY"):
            reasons.append("NOT_ACTIONABLE")

        # 2) 확정 봉
        sb = pd.Timestamp(signal_bar)
        if sb > meta.last_bar_ts:
            reasons.append("BAR_UNCONFIRMED: 신호 봉이 확정 봉보다 최신")
        elif sb < meta.last_bar_ts:
            reasons.append("STALE_SIGNAL_BAR: 신호 봉이 최신 확정 봉이 아님")

        # 3) 데이터 신뢰
        if trust is None or not trust.passed:
            reasons.append("DATA_UNTRUSTED")

        # 4) OOS 검증
        if self.validation is None:
            reasons.append("VALIDATION_MISSING")
        elif not self.validation.passed:
            reasons.append("VALIDATION_FAILED: " + "; ".join(self.validation.reasons))

        # 4b) 검증-보정기-전략 바인딩. 마이그레이션 단계에서는 선택적으로 강제한다.
        binding_status = "BINDING_MISSING"
        if binding is not None:
            binding_status = "BINDING_CONSISTENT"
            if self.validation is None or binding.validation_id != self.validation.validation_id:
                reasons.append("VALIDATION_MISMATCH: validation_id 불일치")
            current_fp = getattr(self.calibrator, "state_fingerprint", None)
            report_fp = (getattr(self.validation, "deployed_fingerprint", "") or
                         getattr(self.validation, "calibrator_state_hash", "")) if self.validation is not None else ""
            if not current_fp or current_fp != report_fp or binding.calibrator_hash != current_fp:
                reasons.append("REVALIDATION_REQUIRED: 배포 보정기가 검증 이후 재학습되었거나 상태 지문 불일치")
            if self.validation is not None:
                if binding.data_fingerprint != self.validation.data_fingerprint:
                    reasons.append("VALIDATION_MISMATCH: data_fingerprint 불일치")
                if binding.strategy_version != self.validation.strategy_version:
                    reasons.append("VALIDATION_MISMATCH: 검증 리포트의 strategy_version과 불일치")
            if self.strategy_version is not None and binding.strategy_version != self.strategy_version:
                reasons.append("VALIDATION_MISMATCH: 현재 strategy_version 불일치")
            if self.validation is not None and binding.train_window != self.validation.train_window:
                reasons.append("VALIDATION_MISMATCH: train_window 불일치")
            if not reasons:
                binding_status = "VERIFIED_MATCH"
        elif self.require_binding:
            reasons.append("VALIDATION_BINDING_MISSING")

        # 5) 보정 상태 / 6) 점 추정치와 하한은 독립 평가
        cs = self.calibrator.calibrate(float(getattr(rec, "signal_strength", 0.0)) / 100.0)
        if cs.status is not CalStatus.CALIBRATED:
            reasons.append(f"CALIBRATION_UNVERIFIED: {cs.reason}")
        else:
            if cs.p is None:
                reasons.append("CALIBRATION_INVALID: p 없음")
            elif cs.p < self.min_prob:
                reasons.append(f"LOW_CONFIDENCE: p={cs.p:.3f} < {self.min_prob}")
            if self.min_p_lower is not None:
                if cs.p_lower is None:
                    reasons.append("LOW_CONFIDENCE_LOWER_BOUND: p_lower 없음")
                elif cs.p_lower < self.min_p_lower:
                    reasons.append("LOW_CONFIDENCE_LOWER_BOUND: "
                                   f"p_lower={cs.p_lower:.3f} < {self.min_p_lower}")

        # 7) 수집 시각: NaT/naive/future timestamp는 fail-closed
        try:
            now_ts, collected = pd.Timestamp(now), pd.Timestamp(meta.collected_at)
            if (pd.isna(now_ts) or pd.isna(collected) or
                    now_ts.tzinfo is None or collected.tzinfo is None):
                reasons.append("INVALID_COLLECTION_TIME: NaT 또는 naive timestamp")
            else:
                age = now_ts.tz_convert("UTC") - collected.tz_convert("UTC")
                if age < pd.Timedelta(0):
                    reasons.append("INVALID_COLLECTION_TIME: collected_at이 미래")
                elif age > pd.Timedelta(self.max_age):
                    reasons.append("STALE_COLLECTION")
        except (TypeError, ValueError, OverflowError):
            reasons.append("INVALID_COLLECTION_TIME: timestamp 파싱 실패")

        if reasons:
            return Rejection(sym, tuple(reasons), cs.p)
        return ApprovedPosition(
            recommendation=rec, calibrated_p=cs.p, p_lower=cs.p_lower,
            support_range=(cs.bin_lo, cs.bin_hi), validation_id=self.validation.validation_id,
            data_reliability=trust.reliability, signal_bar=sb, collected_at=meta.collected_at,
            binding_status=binding_status,
            _token=_GATE_TOKEN)
