"""
diagnose_observations.py — 감시 프로그램이 실제로 받은 관측치를 파동 모델에 흘려 상태를 진단한다.

사용:
    python diagnose_observations.py observations.csv [--symbol 005930] [--window 20] [--timeframe intraday]
        [--legacy-col legacy_signal] [--log shadow_log.jsonl]

CSV 열(대소문자 무시): timestamp(필수), price 또는 close(필수), volume, symbol, source, legacy_signal
종료 코드: 0 = 입력 정상 + 분석 성공, 2 = 대기/입력 의심/오류/오래됨 (사유를 출력)

이 도구는 읽기 전용이다. 감시 프로그램, 수집기, 기존 매매 판단을 수정하지 않는다.
"""
import argparse
import sys
from collections import Counter

import pandas as pd

from wave_shadow_monitor import ShadowMonitor, ShadowState


def load(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    if "price" not in df.columns and "close" in df.columns:
        df["price"] = df["close"]
    missing = [c for c in ("timestamp", "price") if c not in df.columns]
    if missing:
        raise SystemExit(f"필수 열 누락: {missing} (있는 열: {list(df.columns)})")
    return df


def longest_run(values) -> int:
    best = cur = 1 if len(values) else 0
    for a, b in zip(values, values[1:]):
        cur = cur + 1 if a == b else 1
        best = max(best, cur)
    return best


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("csv"); ap.add_argument("--symbol"); ap.add_argument("--window", type=int, default=20)
    ap.add_argument("--timeframe", default="intraday"); ap.add_argument("--legacy-col", default="legacy_signal")
    ap.add_argument("--log"); ap.add_argument("--max-age", type=float, default=300.0)
    a = ap.parse_args(argv)
    df = load(a.csv)
    if "symbol" in df.columns:
        syms = [a.symbol] if a.symbol else sorted(df["symbol"].astype(str).unique())
    else:
        syms = [a.symbol or "SYMBOL"]
    rc = 0
    for sym in syms:
        d = df[df["symbol"].astype(str) == sym] if "symbol" in df.columns else df
        mon = ShadowMonitor(window_size=a.window, timeframe_label=a.timeframe, log_path=a.log, max_age_seconds=a.max_age)
        for _, r in d.iterrows():
            mon.observe(sym, r["timestamp"], r["price"], r.get("volume", 0.0) if "volume" in d.columns else 0.0,
                        source=str(r["source"]) if "source" in d.columns else "krx",
                        legacy_signal=(r[a.legacy_col] if a.legacy_col in d.columns and pd.notna(r[a.legacy_col]) else None))
        st = mon.status(sym, now=pd.Timestamp(d["timestamp"].iloc[-1]).tz_localize("Asia/Seoul").tz_convert("UTC")
                        if pd.Timestamp(d["timestamp"].iloc[-1]).tzinfo is None else pd.Timestamp(d["timestamp"].iloc[-1]))
        prices = [float(x) for x in d["price"]]
        print(f"\n=== {sym} ===")
        print(f"입력 {len(d)}행 → 새 관측치 {st.accepted} / 같은 관측치 재입력 {st.duplicates} / 거부 {dict(st.rejected) or '없음'}")
        print(f"서로 다른 가격 {len(set(prices))}개 · 가격이 연속 동일한 최장 구간 {longest_run(prices)}행")
        if "source" in d.columns:
            print("소스:", dict(Counter(d['source'].astype(str))))
        ts = pd.to_datetime(d["timestamp"], errors="coerce").dropna().sort_values()
        if len(ts) > 1:
            gaps = ts.diff().dropna().dt.total_seconds()
            print(f"관측 간격(초) 중앙값 {gaps.median():.1f} · 최대 {gaps.max():.1f}")
        print(f"진행 {st.progress} · 상태 {st.state} · 도메인 {st.domain}")
        for r in st.reasons: print("  사유:", r)
        for w in st.warnings: print("  경고:", w)
        if st.last_error: print("  계산 예외:", st.last_error)
        if st.analysis:
            an = st.analysis
            print(f"  분석: {an['wave_state']} · k_f={an['k_f']:.3f} k_c={an['k_c']:.3f} rms={an['v_rms']:.4g} "
                  f"· 추천(shadow, 참고용): {st.recommendation['direction']}/{st.recommendation['action']} "
                  f"강도 {st.recommendation['signal_strength']}")
        elif st.state == ShadowState.WAITING_WARMUP.value and st.accepted >= a.window:
            print("  ⚠ 관측치가 창 크기에 도달했는데 대기 상태 — 비정상")
        if st.state != ShadowState.ANALYZING_OK.value:
            rc = 2
    return rc


if __name__ == "__main__":
    sys.exit(main())
