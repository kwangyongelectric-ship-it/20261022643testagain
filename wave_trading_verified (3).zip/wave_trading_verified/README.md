# wave_trading_verified — 재현 가능한 검증 프로젝트

이 폴더만으로(다른 경로·shim 없이) 테스트가 돌아가야 한다. 

    pip install -r requirements.txt     # numpy, pandas
    python run_tests.py                 # 파일별 별도 프로세스로 전체 실행

## 구성
| 파일 | 역할 |
|---|---|
| wave.py | 원본 캔버스: MarketData 계약, 파형 분석, 포지션 추천 |
| backtest.py | 백테스터 v3(인과 청산, 포지션 크기·수수료 반영) |
| contracts.py, wave_analysis.py | 평평한 레이아웃용 파사드(실제 패키지 분리 시 교체) |
| bar_finality.py | 봉 확정 판정, 수집 메타, TIMED_FIELDS 계약 |
| position_confidence.py | 보정기, 시간순 OOS 검증, 상태 지문 바인딩(지문은 현재 상태에서 매번 계산) |
| approval_engine.py | 승인 게이트 v4(보정/바인딩) |
| oos_validation_bound.py, approval_engine_bound.py | 게이트 OOS·안정성 리포트 + 바인딩 통합 엔진 |
| oos_validation_fixed.py | 이전 리비전(원자 저장·인접 셀 수정). test_oos_validation.py가 사용 |
| data_trust.py | DataTrustValidator(업로드본) |
| data_collector_ohlcv.py | pykrx/Naver 수집기. 확정 봉만 반환/저장(bar_finality 연결), KST tz-aware 시계, 증분 겹쳐 받기, Naver 폴백 구간 제한, 스레드별 오류 기록 |
| check_source_integrity.py | 인코딩 깨짐·주석에 삼켜진 코드 줄 정적 검사: `python check_source_integrity.py .` |

## 아직 검증되지 않은 것
실제 data_collection.py / pykrx / 증권사 API 연동(pykrx가 장중에 당일 임시 봉을 돌려준다는 가정은 스텁 기준), 실데이터 OOS 성능. 거래소 휴장일은 모델링하지 않음. 캐시 치유는 파일 수정 시각에 의존(파일 복사/체크아웃 시 무력화 가능).
테스트는 합성 데이터이며, OOS_PASS 케이스는 성과를 고정한 스텁 백테스터를 쓴다.

## 소스 손상 대응
- 한글이 깨져 보이면 VS Code 하단 인코딩 표시 → 'Reopen with Encoding' → UTF-8 로 열어 확인하고, 저장은 항상 UTF-8.
- 손상 의심 시 `python check_source_integrity.py .` 와 `python run_tests.py` 를 실행. test_collector_incremental 이 증분 수집 회귀를 잡는다.
