"""
data_trust.py — 수집 데이터 신뢰도 검증 및 보안 점검 모듈
=========================================================

위치 (파이프라인 내):
    DataCollector ──> [DataTrustValidator] ──> WaveAnalysisAlgorithm ──> PositionRecommender
                          │  신규/구 데이터 비교, 이상치 검증, 보안 점검
                          ▼
                    TrustReport (신뢰도 점수 0~100 + 경보 목록)

검증 항목:
  A. 신규/구 데이터 비교 (Overlap Check)
     1) 정합성: 겹치는 구간 종가 불일치 봉 수 / 최대 편차율
     2) 연속성: 신규 데이터가 구 데이터 직후부터 시작하는지 (갭/누락 검사)
     3) 무결성 지문: 구간 해시(SHA-256) 비교 — 데이터 위조/부호화 변경 감지

  B. 단일 데이터 품질 (Intrinsic Quality)
     4) 통계 이상치: 일별 수익률 |z|>4 (스파이크 주입/오류 데이터 감지)
     5) 정체 데이터: 가격 변동 0 연속 (거래정지/오류 응답 감지)
     6) 해상도: 봉 간격 이상 (주기 누락), 최소 봉 수

  C. 보안 점검 (Security Check)
     7) 심볼 파라미터 검증: 형식 고정(6자리 숫자 또는 티커), 명령어/SQL 주입 패턴 차단
     8) 값 범위 화이트리스트: 가격/거래량의 비정상 값(NaN/음수/무한대) 거부
        — NaN/Inf는 분석 모듈의 RMS 계산을 조용히 오염시키는 대표적 공격/오류 경로
     9) 시간 이상: 미래 타임스탬프, 역순/중복 타임스탬프 차단

신뢰도 점수 = 100에서 항목별 감점. 기준 미달 시 분석 모듈로 전달 거부(또는 경고와 함께 폴백).

의존성: numpy, pandas, hashlib (표준 라이브러리)
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

# 계약 import — 패키지 분리 시: from wave_analysis.contracts import MarketData
try:
    from wave_analysis.contracts import MarketData
except ImportError:
    from wave_analysis import MarketData  # type: ignore


# ----------------------------------------------------------------
# 검증 결과 리포트
# ----------------------------------------------------------------
@dataclass
class TrustReport:
    symbol: str
    reliability: float                  # 0~100 신뢰도 점수
    passed: bool                        # 기준 충족 여부
    overlap_bars: int                   # 신규∩구 겹침 봉 수
    mismatched_bars: int                # 겹침 구간 종가 불일치 봉 수
    max_deviation_pct: float            # 겹침 구간 최대 종가 편차율 (%)
    gap_detected: bool                  # 신규/구 사이 봉 누락 여부
    anomaly_count: int                  # 통계 이상치 봉 수
    stale_streak: int                   # 가격 무변동 연속 봉 수
    security_flags: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    fingerprint: str = ""              # 신규 데이터 SHA-256 지문 (감사 로그용)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class TrustValidationError(RuntimeError):
    """보안/무결성 하드 실패 — 데이터를 분석 모듈로 전달하면 안 되는 경우."""


# ----------------------------------------------------------------
# DataTrustValidator
# ----------------------------------------------------------------
class DataTrustValidator:
    """
    사용 위치:
        collector = DataCollector([...])
        validator = DataTrustValidator(reliability_threshold=80.0)

        raw = collector.collect("005930")
        report, ok = validator.validate(raw, previous=stored_raw)
        if ok: analyzer.analyze_one(raw)
        else:  폴백(재수집) 또는 알람
    """

    # ---- 조정 가능한 정책 ----
    SYMBOL_PATTERN = re.compile(r"^[0-9A-Z.\-]{1,12}$")   # 7) 심볼 화이트리스트
    INJECTION_PATTERN = re.compile(r"[;&|`$<>'\"\\\x00-\x1f]")  # 7) 주입 패턴

    def __init__(self,
                 reliability_threshold: float = 80.0,   # 이 점수 미만이면 passed=False
                 max_deviation_pct: float = 0.5,        # 1) 겹침 구간 허용 편차율
                 mismatch_allowance: float = 0.02,      # 1) 허용 불일치 봉 비율 (2%)
                 zscore_limit: float = 4.0,             # 4) 수익률 이상치 기준
                 stale_limit: int = 10,                  # 5) 무변동 허용 연속 봉
                 min_bars: int = 30):                   # 6) 최소 봉 수
        if not 0 < reliability_threshold <= 100:
            raise ValueError("reliability_threshold는 0~100이어야 합니다.")
        self.reliability_threshold = reliability_threshold
        self.max_deviation_pct = max_deviation_pct
        self.mismatch_allowance = mismatch_allowance
        self.zscore_limit = zscore_limit
        self.stale_limit = stale_limit
        self.min_bars = min_bars

    # ============================================================
    # C. 보안 점검 (하드 실패 → TrustValidationError)
    # ============================================================
    def _security_check(self, raw: MarketData) -> List[str]:
        flags: List[str] = []

        # 7) 심볼 파라미터 검증 (외부 입력이 API 쿼리에 직접 들어가는 경로 차단)
        s = raw.symbol
        if not s or not self.SYMBOL_PATTERN.match(s):
            raise TrustValidationError(f"심볼 형식 비허용: {s!r}")
        if self.INJECTION_PATTERN.search(s):
            raise TrustValidationError(f"심볼에 주입 패턴 감지: {s!r}")
        if raw.timeframe not in ("1d", "1h", "5m"):
            raise TrustValidationError(f"타임프레임 비허용: {raw.timeframe!r}")

        # 8) 값 범위 화이트리스트 — NaN/Inf/음수는 RMS·K_f 계산을 조용히 오염시킴
        close = raw.close
        if not np.all(np.isfinite(close)):
            raise TrustValidationError("close에 NaN/Inf 포함 — 분석 불가")
        if np.any(close <= 0):
            raise TrustValidationError("close에 0 이하 값 포함")
        if not np.all(np.isfinite(raw.volume)) or np.any(raw.volume < 0):
            flags.append("volume에 비정상 값(음수/NaN) — volume은 분석 미사용이믈다 경고만")
            raw.volume = np.nan_to_num(raw.volume, nan=0.0)

        # 9) 타임스탬프: 역순/중복/미래 시각 차단
        ts = pd.DatetimeIndex(raw.timestamps)
        if ts.has_duplicates:
            raise TrustValidationError("타임스탬프 중복")
        if not ts.is_monotonic_increasing:
            raise TrustValidationError("타임스탬프 역순")
        now = pd.Timestamp.now(tz=ts.tz) if ts.tz else pd.Timestamp.now()
        if len(ts) and ts[-1] > now + pd.Timedelta(minutes=5):
            raise TrustValidationError(f"미래 타임스탬프 감지: {ts[-1]}")

        # 6) 최소 봉 수
        if len(close) < self.min_bars:
            flags.append(f"봉 수 부족: {len(close)} < {self.min_bars}")

        return flags

    # ============================================================
    # A. 신규/구 데이터 비교 (Overlap Check)
    # ============================================================
    def _compare_with_previous(self, raw: MarketData,
                              prev: MarketData) -> Tuple[int, int, float, bool, List[str]]:
        """
        반환: (overlap, mismatched, max_dev_pct, gap, warnings)
        - prev는 저장소(파일/DB)에 보관해둔 직전 수집 결과.
        """
        warnings: List[str] = []
        if prev is None:
            warnings.append("이전 데이터 없음 — 정합성 비교 생략")
            return 0, 0, 0.0, False, warnings
        if prev.symbol != raw.symbol or prev.timeframe != raw.timeframe:
            raise TrustValidationError("이전 데이터의 종목/타임프레임 불일치 — 비교 대상 오류")

        new_ts = pd.DatetimeIndex(raw.timestamps)
        old_ts = pd.DatetimeIndex(prev.timestamps)
        new_df = pd.DataFrame({"close": raw.close}, index=new_ts)
        old_df = pd.DataFrame({"close": prev.close}, index=old_ts)
        joined = old_df.join(new_df, how="inner", lsuffix="_old", rsuffix="_new")

        overlap = len(joined)
        mismatched, max_dev = 0, 0.0
        if overlap > 0:
            dev_pct = ((joined["close_new"] - joined["close_old"]) / joined["close_old"]) * 100
            mismatched = int((dev_pct.abs() > self.max_deviation_pct).sum())
            max_dev = float(dev_pct.abs().max())
            if mismatched > self.mismatch_allowance * overlap:
                warnings.append(
                    f"겹침 {overlap}봉 중 {mismatched}봉 불일치 "
                    f"(최대 편차 {max_dev:.3f}%) — 수정주가/소스 혼용 의심")
            # 3) 무결성 지문: 동일 구간 해시가 다르면 편차가 작아도 값이 바뀐 것
            old_slice = joined["close_old"].round(4).to_csv().encode()
            new_slice = joined["close_new"].round(4).to_csv().encode()
            if (hashlib.sha256(old_slice).hexdigest()
                    != hashlib.sha256(new_slice).hexdigest()) and mismatched == 0:
                warnings.append("해시 불일치(미세 값 변경 감지) — 부호화/반올림 변경 가능")

        # 2) 연속성: 구 데이터 마지막 봉 직후에 신규 데이터가 이어지는가
        gap = False
        if len(new_ts) and len(old_ts):
            expected = old_ts[-1] + pd.tseries.frequencies.to_offset(
                {"1d": "D", "1h": "h", "5m": "5min"}[raw.timeframe])
            first_new = new_ts[new_ts > old_ts[-1]]
            if len(first_new) == 0:
                gap = True
                warnings.append("신규 데이터에 갱신분 없음 — 응답 캐시/지연 의심")
            elif first_new[0] > expected:
                gap = True
                warnings.append(f"봉 누락 감지: {old_ts[-1]} → {first_new[0]}")
        return overlap, mismatched, max_dev, gap, warnings

    # ============================================================
    # B. 단일 데이터 품질
    # ============================================================
    def _intrinsic_quality(self, raw: MarketData) -> Tuple[int, int, List[str]]:
        warnings: List[str] = []
        close = raw.close

        # 4) 통계 이상치 (악의적/오류 스파이크)
        rets = np.diff(close) / close[:-1]
        anomaly = 0
        if len(rets) >= 5:
            mu, sd = float(np.mean(rets)), float(np.std(rets))
            if sd > 0:
                z = np.abs((rets - mu) / sd)
                anomaly = int((z > self.zscore_limit).sum())
                if anomaly > 0:
                    warnings.append(f"수익률 이상치 {anomaly}봉 (|z|>{self.zscore_limit})")

        # 5) 정체 데이터 (거래정지/오류 응답)
        stale = 0
        if len(close) > 1:
            same = np.isclose(close[1:], close[:-1], rtol=0, atol=1e-9)
            run = mx = 0
            for x in same:
                run = run + 1 if x else 0
                mx = max(mx, run)
            stale = int(mx)
            if stale >= self.stale_limit:
                warnings.append(f"가격 무변동 {stale}봉 연속 — 거래정지/오류 응답 의심")

        return anomaly, stale, warnings

    # ============================================================
    # 공개 인터페이스
    # ============================================================
    def validate(self, raw: MarketData,
                 previous: Optional[MarketData] = None) -> Tuple[TrustReport, bool]:
        """검증 실행. (TrustReport, passed) 반환. 하드 실패는 TrustValidationError 예외."""
        # C) 보안 하드 게이트
        security_flags = self._security_check(raw)

        # A) 신규/구 비교
        overlap, mismatched, max_dev, gap, cmp_warn = self._compare_with_previous(raw, previous)

        # B) 내재 품질
        anomaly, stale, qual_warn = self._intrinsic_quality(raw)

        warnings = cmp_warn + qual_warn

        # ---- 신뢰도 점수 산출: 100점에서 감점 ----
        score = 100.0
        if overlap > 0:
            ratio = mismatched / overlap
            score -= min(40.0, ratio * 200)            # 불일치 최대 -40
            score -= min(10.0, max_dev)                # 편차 크기 -0.1%p당 1점
        if gap:
            score -= 15.0                              # 누락/무갱신 -15
        score -= min(20.0, anomaly * 5.0)              # 이상치 봉당 -5 (최대 -20)
        if stale >= self.stale_limit:
            score -= 10.0                              # 정체 -10
        score -= min(10.0, len(security_flags) * 5.0)  # 보안 경고당 -5
        score = max(0.0, min(100.0, score))

        fingerprint = hashlib.sha256(
            f"{raw.symbol}|{raw.timeframe}|".encode()
            + np.asarray(raw.close, dtype=float).tobytes()).hexdigest()

        report = TrustReport(
            symbol=raw.symbol, reliability=round(score, 1),
            passed=score >= self.reliability_threshold,
            overlap_bars=overlap, mismatched_bars=mismatched,
            max_deviation_pct=round(max_dev, 4), gap_detected=gap,
            anomaly_count=anomaly, stale_streak=stale,
            security_flags=security_flags, warnings=warnings,
            fingerprint=fingerprint)

        if not report.passed:
            report.warnings.append(
                f"신뢰도 {score:.1f} < 기준 {self.reliability_threshold} — "
                "재수집/폴백 소스 전환 권장")
        return report, report.passed

    def fingerprint(self, raw: MarketData) -> str:
        """저장용 무결성 지문 — 수집 시 저장해 두고 다음 검증의 감사 로그로 사용."""
        return hashlib.sha256(
            f"{raw.symbol}|{raw.timeframe}|".encode()
            + np.asarray(raw.close, dtype=float).tobytes()).hexdigest()


# ----------------------------------------------------------------
# 저장소 인터페이스 예시 (구 데이터 보관 — 파일 기반 최소 구현)
# ----------------------------------------------------------------
class PreviousDataStore:
    """직전 수집 결과를 메모리/파일에 보관해 다음 검증의 비교 기준으로 쓴다."""
    def __init__(self, path: Optional[str] = None):
        self.path = path
        self._cache: Dict[str, MarketData] = {}

    def get(self, symbol: str) -> Optional[MarketData]:
        if symbol in self._cache:
            return self._cache[symbol]
        if self.path:
            import os
            fp = os.path.join(self.path, f"{symbol}.parquet")
            if os.path.exists(fp):
                df = pd.read_parquet(fp)
                return MarketData(symbol, "1d", pd.DatetimeIndex(df.index),
                                  df["close"].to_numpy(), df["volume"].to_numpy())
        return None

    def put(self, raw: MarketData):
        self._cache[raw.symbol] = raw
        if self.path:
            import os
            os.makedirs(self.path, exist_ok=True)
            df = pd.DataFrame({"close": raw.close, "volume": raw.volume}, index=raw.timestamps)
            df.to_parquet(os.path.join(self.path, f"{raw.symbol}.parquet"))


# ----------------------------------------------------------------
# 데모
# ----------------------------------------------------------------
if __name__ == "__main__":
    logging = None
    validator = DataTrustValidator(reliability_threshold=80.0)
    store = PreviousDataStore()

    rng = np.random.default_rng(7)
    n = 100
    prices = 70000 * np.exp(np.cumsum(rng.normal(0.0005, 0.012, n)))
    ts = pd.date_range(end=pd.Timestamp.now().normalize(), periods=n, freq="D")

    # 1차 수집 → 검증 통과 → 저장
    raw1 = MarketData("005930", "1d", ts, prices, rng.integers(1e5, 5e5, n).astype(float))
    rep1, ok1 = validator.validate(raw1, previous=store.get("005930"))
    print(f"[1차 수집] 신뢰도 {rep1.reliability} / 통과 {ok1} / 경보 {rep1.warnings}")
    store.put(raw1)

    # 2차 수집 시뮬레이션: 마지막 봉 갱신 + 3개 겹침 봉의 종가 임의 변경(오염 주입)
    prices2 = prices.copy()
    prices2[-5:-2] *= 1.003                       # 겹침 구간 0.3% 조작 → 불일치 감지
    prices2 = np.append(prices2, prices2[-1] * 1.004)   # 신규 봉 1개 추가
    ts2 = pd.date_range(end=pd.Timestamp.now().normalize() + pd.Timedelta(days=1),
                        periods=n + 1, freq="D")
    raw2 = MarketData("005930", "1d", ts2, prices2, rng.integers(1e5, 5e5, n + 1).astype(float))

    rep2, ok2 = validator.validate(raw2, previous=store.get("005930"))
    print(f"[2차 수집] 신뢰도 {rep2.reliability} / 통과 {ok2}")
    print(f"  겹침 {rep2.overlap_bars}봉 중 불일치 {rep2.mismatched_bars}봉 "
          f"(최대 편차 {rep2.max_deviation_pct:.3f}%) / 갭 {rep2.gap_detected}")
    for w in rep2.warnings:
        print(f"  경보: {w}")

    # 보안 하드 실패 예시: 주입 패턴 심볼 / NaN 주입
    for bad_symbol in ["005930; rm -rf", "005930'--"]:
        try:
            validator.validate(MarketData(bad_symbol, "1d", ts, prices, np.ones(n)))
        except TrustValidationError as e:
            print(f"[보안 차단] {e}")
    bad = prices.copy(); bad[3] = np.nan
    try:
        validator.validate(MarketData("005930", "1d", ts, bad, np.ones(n)))
    except TrustValidationError as e:
        print(f"[보안 차단] {e}")