# 실제 장중 감시 프로그램 검증 체크리스트 (shadow 모드)

**현재 상태: 실제 감시 프로그램·대시보드·KRX 시세 경로는 한 번도 검증되지 않았다.**
이 저장소의 테스트는 합성 데이터 위의 일봉 파이프라인이고, 아래 도구는 '실환경에서 무엇을 확인할지'를 코드로 만든 것이다.
도구가 통과해도 그것은 입력과 분석 상태를 구분해서 보여 준다는 뜻이지, 새 모델의 매매 신호가 옳다는 뜻이 아니다.

## ★ 먼저 알아야 할 도메인 불일치
모델(`WaveAnalysisAlgorithm`)은 **확정 일봉 20개**를 입력으로 가정하고 검증되었다(`bar_finality`도 일봉만 지원).
장중 감시에서 "관측치 n/20"이 스냅샷(분·틱 단위)을 20개 모은 것이라면 **검증된 사용 방식이 아니다.** 어댑터는
`timeframe_label != "1d"`일 때 모든 상태에 `UNVALIDATED_INTRADAY` 경고를 붙인다. 장중 입력을 쓰려면 별도의 장중 검증이 필요하다.

## 1. 기존 감시 프로그램 유지
- 수집·감시 코드를 수정하지 않는다. 어댑터는 읽기 전용이며 `observe()`는 예외를 던지지 않는다.
- 연결(기존 루프에 몇 줄만 추가, 실패해도 기존 동작에 영향 없음):

      from wave_shadow_monitor import ShadowMonitor
      shadow = ShadowMonitor(window_size=20, timeframe_label="intraday", log_path="shadow_log.jsonl")
      ...                                   # 기존 루프: 시세 수신 → 기존 모델 신호 산출
      st = shadow.observe(symbol, ts, price, volume, source="krx", legacy_signal=legacy_signal)   # 관찰만
      decision = shadow.final_decision(legacy_signal)       # 항상 legacy_signal 그대로(덮어쓰기 없음)
      panel_text = f"{st.progress} {st.state} {st.reasons} {st.warnings}"                        # 패널 표시용

## 2. 입력 확인 (실제 KRX 시세가 들어오는가, 모의/반복인가)
감시 프로그램이 받은 관측치를 CSV로 내보낸다(열: timestamp, price, volume, source, legacy_signal, symbol).

      python diagnose_observations.py observations.csv --symbol 005930 --log shadow_log.jsonl

출력으로 확인: 새 관측치 vs **같은 관측치 재입력** 수, 서로 다른 가격 수, 가격이 연속 동일한 최장 구간, 소스(모의 여부), 관측 간격.

## 3. 분석 상태 구분
| 상태 | 의미 |
|---|---|
| `WAITING_WARMUP` n/20 | 정상 대기. 단 `REPEATED_OBSERVATIONS` 경고가 있으면 같은 값이 반복 입력되어 n이 늘지 않는 정체 |
| `INPUT_SUSPECT` | 모의 소스, 얼어붙은 피드(가격·거래량 동일), 평평한 피드 → 분석 차단 |
| `ANALYZING_OK` | 입력 정상 + 분석 성공(파동 상태, k_f, k_c, 추천 포함) |
| `STALE_INPUT` | 마지막 관측이 오래됨 |
| `MODEL_ERROR` | 분석 중 예외(예외 유형·메시지 기록). 관측치가 20개인데 분석이 없으면 이 상태여야 한다 |
`20/20`인데 `WAITING_WARMUP`이면 비정상으로 진단 도구가 별도 표시한다.

## 4. 모델 결합 검증
- `shadow_log.jsonl`: 기존 신호와 파동 신호를 나란히 기록(`agree`, `disagreement_reason`, `wave_reason`, `overridden=false`).
- 해석 불가 신호는 `agree=null`, 분석 불가 상태는 기록하지 않는다(불일치로 오염시키지 않음).
- **검증 전에는 기존 매매 판단을 덮어쓰지 않는다.** 일치율·불일치 사유는 관찰용이며, 새 모델 채택 기준(임계값)은 아직 정의되지 않았다 — 사용자 결정 사항.

## 5. 실행 환경에서 확인할 것 (여기서 검증하지 못함)
1. 실제 대시보드 구동, 실제 KRX 시세 수신, 데이터 갱신 주기
2. 위 진단 도구의 출력(실제 로그 기준)
3. 분석 결과가 갱신마다 달라지는지, 예외가 없는지
4. 기존 감시 프로그램의 동작이 어댑터 추가 전후로 같은지

## 필요한 자료 (제공해 주시면 실제 연결을 검토할 수 있음)
- 감시 프로그램의 수집 루프와 패널 표시 코드(관측치 1/20을 만드는 부분), 기존 신호를 만드는 부분
- 실제 관측 로그(위 CSV 형식) 일부, 발생한 예외/스택 트레이스가 있으면 함께
