"""소스 무결성 회귀: 프로젝트의 모든 .py가 깨끗해야 하고, 검사기가 실제 손상 패턴을 잡아야 한다."""
import os
import check_source_integrity as ci

HERE = os.path.dirname(os.path.abspath(__file__))

def test_project_sources_are_clean():
    bad = [i for f in sorted(os.listdir(HERE)) if f.endswith(".py") for i in ci.scan_file(os.path.join(HERE, f))]
    assert not bad, bad[:3]

def test_detects_comment_swallowing_code():
    # 손상 샘플은 런타임에 조립한다(리터럴로 두면 이 파일 자체가 검사에 걸린다)
    comment = "                # " + "증분 구간은 최소 행 수를 재산출"
    code = "start_d = datetime.strptime(start_date, '%Y%m%d').date()"
    assert ci.scan_text(comment + " " * 16 + code), "주석에 합쳐진 코드 줄을 잡아야 한다"
    assert not ci.scan_text(comment + "\n" + " " * 16 + code)

def test_detects_mojibake():
    hanja = "".join(chr(c) for c in (0x7e15, 0x63f4, 0x63f6))              # 모지바케에 흔한 한자
    assert ci.scan_text("# " + "한글" + hanja)                              # 한자 혼입
    assert ci.scan_text("x = 1  # " + chr(0xfffd) * 2)                     # 치환 문자
    assert not ci.scan_text("# 정상적인 한글 주석: 확정 봉만 사용")

def test_detects_non_utf8_file(tmp=None):
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "bad.py"); open(p, "wb").write("# 한글\nx = 1\n".encode("cp949"))
        assert any("UTF-8" in m for _, _, m in ci.scan_file(p))
