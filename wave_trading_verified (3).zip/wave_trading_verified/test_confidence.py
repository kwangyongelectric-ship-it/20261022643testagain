"""
test_confidence.py — 회귀 테스트 (pytest 또는 python test_confidence.py)

실행 전제: 프로젝트의 contracts(MarketData), backtest(WaveBacktester), wave_analysis,
          data_trust(DataTrustValidator)가 import 가능해야 한다.
통합 테스트(test_extracted_trades_are_causal 등)는 그 모듈이 없으면 건너뛴다.
※ 합성 데이터 결과는 로직 검증용이며 실제 종목 성능을 의미하지 않는다.
"""
from __future__ import annotations

import dataclasses
from datetime import timedelta

import numpy as np
import pandas as pd

from approval_engine import ApprovalEngine, ApprovedPosition, Rejection
from bar_finality import (CollectionMeta, ConfirmedDataCollector, UnconfirmedDataError,
                          confirmed_mask, finalize_market_data)
from position_confidence import (CalStatus, ConfidenceCalibrator, TradeRecord,
                                 validate_chronological, extract_trades)

T0 = pd.Timestamp("2024-01-02")


# ---------------- 합성 거래 ----------------
def make_trades(n, true_p, seed=0, lo=0.5, hi=0.95, symbol="S"):
    rng = np.random.default_rng(seed)
    out = []
    for i in range(n):
        s = rng.uniform(lo, hi)
        d = T0 + pd.Timedelta(days=int(i * 0.5 + rng.integers(0, 2)))
        lab = d + pd.Timedelta(days=int(rng.integers(1, 15)))
        out.append(TradeRecord(symbol, d, lab, s, int(rng.random() < true_p(s))))
    return out


MISCAL = lambda s: s - 0.13           # 원시 점수가 과신(overconfident)인 세계
NOSIGNAL = lambda s: 0.5              # 점수가 결과와 무관한 세계


# ---------------- 가짜 MarketData / 소스 ----------------
class MD:                              # 계약과 동일한 5개 필드의 최소 구현
    def __init__(self, symbol, timeframe, timestamps, close, volume):
        self.symbol, self.timeframe = symbol, timeframe
        self.timestamps, self.close, self.volume = pd.DatetimeIndex(timestamps), np.asarray(close, float), np.asarray(volume, float)


def md_until(last_day, n=40, symbol="005930"):
    ts = pd.bdate_range(end=pd.Timestamp(last_day), periods=n)
    return MD(symbol, "1d", ts, 100 + np.arange(n), np.ones(n))


# =============== 봉 확정 ===============
def test_today_bar_unconfirmed_before_cutoff_and_confirmed_after():
    md = md_until("2026-10-08")                                           # 목요일 봉 포함
    m1, meta1 = finalize_market_data(md, pd.Timestamp("2026-10-08 11:00", tz="Asia/Seoul"), "x")
    assert meta1.n_dropped_unconfirmed == 1 and meta1.last_bar_ts == pd.Timestamp("2026-10-07")
    m2, meta2 = finalize_market_data(md, pd.Timestamp("2026-10-08 15:45", tz="Asia/Seoul"), "x")
    assert meta2.n_dropped_unconfirmed == 1                               # 15:30+30분=16:00 이전 → 아직 미확정
    m3, meta3 = finalize_market_data(md, pd.Timestamp("2026-10-08 16:00", tz="Asia/Seoul"), "x")
    assert meta3.n_dropped_unconfirmed == 0 and meta3.last_bar_ts == pd.Timestamp("2026-10-08")


def test_future_bar_and_weekend_and_utc_clock():
    md = md_until("2026-10-12")                                           # 월요일(미래) 봉 포함
    _, meta = finalize_market_data(md, pd.Timestamp("2026-10-10 12:00", tz="Asia/Seoul"), "x")   # 토요일
    assert meta.last_bar_ts == pd.Timestamp("2026-10-09") and meta.n_dropped_unconfirmed == 1
    # UTC로 들어온 시각도 KST로 변환해 판정: 06:30 UTC = 15:30 KST (아직 미확정)
    mk = confirmed_mask(md_until("2026-10-08").timestamps, pd.Timestamp("2026-10-08 06:30", tz="UTC"))
    assert not mk[-1]


def test_no_confirmed_bar_raises_and_intraday_rejected():
    md = MD("X", "1d", [pd.Timestamp("2026-10-08")], [1.0], [1.0])
    try:
        finalize_market_data(md, pd.Timestamp("2026-10-08 10:00", tz="Asia/Seoul"), "x"); assert False
    except UnconfirmedDataError:
        pass
    try:
        finalize_market_data(MD("X", "5m", [T0], [1.0], [1.0]), T0, "x"); assert False
    except NotImplementedError:
        pass


def test_collector_records_source_and_checks_min_bars_after_dropping():
    class Src:
        def __init__(s, name, md): s.name, s._md = name, md
        def fetch(s, sym, lb, end): return s._md
    class Col:
        min_bars = 30
        sources = [Src("short", md_until("2026-10-08", n=29)), Src("full", md_until("2026-10-08", n=31))]
    clock = lambda: pd.Timestamp("2026-10-08 11:00", tz="Asia/Seoul")
    md, meta = ConfirmedDataCollector(Col, clock=clock).collect("005930")
    # 'full'은 31봉이지만 오늘(미확정) 1봉을 빼면 30봉 → 통과, 'short'는 28봉 → 폴백
    assert meta.source == "full" and len(md.close) == 30 and meta.n_dropped_unconfirmed == 1
    assert meta.collected_at.tzinfo is not None


# =============== 보정기 ===============
def test_min_sample_merge_and_unverified():
    # 구간별 표본이 적으면 병합되고, 전체가 부족하면 UNVERIFIED
    tr = make_trades(120, MISCAL, seed=1)
    cal = ConfidenceCalibrator(n_bins=10, min_bin_samples=30, min_total=100).fit(tr, as_of=pd.Timestamp("2030-01-01"))
    assert cal.fitted and all(g["n"] >= 30 for g in cal._groups)
    small = ConfidenceCalibrator(min_total=100).fit(tr[:50], as_of=pd.Timestamp("2030-01-01"))
    assert small.calibrate(0.8).status is CalStatus.UNVERIFIED and "INSUFFICIENT_TOTAL" in small.calibrate(0.8).reason


def test_out_of_support_is_unverified():
    tr = make_trades(300, MISCAL, seed=2, lo=0.5, hi=0.8)
    cal = ConfidenceCalibrator().fit(tr, pd.Timestamp("2030-01-01"))
    assert cal.calibrate(0.95).status is CalStatus.UNVERIFIED          # 학습 범위 밖은 외삽하지 않는다
    assert cal.calibrate(0.65).status is CalStatus.CALIBRATED


def test_label_maturity_excludes_open_trades():
    tr = make_trades(300, MISCAL, seed=3)
    as_of = tr[200].decision_time
    flipped = [dataclasses.replace(t, outcome=1 - t.outcome) if t.label_time > as_of else t for t in tr]
    a = ConfidenceCalibrator().fit(tr, as_of); b = ConfidenceCalibrator().fit(flipped, as_of)
    assert a._groups == b._groups and a.n_fit < len(tr)               # 미성숙 거래의 결과는 학습에 영향 없음


def test_future_folds_cannot_change_past_predictions():
    tr = make_trades(600, MISCAL, seed=4)
    base = validate_chronological(tr)
    cut = sorted(t.decision_time for t in tr)[int(len(tr) * 0.85)]
    mutated = [dataclasses.replace(t, outcome=1 - t.outcome, score=1 - t.score) if t.decision_time >= cut else t for t in tr]
    alt = validate_chronological(mutated)
    # 최종 fold 이전(= as_of < cut)의 예측은 완전히 동일해야 한다. (fold 경계는 거래 수 기준이라 같은 필터로 비교)
    k = lambda r: r.oos_frame[r.oos_frame["decision_time"] < cut].reset_index(drop=True)
    pd.testing.assert_frame_equal(k(base)[["decision_time", "p", "base"]], k(alt)[["decision_time", "p", "base"]])


def test_calibration_improves_and_passes_on_miscalibrated_world():
    r = validate_chronological(make_trades(2000, MISCAL, seed=5))
    assert r.ece_cal < r.ece_raw and r.brier_cal < r.brier_raw
    assert r.skill > 0 and r.passed, r.reasons


def test_validation_fails_when_score_has_no_signal():
    r = validate_chronological(make_trades(2000, NOSIGNAL, seed=6))
    assert not r.passed and any("NO_SKILL" in x or "ECE" in x for x in r.reasons), r


def test_validation_fails_when_too_few_trades():
    r = validate_chronological(make_trades(80, MISCAL, seed=7))
    assert not r.passed and any("INSUFFICIENT" in x for x in r.reasons)


# =============== 승인 게이트 ===============
@dataclasses.dataclass
class Rec:
    symbol: str = "005930"; direction: str = "LONG"; action: str = "BUY"; signal_strength: float = 78.0


@dataclasses.dataclass
class Trust:
    passed: bool = True; reliability: float = 95.0


def _engine(world=MISCAL, n=2000, hi=0.95, **kw):
    tr = make_trades(n, world, seed=11, hi=hi)
    cal = ConfidenceCalibrator().fit(tr, pd.Timestamp("2030-01-01"))
    kw.setdefault("require_binding", False)      # 바인딩 없는 호환 모드(바인딩 시나리오는 test_binding_integrity.py)
    return ApprovalEngine(cal, validate_chronological(tr), **kw)


def _ctx(now="2026-10-08 18:00"):
    now = pd.Timestamp(now, tz="Asia/Seoul")
    md, meta = finalize_market_data(md_until("2026-10-08"), now, "kis")
    return now, meta


def test_gate_cannot_be_bypassed():
    try:
        ApprovedPosition(Rec(), 0.9, 0.8, (0.7, 0.8), "v", 99.0, T0, T0); assert False
    except PermissionError:
        pass
    try:
        ApprovedPosition(Rec(), 0.9, 0.8, (0.7, 0.8), "v", 99.0, T0, T0, _token=object()); assert False
    except PermissionError:
        pass


def test_gate_approves_only_when_everything_holds():
    now, meta = _ctx()
    eng = _engine(min_prob=0.5)
    d = eng.evaluate(Rec(), signal_bar=meta.last_bar_ts, meta=meta, trust=Trust(), now=now)
    assert isinstance(d, ApprovedPosition) and d.calibrated_p >= 0.5
    # 각 조건을 하나씩 깨뜨리면 반드시 거절
    cases = {
        "BAR_UNCONFIRMED": dict(signal_bar=meta.last_bar_ts + pd.Timedelta(days=1)),
        "STALE_SIGNAL_BAR": dict(signal_bar=meta.last_bar_ts - pd.Timedelta(days=1)),
        "DATA_UNTRUSTED": dict(trust=Trust(passed=False)),
        "STALE_COLLECTION": dict(now=now + timedelta(days=2)),
    }
    for code, over in cases.items():
        args = dict(signal_bar=meta.last_bar_ts, meta=meta, trust=Trust(), now=now); args.update(over)
        r = eng.evaluate(Rec(), **args)
        assert isinstance(r, Rejection) and any(code in x for x in r.reasons), (code, r)
    assert isinstance(eng.evaluate(Rec(action="HOLD"), signal_bar=meta.last_bar_ts, meta=meta, trust=Trust(), now=now), Rejection)


def test_gate_blocks_everything_when_oos_fails_or_missing():
    now, meta = _ctx()
    args = dict(signal_bar=meta.last_bar_ts, meta=meta, trust=Trust(), now=now)
    r = _engine(NOSIGNAL).evaluate(Rec(), **args)
    assert isinstance(r, Rejection) and any("VALIDATION_FAILED" in x for x in r.reasons)
    eng = _engine(); eng.validation = None
    assert any("VALIDATION_MISSING" in x for x in eng.evaluate(Rec(), **args).reasons)


def test_gate_rejects_unverified_score_range():
    now, meta = _ctx()
    # 학습 점수가 0.8까지뿐이면 0.9 이상 구간은 데이터가 없다 → 외삽 금지
    r = _engine(min_prob=0.5, hi=0.8).evaluate(Rec(signal_strength=95.0), signal_bar=meta.last_bar_ts, meta=meta, trust=Trust(), now=now)
    assert isinstance(r, Rejection) and any("CALIBRATION_UNVERIFIED" in x for x in r.reasons)


# =============== 통합: 실제 백테스터 / DataTrustValidator ===============
def _demo(seed, n=260):
    from contracts import MarketData
    rng = np.random.default_rng(seed)
    c = 70000 * np.exp(np.cumsum(rng.normal(0.0003, 0.015, n)))
    return MarketData(f"T{seed}", "1d", pd.date_range("2025-01-01", periods=n, freq="D"), c, np.full(n, 1e5))


def test_extracted_trades_are_causal():
    """절단 시리즈에서 뽑은 거래 == 전체 시리즈 거래 중 label_time <= 절단 직전 결정 시각."""
    from backtest import WaveBacktester
    from wave_analysis import WaveAnalysisAlgorithm, PositionRecommender
    from contracts import MarketData
    mk = lambda: WaveBacktester(WaveAnalysisAlgorithm(20), PositionRecommender())
    checked = 0
    for seed in range(12):
        raw = _demo(seed)
        full = extract_trades(raw, mk().run(raw))
        for m in (120, 160, 200, 240):
            cut = MarketData(raw.symbol, raw.timeframe, raw.timestamps[:m], raw.close[:m], raw.volume[:m])
            part = extract_trades(cut, mk().run(cut))
            expect = [t for t in full if t.label_time <= raw.timestamps[m - 2]]
            assert part == expect, (seed, m)
            checked += len(part) > 0
        assert all(t.label_time >= t.decision_time for t in full)
    assert checked > 0


def test_trust_report_feeds_gate():
    from contracts import MarketData
    from data_trust import DataTrustValidator
    raw = _demo(1)
    rep, ok = DataTrustValidator().validate(raw, previous=None)
    assert ok and rep.reliability >= 80
    now = pd.Timestamp("2026-10-08 18:00", tz="Asia/Seoul")
    _, meta = finalize_market_data(raw, now, "x")
    d = _engine(min_prob=0.5).evaluate(Rec(), signal_bar=meta.last_bar_ts, meta=meta, trust=rep, now=now)
    assert isinstance(d, (ApprovedPosition, Rejection))


if __name__ == "__main__":
    import traceback
    fails = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn(); print("PASS", name)
            except ImportError as e:
                print("SKIP", name, "-", e)
            except Exception:
                fails += 1; print("FAIL", name); traceback.print_exc()
    raise SystemExit(1 if fails else 0)
