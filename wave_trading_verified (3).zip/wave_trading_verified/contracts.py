"""계약 파사드: 단일 파일(wave.py)에 있는 MarketData를 contracts 이름으로 노출한다."""
from wave import MarketData  # noqa: F401
