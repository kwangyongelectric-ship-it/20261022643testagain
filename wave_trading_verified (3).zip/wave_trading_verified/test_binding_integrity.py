"""test_binding_integrity.py — 검증-보정기 바인딩 회귀 테스트 (합성 데이터)
시나리오: 정상 승인 / 다른 데이터 학습 보정기 / 재학습 / 사후 변조 / 전략 버전 / 바인딩 누락"""
import copy, numpy as np, pandas as pd
from test_confidence import make_trades, MISCAL, Rec, Trust, md_until
from position_confidence import ConfidenceCalibrator, validate_chronological, build_validation_binding, calibrator_state_hash
from approval_engine import ApprovalEngine, ApprovedPosition, Rejection
from bar_finality import finalize_market_data

NOW = pd.Timestamp("2026-10-08 18:00", tz="Asia/Seoul")
_, META = finalize_market_data(md_until("2026-10-08"), NOW, "kis")
ARGS = dict(signal_bar=META.last_bar_ts, meta=META, trust=Trust(), now=NOW)
REC = Rec(signal_strength=62.0)

def _setup():
    A = make_trades(2000, MISCAL, seed=11)
    o = sorted(A, key=lambda t: (t.decision_time, t.symbol)); n = len(o)
    edges = np.linspace(max(1, int(n * 0.5)), n, 5).astype(int)
    asof = o[edges[3]].decision_time                       # 마지막 OOS fold 시작 = 배포 가능한 보정기 상태
    rep = validate_chronological(A, strategy_version="v1")
    cal = ConfidenceCalibrator().fit(A, asof)
    return A, asof, rep, cal, build_validation_binding(rep, cal, "v1", A)

def _eng(cal, rep, **kw):
    return ApprovalEngine(cal, rep, min_prob=0.45, require_binding=True, strategy_version="v1", **kw)

def _codes(d): return [r.split(":")[0] for r in d.reasons]

def test_verified_match_end_to_end():
    A, asof, rep, cal, b = _setup()
    d = _eng(cal, rep).evaluate(REC, binding=b, **ARGS)
    assert isinstance(d, ApprovedPosition) and d.binding_status == "VERIFIED_MATCH"

def test_calibrator_trained_on_other_data_is_rejected():
    A, asof, rep, cal, b = _setup()
    B = make_trades(2000, lambda s: 0.9, seed=99, hi=0.7)
    calB = ConfidenceCalibrator().fit(B, asof)
    d = _eng(calB, rep).evaluate(REC, binding=b, **ARGS)
    assert isinstance(d, Rejection) and "REVALIDATION_REQUIRED" in _codes(d)

def test_refit_on_newer_data_requires_revalidation():
    A, asof, rep, cal, b = _setup()
    full = ConfidenceCalibrator().fit(A, pd.Timestamp("2030-01-01"))
    d = _eng(full, rep).evaluate(REC, binding=b, **ARGS)
    assert isinstance(d, Rejection) and "REVALIDATION_REQUIRED" in _codes(d)

def test_post_fit_mutation_of_groups_is_detected():
    A, asof, rep, cal, b = _setup()
    m = copy.deepcopy(cal)
    for g in m._groups: g["p"], g["p_lower"] = 0.99, 0.95
    d = _eng(m, rep).evaluate(REC, binding=b, **ARGS)
    assert isinstance(d, Rejection) and "REVALIDATION_REQUIRED" in _codes(d), d

def test_post_fit_mutation_of_as_of_is_detected():
    A, asof, rep, cal, b = _setup()
    m = copy.deepcopy(cal); m.as_of = pd.Timestamp("2020-01-01")
    d = _eng(m, rep).evaluate(REC, binding=b, **ARGS)
    assert isinstance(d, Rejection) and "REVALIDATION_REQUIRED" in _codes(d), d

def test_strategy_version_mismatch_rejected():
    A, asof, rep, cal, b = _setup()
    d = ApprovalEngine(cal, rep, min_prob=0.45, require_binding=True, strategy_version="v2").evaluate(REC, binding=b, **ARGS)
    assert isinstance(d, Rejection) and "VALIDATION_MISMATCH" in _codes(d)

def test_missing_binding_fail_closed_and_compat_mode_labeled():
    A, asof, rep, cal, b = _setup()
    assert "VALIDATION_BINDING_MISSING" in _codes(_eng(cal, rep).evaluate(REC, **ARGS))
    d = ApprovalEngine(cal, rep, min_prob=0.45, require_binding=False).evaluate(REC, **ARGS)
    assert isinstance(d, ApprovedPosition) and d.binding_status == "BINDING_MISSING"

if __name__ == "__main__":
    import traceback; fails = 0
    for k, f in sorted(globals().items()):
        if k.startswith("test_") and callable(f):
            try: f(); print("PASS", k)
            except Exception: fails += 1; print("FAIL", k)
    raise SystemExit(1 if fails else 0)
