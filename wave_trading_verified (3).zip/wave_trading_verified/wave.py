"""
파형 분석 핵심 패키지 — 데이터 수집 계층 완전 분리형
=====================================================

패키지 레이아웃 (물리적으로 파일 분할 시):
wave_analysis/
├── contracts.py            # MarketData / AnalysisVector / PositionRecommendation
├── wave_analysis.py        # WaveAnalysisAlgorithm (상태 판단까지만)
├── position_recommender.py # PositionRecommender (정책 엔진: Wave State + Kf + Kc + V_rms + AC + DC → 정책 → 리스크 게이트)
├── multi_symbol_analyzer.py# MultiSymbolAnalyzer (MarketData 목록 → AnalysisVector/PositionRecommendation 목록)
└── backtest.py             # WaveBacktester (MarketData 기반 Walk-Forward)

설계 원칙:
- 이 패키지는 MarketData를 입력받는 순간부터만 동작한다. (데이터 수집 계층은 패키지 밖)
- REST → WebSocket → 증권사 API 교체 시 이 패키지 코드는 한 줄도 수정 불필요.
- 책임 분리: WaveAnalysisAlgorithm = "시장이 어떤 상태인가?",
           PositionRecommender = "얼마를 어떤 방향으로 어떻게 가질 것인가?"

(본 캔버스는 단일 파일 구성이므로, 아래 SECTION 구분자가 파일 경계를 나타냅니다.
 실제 패키지 사용 시 각 섹션을 별도 파일로 저장하고 주석 처리된 import를 활성화하세요.)

실행: python wave_analysis_package.py
의존성: numpy, pandas
"""

from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Tuple, Optional
import numpy as np
import pandas as pd


# ================================================================
# SECTION: contracts.py
# ================================================================
# (실제 패키지에서는 아래 dataclass들을 contracts.py로 이동하고
#  다른 파일들에서 from .contracts import MarketData, ... 로 import)

@dataclass
class MarketData:
    """데이터 수집 계층이 건네주는 표준 계약. 수집 방식(REST/WebSocket/API)과 무관."""
    symbol: str
    timeframe: str
    timestamps: pd.DatetimeIndex
    close: np.ndarray
    volume: np.ndarray

    def __post_init__(self):
        self.close = np.asarray(self.close, dtype=float)
        self.volume = np.asarray(self.volume, dtype=float)
        if len(self.close) != len(self.volume):
            raise ValueError("close와 volume의 길이가 같아야 합니다.")
        if len(self.timestamps) != len(self.close):
            raise ValueError("timestamps와 close의 길이가 같아야 합니다.")
        if len(self.close) == 0:
            raise ValueError("시장 데이터가 비어 있습니다.")


@dataclass
class AnalysisVector:
    """분석 모듈의 출력 = 포지션 모듈의 입력."""
    symbol: str
    current_price: float
    dc_trend: float
    v_rms: float
    v_avg: float
    k_f: float
    k_c: float
    ac_signal: float
    wave_state: str

    def to_dict(self): return asdict(self)


@dataclass
class PositionRecommendation:
    """주문 시스템에 바로 넘길 수 있는 포지션 설계 결과 (최종 출력 계약)."""
    symbol: str
    timeframe: str
    direction: str          # LONG / SHORT / FLAT
    action: str             # BUY / SELL / TAKE_PROFIT / READY / HOLD
    entry_condition: str   # ①~② 진입 조건 (조건부 주문용)
    entry_price: float      # ③ 진입가격
    target_price: float     # ④ 목표가격
    stop_loss: float        # ⑤ 손절가격
    position_size: float    # ⑥ 포지션 비중 (0~1)
    risk: float
    reward: float
    risk_reward: float     # ⑦ 리스크/보상비
    signal_strength: int   # ⑧ 신호 강도 (0~100)
    current_price: float
    reason: str            # ⑨ 추천 근거
    indicators: Dict[str, Any]

    def to_dict(self): return asdict(self)


# ================================================================
# SECTION: wave_analysis.py
# ================================================================
# from .contracts import MarketData, AnalysisVector

class WaveAnalysisAlgorithm:
    """'현재 시장이 어떤 상태인가?' 까지만 판단한다. 주문 파라미터는 생성하지 않는다."""
    STATES = ("STRONG_TREND", "OVERBOUGHT_SPIKE", "SQUEEZE", "NEUTRAL")

    def __init__(self, window_size=20, overbought_crest=2.0,
                 overbought_ac_multiple=1.5, strong_trend_form_factor=1.18,
                 squeeze_ratio=0.008):
        self.window_size = window_size
        self.overbought_crest = overbought_crest
        self.overbought_ac_multiple = overbought_ac_multiple
        self.strong_trend_form_factor = strong_trend_form_factor
        self.squeeze_ratio = squeeze_ratio

    @staticmethod
    def _metrics(p: np.ndarray) -> Tuple[float, float, float, float, float, float]:
        """(dc, ac_signal, rms, avg, kf, kc) — 한 창의 파형 지표 산출."""
        dc = float(np.mean(p))
        ac = p - dc
        rms = float(np.sqrt(np.mean(ac ** 2)))
        avg = float(np.mean(np.abs(ac)))   # 전기공학 V_avg = 절대값 평균
        kf = rms / avg if avg > 0 else 1.0
        kc = float(np.max(np.abs(ac))) / rms if rms > 0 else 1.0
        return dc, float(ac[-1]), rms, avg, kf, kc

    def _classify(self, kf, kc, rms, dc, ac_signal) -> str:
        if kc >= self.overbought_crest and ac_signal > self.overbought_ac_multiple * rms:
            return "OVERBOUGHT_SPIKE"
        if kf <= self.strong_trend_form_factor and ac_signal > 0:
            return "STRONG_TREND"
        if rms < dc * self.squeeze_ratio:
            return "SQUEEZE"
        return "NEUTRAL"

    def process(self, raw: MarketData) -> AnalysisVector:
        if len(raw.close) < self.window_size:
            raise ValueError(f"데이터 길이가 분석 창 크기({self.window_size})보다 작습니다.")
        p = raw.close[-self.window_size:]
        dc, ac_sig, rms, avg, kf, kc = self._metrics(p)
        return AnalysisVector(raw.symbol, float(p[-1]), dc, rms, avg, kf, kc, ac_sig,
                              self._classify(kf, kc, rms, dc, ac_sig))

    def rolling_analyses(self, raw: MarketData) -> List[AnalysisVector]:
        """백테스트용: 각 시점마다 직전 window_size 봉으로 AnalysisVector를 롤링 생성."""
        n = len(raw.close)
        out = []
        for i in range(self.window_size, n):
            p = raw.close[i - self.window_size:i]
            dc, ac_sig, rms, avg, kf, kc = self._metrics(p)
            out.append(AnalysisVector(raw.symbol, float(p[-1]), dc, rms, avg, kf, kc,
                                      ac_sig, self._classify(kf, kc, rms, dc, ac_sig)))
        return out


# ================================================================
# SECTION: position_recommender.py
# ================================================================
# from .contracts import AnalysisVector, PositionRecommendation

class PositionRecommender:
    """
    독립 정책 엔진. 분석 모듈과 데이터 수집 모듈 어디에도 의존하지 않는다.
    입력: AnalysisVector (Wave State + Kf + Kc + V_rms + AC Signal + DC Trend)
    내부 흐름:
        6개 지표 → Position Policy (방향/Entry/Target/Stop/Size 설계)
                 → Risk Gate (R/R·신호 강도·변동성 한계 검증)
                 → 최종 PositionRecommendation
    """
    def __init__(self, target_volatility=0.02, max_position_size=1.0,
                 min_risk_reward=1.0, min_signal_strength=60):
        if target_volatility <= 0 or not 0 < max_position_size <= 1:
            raise ValueError("target_volatility > 0, max_position_size는 0~1이어야 합니다.")
        self.target_volatility = target_volatility
        self.max_position_size = max_position_size
        self.min_risk_reward = min_risk_reward
        self.min_signal_strength = min_signal_strength

    # ---------- 정책(Policy) 단계 ----------
    def _policy(self, a: AnalysisVector) -> Dict[str, Any]:
        """6개 지표 조합으로 방향/진입조건/진입가/목표가/손절가/비중을 설계한다."""
        price, dc, rms, kf, kc = a.current_price, a.dc_trend, a.v_rms, a.k_f, a.k_c
        if a.wave_state == "STRONG_TREND":
            entry = price
            target = price + kf * rms
            stop = dc - 0.8 * rms
            pol = {"direction": "LONG", "action": "BUY",
                   "entry_condition": "즉시 진입 (시장가). K_f 안정 + AC > 0 + DC 상방 충족",
                   "entry": entry, "target": target, "stop": stop,
                   "size": self._vol_target_size(price, rms),
                   "reason": (f"K_f={kf:.2f} 파형 일관성 안정, K_c={kc:.2f} 정상, "
                              f"AC(+{a.ac_signal:.0f})가 DC 추세선 상방 유지")}
        elif a.wave_state == "OVERBOUGHT_SPIKE":
            pol = {"direction": "FLAT", "action": "SELL / TAKE_PROFIT",
                   "entry_condition": "신규 진입 금지. 보유 포지션 즉시 청산",
                   "entry": price, "target": price, "stop": price - 0.5 * rms,
                   "size": 0.0,
                   "reason": (f"K_c={kc:.2f} 스파이크 과열 → 절연파괴형 반전 리스크. "
                              f"AC가 에너지 한계(+{1.5 * rms:.0f}) 이탈")}
        elif a.wave_state == "SQUEEZE":
            pol = {"direction": "LONG", "action": "READY",
                   "entry_condition": (f"조건부 지정가: {dc + 1.5 * rms:,.0f} 상방 돌파 시 매수. "
                                       f"하방 -{1.0 * rms:.0f} 이탈 시 하방 분출로 간주"),
                   "entry": dc + 1.5 * rms, "target": dc + 3.0 * rms, "stop": dc - 1.0 * rms,
                   "size": self._vol_target_size(price, rms) * 0.5,   # 분할 진입 절반 비중
                   "reason": (f"V_rms={rms:,.0f} 변동 에너지 응축 완료 → 분출 임박. "
                              "돌파 방향 확인 후 진입")}
        else:
            pol = {"direction": "FLAT", "action": "HOLD",
                   "entry_condition": "진입 금지 (비정형/노이즈 구간)",
                   "entry": price, "target": price, "stop": price - rms,
                   "size": 0.0,
                   "reason": "파형의 질적 일관성 부족(K_f/K_c 비정형): 관망"}
        return pol

    def _vol_target_size(self, price: float, rms: float) -> float:
        ratio = rms / price if price > 0 else 0.0
        if ratio <= 0:
            return self.max_position_size
        return float(min(self.max_position_size, self.target_volatility / ratio))

    # ---------- 신호 강도 ----------
    def _signal_strength(self, a: AnalysisVector) -> int:
        state, kf, kc, ac, rms = a.wave_state, a.k_f, a.k_c, a.ac_signal, a.v_rms
        if state == "STRONG_TREND":
            score = 70.0 + max(0.0, 1.18 - kf) * 50 - max(0.0, kc - 1.5) * 20
            score += min(10.0, (ac / rms) * 10) if rms > 0 else 0
        elif state == "OVERBOUGHT_SPIKE":
            score = 65.0 + max(0.0, kc - 2.0) * 15
        elif state == "SQUEEZE":
            score = 50.0
        else:
            score = 20.0
        return int(max(0, min(100, round(score))))

    @staticmethod
    def _rr(entry: float, target: float, stop: float) -> Tuple[float, float, float]:
        risk, reward = abs(entry - stop), abs(target - entry)
        return risk, reward, (reward / risk if risk > 0 else 0.0)

    # ---------- 공개 인터페이스 ----------
    def generate(self, a: AnalysisVector, timeframe: str = "1d") -> PositionRecommendation:
        # 1) Position Policy
        pol = self._policy(a)
        risk, reward, rr = self._rr(pol["entry"], pol["target"], pol["stop"])
        strength = self._signal_strength(a)
        action, size, reason = pol["action"], pol["size"], pol["reason"]

        # 2) Risk Gate
        if action == "BUY" and rr < self.min_risk_reward:
            size = 0.0
            action = "HOLD (R/R 미달)"
            reason += f" | R/R={rr:.2f} < 최소 요구치({self.min_risk_reward}) → 진입 보류"
        if action == "BUY" and strength < self.min_signal_strength:
            size = round(size * 0.5, 4)
            reason += f" | 신호 강도({strength}) 미달 → 비중 절반 축소"

        ind = {"V_rms": round(a.v_rms, 4), "V_avg": round(a.v_avg, 4),
               "K_f": round(a.k_f, 4), "K_c": round(a.k_c, 4),
               "AC_signal": round(a.ac_signal, 4), "DC_trend": round(a.dc_trend, 4),
               "Wave State": a.wave_state}
        return PositionRecommendation(a.symbol, timeframe, pol["direction"], action,
                                      pol["entry_condition"], round(pol["entry"], 2),
                                      round(pol["target"], 2), round(pol["stop"], 2),
                                      round(size, 4), round(risk, 2), round(reward, 2),
                                      round(rr, 2), strength, round(a.current_price, 2),
                                      reason, ind)


# ================================================================
# SECTION: multi_symbol_analyzer.py
# ================================================================
# from .contracts import MarketData, PositionRecommendation
# from .wave_analysis import WaveAnalysisAlgorithm
# from .position_recommender import PositionRecommender

class MultiSymbolAnalyzer:
    """MarketData 목록만 받는다. DataCollector/데이터 소스 의존 없음."""
    def __init__(self, algorithm: WaveAnalysisAlgorithm, recommender: PositionRecommender):
        self.algorithm = algorithm
        self.recommender = recommender

    def analyze_one(self, raw: MarketData) -> PositionRecommendation:
        return self.recommender.generate(self.algorithm.process(raw), raw.timeframe)

    def analyze_all(self, raws: List[MarketData]) -> pd.DataFrame:
        rows = [self.analyze_one(r).to_dict() for r in raws]
        return pd.DataFrame(rows)

    @staticmethod
    def save_signals(df: pd.DataFrame, path: str = "signals.csv") -> str:
        df.to_csv(path, index=False, encoding="utf-8-sig")
        return path


# ================================================================
# SECTION: backtest.py
# ================================================================
# from .contracts import MarketData
# from .wave_analysis import WaveAnalysisAlgorithm
# from .position_recommender import PositionRecommender

class WaveBacktester:
    """
    MarketData 기반 Walk-Forward 백테스트.
    규칙: 직전 시점 정책의 direction이 LONG이면 해당 봉 수익률 획득, FLAT이면 현금.
    SQUEEZE의 READY는 진입 확정이 아니므로 관망 처리. 수수료 0.015%.
    """
    FEE = 0.00015

    def __init__(self, algorithm: WaveAnalysisAlgorithm, recommender: PositionRecommender,
                 initial_capital: float = 100_000_000.0):
        self.algorithm = algorithm
        self.recommender = recommender
        self.initial_capital = initial_capital

    def run(self, raw: MarketData) -> Dict[str, Any]:
        analyses = self.algorithm.rolling_analyses(raw)
        close = raw.close
        equity = [self.initial_capital]
        in_market, trades, wins = False, 0, 0
        for t, a in enumerate(analyses):
            rec = self.recommender.generate(a, raw.timeframe)
            want_long = rec.direction == "LONG" and rec.action == "BUY"
            i = t + self.algorithm.window_size  # 이 시점의 봉 인덱스
            ret = (close[i] / close[i - 1]) - 1 if i > 0 else 0.0
            changed = (want_long != in_market)
            in_market = want_long
            gross = ret if in_market else 0.0
            fee = self.FEE if changed else 0.0
            equity.append(equity[-1] * (1 + gross - fee))
            if changed and in_market:
                trades += 1
                if ret > 0: wins += 1
        eq = np.array(equity)
        total = eq[-1] / eq[0] - 1
        n = len(eq) - 1
        ann = (1 + total) ** (252 / max(n, 1)) - 1 if n > 0 else 0.0
        vol = np.std(np.diff(eq) / eq[:-1]) * np.sqrt(252)
        peak = np.maximum.accumulate(eq)
        mdd = float(np.max((peak - eq) / peak))
        return {"symbol": raw.symbol, "final_equity": round(eq[-1], 2),
                "total_return_pct": round(total * 100, 2),
                "annualized_return_pct": round(ann * 100, 2),
                "annualized_vol_pct": round(vol * 100, 2),
                "sharpe": round(ann / vol, 2) if vol > 0 else 0.0,
                "max_drawdown_pct": round(mdd * 100, 2),
                "trades": trades,
                "win_rate_pct": round(wins / trades * 100, 1) if trades else 0.0}


# ================================================================
# SECTION: 외부 (패키지 밖) — 데모용 MarketData 공급 예시
# 실전에서는 이 부분만 REST/WebSocket/증권사 API로 교체하면 된다.
# ================================================================
def demo_market_data(symbol: str, n: int = 200) -> MarketData:
    """데모용 가상 시세 생성. 실전에서는 이 함수를 API 어댑터로 대체."""
    rng = np.random.default_rng(abs(hash(symbol)) % (2 ** 32))
    returns = rng.normal(0.001, 0.015, n)
    returns[-1] = 0.052
    prices = 70000.0 * np.exp(np.cumsum(returns))
    return MarketData(symbol, "1d",
                      pd.date_range(end=pd.Timestamp.now(), periods=n, freq="D"),
                      prices, rng.integers(100000, 500000, n).astype(float))


if __name__ == "__main__":
    pd.set_option("display.width", 180)
    pd.set_option("display.max_columns", 30)

    # 패키지 구성 (데이터 수집 모듈은 존재하지 않음 — MarketData만 들어온다)
    algo = WaveAnalysisAlgorithm(window_size=20)
    reco = PositionRecommender(target_volatility=0.02)
    analyzer = MultiSymbolAnalyzer(algo, reco)
    backtester = WaveBacktester(algo, reco)

    print("=" * 70)
    print("[1] 단일 종목 포지션 설계 리포트")
    print("=" * 70)
    raw = demo_market_data("005930", 50)
    rec = analyzer.analyze_one(raw)
    print(f"종목       : {rec.symbol} ({rec.timeframe}) / 현재가 {rec.current_price:,.2f}")
    print("-" * 45)
    print(f"Direction  : {rec.direction}")
    print(f"Action     : {rec.action}")
    print(f"Entry      : {rec.entry_price:,.2f}  ({rec.entry_condition})")
    print(f"Target     : {rec.target_price:,.2f} / Stop: {rec.stop_loss:,.2f}")
    print(f"Risk {rec.risk:,.2f} / Reward {rec.reward:,.2f} / R/R {rec.risk_reward:.2f}")
    print(f"Size       : {rec.position_size * 100:.2f}% / Signal {rec.signal_strength}/100")
    print(f"Reason     : {rec.reason}")

    print()
    print("=" * 70)
    print("[2] 멀티 종목 스캔 (MarketData 목록 입력만으로 동작)")
    print("=" * 70)
    raws = [demo_market_data(s, 60) for s in ["005930", "000660", "035420"]]
    df = analyzer.analyze_all(raws)
    cols = ["symbol", "direction", "action", "entry_price", "target_price",
            "stop_loss", "risk_reward", "signal_strength", "position_size"]
    print(df[cols].to_string(index=False))

    print()
    print("=" * 70)
    print("[3] Walk-Forward 백테스트")
    print("=" * 70)
    for r in raws:
        stats = backtester.run(demo_market_data(r.symbol, 200))
        print(f"{stats['symbol']}: 최종자산 {stats['final_equity']:,.0f} | "
              f"누적 {stats['total_return_pct']:+.2f}% | 연율 {stats['annualized_return_pct']:+.2f}% | "
              f"Sharpe {stats['sharpe']:.2f} | MDD {stats['max_drawdown_pct']:.2f}% | "
              f"매매 {stats['trades']}회 | 승률 {stats['win_rate_pct']}%")