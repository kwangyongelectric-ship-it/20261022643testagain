"""실제 OOSValidator/GateStabilityAnalyzer 출력이 ApprovalEngine(OOSBindingGate)을 통과/거절하는지 끝에서 끝까지 확인."""
import dataclasses
from datetime import timedelta
from types import SimpleNamespace as NS
import numpy as np, pandas as pd

import oos_validation_bound as ov
from approval_engine_bound import ApprovalEngine, ApprovedPosition, Rejection, verdict_for_reasons
from position_confidence import ConfidenceCalibrator, validate_chronological, build_validation_binding
from bar_finality import finalize_market_data
from test_confidence import make_trades, MISCAL, Rec, Trust, MD
from wave_analysis import MarketData, WaveAnalysisAlgorithm

GATE = ov.GateConfig(1.0, 60)
def _real_now(): return pd.Timestamp.now(tz="Asia/Seoul")
def _last_end():            # 어제 이전의 마지막 영업일 = 항상 '확정'된 봉
    return pd.offsets.BDay().rollback((_real_now().normalize() - pd.Timedelta(days=1)).tz_localize(None))   # 주말이면 직전 금요일

class _PassBT:                      # OOS 판정 로직만 검증하려고 성과를 고정한 백테스터
    def __init__(s, algo, rec): pass
    def run(s, test): return {"trades": 9, "sharpe": 9.0, "max_drawdown_pct": 0.0, "total_return_pct": 1.0}
class _Rec:
    def __init__(s, **k): pass

def _raw(sym="005930", end=None, n=300):
    end = end if end is not None else _last_end()
    rng = np.random.default_rng(3)
    return MarketData(sym, "1d", pd.bdate_range(end=end, periods=n), 70000 * np.exp(np.cumsum(rng.normal(0, .01, n))), np.full(n, 1e5))

def _grid(best=(1.0, 60)):
    return pd.DataFrame([{"min_risk_reward": rr, "min_signal_strength": ss, "score": 1.0 if (rr, ss) == best else 0.9}
                         for rr in (0.8, 1.0, 1.2, 1.5) for ss in (40, 50, 60, 70)])

def _setup(sym="005930"):
    A = make_trades(2000, MISCAL, seed=11); o = sorted(A, key=lambda t: (t.decision_time, t.symbol)); n = len(o)
    asof = o[np.linspace(max(1, int(n * .5)), n, 5).astype(int)[3]].decision_time
    rep = validate_chronological(A, strategy_version="v1"); cal = ConfidenceCalibrator().fit(A, asof)
    b = build_validation_binding(rep, cal, "v1", A)
    raw = _raw(sym)
    oos = ov.OOSValidator(lambda: WaveAnalysisAlgorithm(window_size=20), _Rec, _PassBT, lambda tr: GATE,
                          min_oos_trades=1, strategy_version="v1").validate(raw)
    stab = ov.GateStabilityAnalyzer().analyze(_grid(), sym, strategy_version="v1", data_fingerprint=oos.data_fingerprint)
    _, meta = finalize_market_data(MD(sym, "1d", raw.timestamps, raw.close, raw.volume), _real_now(), "kis")
    eng = ApprovalEngine(cal, rep, min_prob=0.45, require_binding=True, strategy_version="v1", expected_gate=GATE)
    now = pd.Timestamp.now(tz="UTC")
    return eng, dict(signal_bar=meta.last_bar_ts, meta=meta, trust=Trust(), now=now, binding=b), oos, stab, Rec(symbol=sym, signal_strength=62.0)

def _codes(d): return [r.split(":")[0] for r in d.reasons]
def _run(eng, base, rec, oos, stab): return eng.evaluate(rec, oos_report=oos, stability_report=stab, **base)

def test_real_reports_are_bound_and_approved():
    eng, base, oos, stab, rec = _setup()
    assert oos.verdict == "OOS_PASS" and oos.created_at.tzinfo is not None and oos.data_fingerprint and oos.data_end is not None
    d = _run(eng, base, rec, oos, stab)
    assert isinstance(d, ApprovedPosition) and d.binding_status == "VERIFIED_MATCH", getattr(d, "reasons", d)

def test_fake_report_rejected():
    eng, base, oos, stab, rec = _setup()
    d = _run(eng, base, rec, NS(verdict="OOS_PASS"), NS(stable=True))
    assert isinstance(d, Rejection) and {"OOS_REPORT_INVALID", "GATE_STABILITY_INVALID"} <= set(_codes(d))

def test_other_symbol_rejected():
    eng, base, oos, stab, rec = _setup()
    d = _run(eng, base, rec, dataclasses.replace(oos, symbol="OTHER"), stab)
    assert "OOS_SYMBOL_MISMATCH" in _codes(d)
    d = _run(eng, base, rec, oos, dataclasses.replace(stab, symbol="OTHER"))
    assert "OOS_STABILITY_SYMBOL_MISMATCH" in _codes(d)

def test_other_gate_rejected():
    eng, base, oos, stab, rec = _setup()
    d = _run(eng, base, rec, dataclasses.replace(oos, frozen_gate=ov.GateConfig(0.8, 40)), stab)
    assert "OOS_GATE_MISMATCH" in _codes(d) and "OOS_STABILITY_GATE_MISMATCH" in _codes(d)

def test_missing_expected_gate_rejected():
    eng, base, oos, stab, rec = _setup(); eng.oos_gate.expected_gate = None
    assert "OOS_GATE_UNSPECIFIED" in _codes(_run(eng, base, rec, oos, stab))

def test_stale_report_by_created_at_rejected():
    eng, base, oos, stab, rec = _setup()
    old = pd.Timestamp.now(tz="UTC") - timedelta(days=8)
    assert "STALE_OOS" in _codes(_run(eng, base, rec, dataclasses.replace(oos, created_at=old), stab))
    assert "STALE_OOS" in _codes(_run(eng, base, rec, dataclasses.replace(oos, created_at=pd.Timestamp("2026-01-01")), stab))

def test_old_data_with_fresh_created_at_rejected():
    """오래된 데이터로 '오늘' 만든 리포트: created_at만 보면 통과하지만 data_end로 걸러야 한다."""
    eng, base, _, _, rec = _setup()
    raw_old = _raw(end="2024-06-03")
    oos = ov.OOSValidator(lambda: WaveAnalysisAlgorithm(window_size=20), _Rec, _PassBT, lambda tr: GATE,
                          min_oos_trades=1, strategy_version="v1").validate(raw_old)
    stab = ov.GateStabilityAnalyzer().analyze(_grid(), "005930", strategy_version="v1", data_fingerprint=oos.data_fingerprint)
    assert (pd.Timestamp.now(tz="UTC") - oos.created_at) < pd.Timedelta(minutes=1)      # created_at은 신선
    assert "STALE_OOS_DATA" in _codes(_run(eng, base, rec, oos, stab))

def test_clock_skew_tolerance():
    eng, base, oos, stab, rec = _setup()
    soon = pd.Timestamp.now(tz="UTC") + timedelta(seconds=30)           # 다른 머신에서 만든 리포트(시계 오차)
    assert isinstance(_run(eng, base, rec, dataclasses.replace(oos, created_at=soon), stab), ApprovedPosition)
    hour = pd.Timestamp.now(tz="UTC") + timedelta(hours=1)
    assert "STALE_OOS" in _codes(_run(eng, base, rec, dataclasses.replace(oos, created_at=hour), stab))

def test_version_and_fingerprint_mismatch():
    eng, base, oos, stab, rec = _setup()
    assert "OOS_VERSION_MISMATCH" in _codes(_run(eng, base, rec, dataclasses.replace(oos, strategy_version="old"), stab))
    assert "OOS_STABILITY_FINGERPRINT_MISMATCH" in _codes(_run(eng, base, rec, oos, dataclasses.replace(stab, data_fingerprint="x")))
    assert "OOS_FINGERPRINT_MISSING" in _codes(_run(eng, base, rec, dataclasses.replace(oos, data_fingerprint=""), stab))

def test_verdict_mapping_for_new_codes():
    eng, base, oos, stab, rec = _setup()
    d = _run(eng, base, rec, dataclasses.replace(oos, strategy_version="old"), dataclasses.replace(stab, strategy_version="old"))
    assert verdict_for_reasons(d.reasons) == "REVALIDATION_REQUIRED"
    assert verdict_for_reasons(["STALE_OOS: x"]) == "REJECTED"

def test_fingerprint_changes_with_one_bar():
    raw = _raw(); tr, te = ov.split_time_ordered(raw, 0.7, 20)
    c = te.close.copy(); c[5] *= 1.0001
    te2 = MarketData(te.symbol, te.timeframe, te.timestamps, c, te.volume)
    assert ov.oos_data_fingerprint(tr, te) != ov.oos_data_fingerprint(tr, te2)

def test_last_end_is_business_day_and_raw_has_exact_length():
    """요일 의존 회귀: 월요일/주말에 실행해도 헬퍼가 평일 끝점과 정확한 봉 수를 만든다."""
    assert _last_end().weekday() < 5
    assert len(_raw().close) == 300
    for k in range(7):                                        # 어느 요일을 '어제'로 잡아도 300봉
        anchor = pd.offsets.BDay().rollback(pd.Timestamp("2026-10-12") + pd.Timedelta(days=k))
        assert len(pd.bdate_range(end=anchor, periods=300)) == 300


if __name__ == "__main__":
    f = 0
    for k, fn in sorted(globals().items()):
        if k.startswith("test_") and callable(fn):
            try: fn(); print("PASS", k)
            except Exception as e: f += 1; print("FAIL", k, type(e).__name__, str(e)[:100])
    raise SystemExit(1 if f else 0)
